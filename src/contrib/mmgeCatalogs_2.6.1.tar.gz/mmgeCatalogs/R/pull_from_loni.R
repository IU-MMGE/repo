#'@export
pull_from_loni <- function(file_name, study = "ppmi", save_location, proxyHost,
                           proxyPort, add_dates = TRUE, add_loni = TRUE,
                           build_file_name = TRUE, use_cache = TRUE) {

  jar_file <- system.file("java/IdaDbSyncDownload_19Apr2019.jar", package = "mmgeCatalogs")

  return_df <- FALSE
  cache_folder <- "~/.mmgeCatalogs"

  if(!dir.exists(cache_folder)) {
    dir.create(cache_folder)
  }

  # if(missing(save_location)) {
  #   save_location <- tempfile(fileext = ".csv")
  #   save_location <- file.path(cach_folder, paste0(file_name, ".csv"))
  #   return_df <- TRUE
  # }

  dl_file <- file_name

  if(build_file_name) {

    if(!grepl("$v\\.*_", dl_file)) {
      if(add_loni) {
        dl_file <- paste0("v_loni_", dl_file)
      } else {
        dl_file <- paste0("v_", dl_file)
      }
    }

    if(!grepl("_dates$", dl_file) & add_dates) {
      dl_file <- paste0(dl_file, "_dates")
    }

  }

  if(missing(save_location)) {
    save_location <- file.path(cache_folder, paste0(dl_file, ".csv"))
    return_df <- TRUE
  }

  if(use_cache) {
    if(return_df) {
      if(file.exists(save_location)) {
        if(as.numeric(Sys.time()) - as.numeric(file.info(save_location)$ctime) < (60*60)) {
          message("Returning cached data for `", file_name, "`...")
          message("File cached at ", file.info(save_location)$ctime)
          df <- read.csv(save_location, stringsAsFactors = FALSE)
          return(df)
        } else {
          message("Cache stale... refreshing")
        }
      }
    }
  }

  cmd <- "java"

  if(!missing(proxyHost)) {
    cmd <- paste0(cmd, " -Dhttps.proxyHost=", proxyHost)
    cmd <- paste0(cmd, " -Dhttp.proxyHost=", proxyHost)
    if(!is.null(proxyPort)) {
      cmd <- paste0(cmd, " -Dhttps.proxyPort=", proxyPort)
      cmd <- paste0(cmd, " -Dhttp.proxyPort=", proxyPort)
    }
  }

  cmd <- paste(cmd, "-jar -Xmx800m", jar_file, save_location, "https://ida.loni.usc.edu/dbsync/table", study, dl_file, Sys.getenv("LONI_USER"), Sys.getenv("LONI_PW"))

  if(Sys.info()[['sysname']] == "Windows") {
    x <- try(system(cmd, ignore.stdout = TRUE, show.output.on.console = FALSE))
  } else {
    x <- try(system(cmd, ignore.stdout = FALSE))
  }

  if(return_df) {
    df <- read.csv(save_location, stringsAsFactors = FALSE)
    return(df)
  } else {
    message("Wrote data to CSV file '", save_location, "'")
    return(invisible(TRUE))
  }

}
