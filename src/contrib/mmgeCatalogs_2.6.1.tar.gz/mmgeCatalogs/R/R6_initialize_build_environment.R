R6_initialize_build_environment <- function() {

  db <- debugR::debug('build_environment')

  build_env <- new.env()

  script_loc <- c(private$config_obj$build$locations$scripts, file.path(self$catalog_dir, "scripts"))

  files <- unlist(sapply(script_loc, function(loc) {
    list.files(loc, full.names = TRUE, pattern = "\\.R$")
  }))

  if(length(files) > 0) {
    invisible(
      sapply(normalizePath(files),
             source,
             local = build_env
      )
    )
  }

  if('startup' %in% ls(build_env)) {
    build_env$startup(private$config_obj, private$dictionary_obj, private$recodes)
  }

  private$build_environment <- build_env

  return(invisible(self))

}