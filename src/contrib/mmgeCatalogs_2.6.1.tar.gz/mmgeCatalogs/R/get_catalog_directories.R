get_catalog_directories <- function(root = "/media/HG-Data") {

  min_version <- settings$min_version

  dirs <- list.files(root, recursive = TRUE, full.names = TRUE)
  dirs <- gsub("/config.yaml$", "", dirs[ grep("Catalogs\\/(.*)config\\.yaml", x = dirs)])

  all_dirs <- dirs[sapply(dirs, function(dir) {
    suppressWarnings(config <- try(yaml::yaml.load_file(file.path(dir, "config.yaml"))))
    if(inherits(config, 'try-error')) {
      warning("Couldn't load config.yaml in ", dir, ". Skipping...", call. = FALSE)
      return(FALSE)
    } else if('enabled' %in% names(config)) {
      if(config$enabled == FALSE) {
        warning("Catalog in ", dir, " disabled. Skipping...", call. = FALSE)
        return(FALSE)
      }
    } else if('version' %in% names(config)) {
      if(config$version < min_version) {
        warning("Catalog in ", dir, " is version ", config$version, ". `min_version` set to ", min_version, ". Skipping...", call. = FALSE)
        return(FALSE)
      }
    }

    return(TRUE)

  })]

  return(all_dirs)

}