R6_save_catalog <- function(dev = TRUE, save_group = 'month', deploy = !dev, ...) {

  db <- debugR::debug("save_catalog")

  if(is.null(private$last_update)) {

    message("Building Catalog before save...")
    self$build()

  }

  for(deploy_name in names(private$config_obj$deploy)) {
    if(deploy_name %in% names(deployment_functions)) {
      deployment_functions[[deploy_name]](self, private, deploy, dev, ...)
    } else {
      warning("No deployment function defined for `", deploy_name, "`. Skipping...")
    }
  }

  self$log(level = 'info', event = 'Catalog Data Saved')

  return(invisible(self))

}

collection <- function(name, protocol, catalog_name, dev, self) {

  if(missing(dev)) {
    dev = getOption("catalog_environment") %in% c("STG", "DEV")
  }

  if(!missing(self)) {
    protocol <- self$protocol[1]
    catalog_name <- self$catalog_name
  }

  if(dev) {
    paste(protocol, catalog_name, name, "dev", sep = "_")
  } else {
    paste(protocol, catalog_name, name, sep = "_")
  }

}

