R6_get_sources <- function() {

  db <- debugR::debug("get_sources")

  dictionary <- private$dictionary_obj

  source_types <- unique(c(dictionary$source, names(private$config_obj$build$source_joins)))
  source_types <- source_types[!grepl("^_", source_types)]

  tesla_source_names <- NULL
  if("tesla_sources" %in% names(private$config_obj$build)) {
    private$get_tesla_sources()
    tesla_source_names <- names(private$config_obj$build$tesla_sources)
  }

  if(any(!source_types %in% c(private$reserved_source_types, tesla_source_names))) {
    private$get_flat_file_sources(self)
  }

  for(source_type in source_types) {
    if(paste0("get_", source_type, "_sources") %in% ls(private)) {
      private[[paste0("get_", source_type, "_sources")]]()
    }
  }

  return(invisible(self))

}