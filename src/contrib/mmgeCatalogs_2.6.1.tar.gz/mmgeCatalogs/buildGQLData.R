buildGQLData <- function() {

  devtools::load_all()

  dirs <- get_catalog_directories()
  protocols <- c("MMGE-REF-POOL")
  selects <- c()
  selects <- unique(c(selects, settings$default_fields))
  bad_selects <- c()

  query <- NULL
  valid_selects <- unique(c(oncore2::annotation_list()$ANNOTATION, oncore2::field_list()$COLUMN_NAME))

  for(dir in dirs) {
    suppressWarnings({
      config <- try(yaml::yaml.load_file(file.path(dir, "config.yaml")))
      dictionary <- try(yaml::yaml.load_file(file.path(dir, "dictionary.yaml")))
    })
    if(!inherits(config, 'try-error') && !inherits(dictionary, 'try-error')) {
      other_selects <- c()
      try({
        other_selects <- unique(c(config$build$oncore_settings$fields))
      }, silent = TRUE)
      protocols <- c(protocols, config$protocol)
      catalog_selects <- c(other_selects, get_oncore_fields(dictionary))
      bad_catalog_selects <- catalog_selects[!catalog_selects %in% valid_selects]
      if("CONCENTRATION_UOM" %in% catalog_selects) {
        print(config$protocol)
      }
      if(length(bad_catalog_selects) > 0) {
        message("Found ", length(bad_catalog_selects), " unrecognized field(s) in ", dir, ":\n\t", paste(bad_catalog_selects, collapse = "\n\t"))
      }
      if("COLLECTION_DATE" %in% catalog_selects) {
        warning(config$name, " contains COLLECTION_DATE. This could cause problems.")
      }
      selects <- c(selects, catalog_selects)
    } else {
      if(inherits(config, 'try-error')) {
        warehouse_log("error", "Config Load", config)
      }
      if(inherits(dictionary, 'try-error')) {
        warehouse_log("error", "Dictionary Load", dictionary)
      }
    }
  }

  protocols_all <- unlist(oncore2::query_oncore("select distinct P.PROTOCOL_NO from {schema}.ONC_PCL_MANAGEMENT_GROUP M, {schema}.SV_ACTIVE_PROTOCOLS P, {schema}.ONC_MANAGEMENT_GROUP G where  G.NAME in ('MMGE- Hereditary Genomics', 'MMGE-CC- Hereditary Genomics') and P.PROTOCOL_ID = M.PROTOCOL_ID and G.ONC_MANAGEMENT_GROUP_ID = M.RESEARCH_MANAGEMENT_GROUP_ID"), recursive = TRUE)

  selects <- unique(unlist(selects))
  valid_selects <- unique(c(oncore2::annotation_list()$ANNOTATION, oncore2::field_list()$COLUMN_NAME))
  bad_selects <- selects[!selects %in% valid_selects]
  selects <- unique(selects)
  selects <- sort(selects)
  if(length(bad_selects) > 0) {
    message("Removing ", length(bad_selects), " unrecognized field(s) from the oncore query.\n\t",paste(bad_selects, collapse = "\n\t"))
    selects <- selects[selects %in% valid_selects]
  }
  protocols <- unique(c(protocols, protocols_all))
  oncore_settings <- list(distinct = TRUE, recode = TRUE, execute=FALSE)

  query <- oncore2::oncore_query(selects = selects, filters = oncore2::mmge_protocols(), .args = oncore_settings)

  selects = query$selects
  annotations = query$annotations
  sources = query$all_source[!is.na(query$all_source$table2), ]

  specimen_tables <- c("SV_BSM_SPECIMEN", sources$TABLE_NAME[sources$table2 == "SV_BSM_SPECIMEN"])
  case_tables <- c("SV_BSM_CASE", sources$TABLE_NAME[sources$table2 == "SV_BSM_CASE"])
  subject_tables <- c("SMRS_PCL_CENT_SUBJECT", sources$TABLE_NAME[sources$table2 == "SMRS_PCL_CENT_SUBJECT"])
  protocols_tables <- c("SV_PROTOCOL", sources$TABLE_NAME[sources$table2 == "SV_PROTOCOL"])

  specimen_selects = unique(c(oncore2::field_list()$COLUMN_NAME[oncore2::field_list()$TABLE_NAME == "SV_BSM_SPECIMEN", selects$COLUMN_NAME[selects$TABLE_NAME %in% specimen_tables]))

  specimen_data <- oncore2::oncore_query(selects = selects$COLUMN_NAME[selects$TABLE_NAME %in% specimen_tables], filters = oncore2::mmge_protocols(), .args=list(distinct = TRUE, recode = TRUE))
  case_data <- oncore2::oncore_query(selects = selects$COLUMN_NAME[selects$TABLE_NAME %in% case_tables], filters = oncore2::mmge_protocols(), .args=list(distinct = TRUE, recode = TRUE))
  subject_data <- oncore2::oncore_query(selects = selects$COLUMN_NAME[selects$TABLE_NAME %in% subject_tables], filters = oncore2::mmge_protocols(), .args=list(distinct = TRUE, recode = TRUE))

}