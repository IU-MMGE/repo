#'@import shiny
#'@import shinydashboard
#'@import rhandsontable
#'@import shinyBS2
#'@importFrom magrittr '%>%'
#'@export
magrittr::`%>%`

#'@importFrom rlang '.data'
#'@export
rlang::.data

#'@importFrom rlang ':='
#'@export
rlang::`:=`

#'@importFrom mmgeCatalogsLite 'write_log'
#'@export
mmgeCatalogsLite::write_log

.onAttach <- function(...) {


}



.onLoad <- function(...) {

  # Create link to javascript and css files for package
  shiny::addResourcePath("mmgeCatalogs", system.file("www", package="mmgeCatalogs"))

  settings <- yaml::yaml.load_file(system.file(package = "mmgeCatalogs", "settings/settings.yaml"))
  assign('settings', value = settings, pos = parent.env(environment()))

  #Shamelessly stolen from dplyr's onLoad hook
  # op <- options()
  # op.mongo <- list(
  #   mongo.url = "mongodb://nformmgo.medgen.iupui.edu/?ssl=true",
  #   mongo.cert = openssl::read_cert(system.file("ssl/baileye.pem", package = "mmgeMongo")),
  #   mongo.key = openssl::read_key(system.file("ssl/baileye.key", package = "mmgeMongo")),
  #   mongo.ca = system.file("ssl/mmgeCA.pem", package = "mmgeMongo")
  # )
  # toset <- !(names(op.mongo) %in% names(op))
  # if (any(toset)) options(op.mongo[toset])
}

mmgeCatalogsDep <- htmltools::htmlDependency(
  "mmgeCatalogs",
  packageVersion("mmgeCatalogs"),
  src = c(href = "mmgeCatalogs"),
  stylesheet = c(
    "mmgeCatalogs.css",
    "bootstrap-tour.css"
  ),
  script = c(
    "bootstrap-tour.js",
    "tour.js",
    "mmgeCatalogs2.js"
  )
)

#'@export
Mode <- function(x) {
  ux <- unique(x)
  ux[which.max(tabulate(match(x, ux)))]
}

check_decimals <- function(x) {

  unname(ceiling(quantile(sapply(strsplit(as.character(x), ".", fixed = TRUE), function(w) {
    if(length(w) == 2) {
      nchar(w[2])
    } else {
      0
    }
  }), 0.90)))

}

oncore2tesla <- function(oncore_fields, clean = FALSE) {

  map <- yaml::yaml.load_file(system.file("settings/tesla_map.yaml", package = "mmgeCatalogs"))

  map_subset <- map[map %in% oncore_fields]

  x <- names(map_subset)
  names(x) <- unname(map_subset)

  if(clean) {
    names(x) <- oncore2:::standard_names(names(x))
  }

  return(x)

}

tesla2oncore <- function(tesla_fields, clean = FALSE) {

  map <- yaml::yaml.load_file(system.file("settings/tesla_map.yaml", package = "mmgeCatalogs"))

  map_subset <- map[names(map) %in% tesla_fields]

  if(clean) {
    x <- oncore2:::standard_names(map_subset)
    names(x) <- names(map_subset)
  } else {
    x <- map_subset
  }

  return(x)

}

buildField <- Vectorize(function(x, type, catalog, attr, removed_fields, ...) {

  class(x) <- c(type, class(x))

  UseMethod('buildField', x)

}, vectorize.args = c("x", "catalog"))

buildField.image <- function(x, type, catalog, attr, removed_fields, ...) {

  catalog <- catalog[!names(catalog) %in% removed_fields]

  catalog <- catalog[sapply(catalog, function(x) {
    if("Date" %in% class(x)) {
      return(TRUE)
    } else if(is.null(x)) {
      return(FALSE)
    } else if(is.na(x)) {
      return(FALSE)
    } else if(x == "NA") {
      return(FALSE)
    } else if(x == "") {
      return(FALSE)
    } else {
      return(TRUE)
    }
  })]

  jsonlite::toJSON(list(
    attributes = attr,
    record = catalog,
    images = jsonlite::fromJSON(x)
  ), auto_unbox = TRUE)

}
