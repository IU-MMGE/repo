check_config <- function(config) {

  required <- c('name', 'short_name', 'protocol', 'version')
  missing <- required[!required %in% names(config)]

  if(length(missing) > 0) {
    if(interactive()) {
      self$open('config')
    }
    stop("The following required field(s) are missing from `config.yaml`:\n\t", paste("-", missing, collapse = "\n\t"), call. = FALSE)
  }

  if(config$version < settings$min_version) {
    stop("Selected catalog is version ", private$config_obj$version,
         ". Minimum catalog version for this package is ", settings$min_version,
         ".", call. = FALSE)
  }

}