combine_configs <- function(x, y) {

  if(!is.null(names(x)) & !is.null(names(y))) {
    ynames <- names(y)
    unnamed <- y[ynames == ""]
    x <- c(x, unnamed)
    for(n in names(y)) {
      if(!n %in% names(x)) {
        x[[n]] <- y[[n]]
      } else {
        x[[n]] <- combine_configs(x[[n]], y[[n]])
      }
    }
  } else if(length(x) > 1 | length(y) > 1) {
    x <- c(x, y)
  } else {
    x <- y
  }

  return(x)

}