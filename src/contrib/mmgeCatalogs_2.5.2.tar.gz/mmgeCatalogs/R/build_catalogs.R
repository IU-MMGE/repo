#'@export
build_catalogs <- function(dirs, save = TRUE, deploy = FALSE, dev = TRUE) {

  catalogs <- process_catalogs(fn = function(protocol, catalog_name, config, dir) {

    suppressMessages(suppressWarnings({
      x <- try(mmgeCatalog$new(protocol = protocol, catalog_name = catalog_name), silent = TRUE)
      if(!inherits(x, 'try-error')) {
        x <- try({x$build()}, silent = TRUE)
        catalog_name <- config$short_name
      } else {
        catalog_name <- ""
      }
      y <- list(protocol = protocol, catalog_name = config$short_name, result = x)
      if(!inherits(y$result, "try-error")) {
        if(nrow(y$result$catalog) > 0) {
          if(save) {s <- y$result$save(dev = dev, deploy = !dev)}
          if(deploy) {y$result$deploy(dev = dev)}
        } else {
          y$result$log("error", event = "Catalog Build", msg = "Zero-length catalog created")
        }
      } else {
        write_log(protocol = protocol, catalog = catalog_name, level = "error", event = "Catalog Build", message = y$result['message'])
      }
    }))
    if(inherits(y$result, 'try-error')) {
      message((crayon::red(clisymbols::symbol$cross, "ERROR:")), " ", protocol, " ", config$short_name)
    } else {
      records <- nrow(y$result$catalog)
      if(records > 0) {
        message((crayon::green(clisymbols::symbol$tick, "SUCCESS:")), " ", protocol, "\b:", config$short_name, "-", crayon::green("Records: ", records))
      } else {
        message(crayon::bgBlack(crayon::magenta(clisymbols::symbol$cross, "ERROR:")), " ", protocol, " - No records produced")
      }
    }

    return(y)

  })

  show_build_result(catalogs)

  return(invisible(catalogs))

}

show_build_result <- function(catalogs, console = TRUE) {

  x <-as.data.frame(matrix(unname(unlist(lapply(catalogs, function(y) {
    z <- list(
      PROTOCOL = y$protocol[[1]],
      CATALOG = y$catalog_name
    )
    if(inherits(y$result, 'mmgeCatalog')) {
      if(nrow(y$result$catalog) > 0) {
        if(console) {
          z$result = crayon::bgBlack(crayon::green("SUCCESS"))
        } else {
          z$result = "<span style='color: green;'>SUCCESS</span>"
        }
      } else {
        if(console) {
          z$result = crayon::bgBlack(crayon::red("FAILURE"))
        } else {
          z$result = "<span style='color: red;'>FAILURE</span>"
        }
      }
      if(nrow(y$result$problems) > 0) {
        z$problems = nrow(y$result$problems)
      } else {
        z$problems = 0
      }
      z$count = nrow(y$result$catalog)
    } else {
      if(console) {
        z$result = crayon::bgBlack(crayon::red("FAILURE"))
      } else {
        z$result = "<span style='color: red;'>FAILURE</span>"
      }
      z$problems = 0
      z$count = 0
    }
    return(z)
  }))), ncol=5, byrow = TRUE), stringsAsFactors = FALSE)
  colnames(x) <- c("PROTOCOL", "CATALOG", "RESULT", "PROBLEMS", "COUNT")
  if(console) {
    console_result(x)
  } else {
    email_result(x, dev)
  }

}

console_result <- function(x) {
  p_char <- max(nchar(c(x$PROTOCOL, "PROTOCOL")))
  c_char <- max(nchar(c(x$CATALOG, "CATALOG")))
  r_char <- 7
  e_char <- max(nchar(c(x$COUNT, "PROBLEMS")))
  l_char <- max(nchar(c(x$COUNT, "COUNT")))
  x$PROTOCOL <- sprintf(paste0("%", p_char, "s"), x$PROTOCOL)
  x$CATALOG <- sprintf(paste0("%", c_char, "s"), x$CATALOG)
  x$PROBLEMS <- sprintf(paste0("%", e_char, "s"), x$PROBLEMS)
  x$COUNT <- sprintf(paste0("%", l_char, "s"), x$COUNT)

  make_header <- function(header, width) {
    nc <- nchar(header)
    fs <- floor((width - nc) / 2)
    h <- paste0(c(header, rep(" ", times = fs)), collapse = "")
    sprintf(paste0("%", width, "s"), h)
  }

  cat(make_header("PROTOCOL", p_char), " | ", make_header("CATALOG", c_char), " | ", make_header("RESULT", r_char), " | ", make_header("PROBLEMS", e_char), " | ", make_header("COUNT", l_char), "\n")
  cat(paste(paste(rep("-", times = p_char), collapse = ""),
            paste(rep("-", times = c_char), collapse = ""),
            paste(rep("-", times = r_char), collapse = ""),
            paste(rep("-", times = e_char), collapse = ""),
            paste(rep("-", times = l_char), collapse = ""),
            sep = "--|--"), "\n")
  for(r in seq(nrow(x))) {
    cat(x$PROTOCOL[r], " | ", x$CATALOG[r], " | ", x$RESULT[r], " | ", x$PROBLEMS[r], " | ", x$COUNT[r] , "\n")
  }
  cat("\n\n")
  for(x in catalogs) {
    if(inherits(x$result, 'try-error')) {
      l <- paste0("  ", x$protocol, " - ", x$catalog_name)
      l <- paste(c(l, rep(" ", times = (80 - nchar(l)))), collapse = "")
      cat(crayon::bgWhite(crayon::blue(crayon::bold(sprintf("%80s", l)))))
      cat("\n", x$result, "\n\n")
    }
  }
}

email_result <- function(x, dev) {

  msg <- "<p>The build catalogs script has completed. Output is below:</p>"

  msg <- paste0(msg, kableExtra::kable(x, escape = FALSE, align=c("l", "l","l","r","r"), table.attr = "border=\"2\" cellspacing=\"0\""))

  if(dev) {
    sub <- glue::glue("mmgeCatalogs Dev Report - {Sys.Date()}")
  } else {
    sub <- glue::glue("mmgeCatalogs Report - {Sys.Date()}")
  }

  email = "baileye@iu.edu"


  pymailr::send_email(sub, html_body = as.character(msg), to = email, from = "hgreport")

}