R6_get_recodes <- function() {

  db <- debugR::debug("R6_get_recodes")

  dictionary <- yaml::yaml.load_file(file.path(self$catalog_dir, "dictionary.yaml"))

  recodes <- lapply(dictionary, function(x) {
    if('recode' %in% names(x)) {
      list(
        source = x$source,
        source_id = x$source_id,
        recode = x$recode
      )
    }
  })
  recodes <- recodes[!sapply(recodes, is.null)]

  private$recodes_obj <- recodes

  return(invisible(self))

}