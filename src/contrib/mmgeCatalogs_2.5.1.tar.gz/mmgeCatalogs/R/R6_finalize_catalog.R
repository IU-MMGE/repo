R6_finalize_catalog <- function() {

  db <- debugR::debug("finalize_catalog")

  cnfg <- private$config_obj
  ctlg <- private$catalog_obj
  dict <- private$dictionary_obj
  dict <- dict %>%
    dplyr::filter(hidden == FALSE) %>%
    dplyr::rowwise() %>%
    dplyr::ungroup()

#  ctlg <- ctlg[colnames(ctlg) %in% dict$source_id]

  rn <- c(dict$source_id, '.__distributable_quantity')
  names(rn) <- c(dict$catalog_id, '.__distributable_quantity')

#  colnames(ctlg) <- make.names(colnames(ctlg))
  ctlg <- ctlg %>%
    dplyr::ungroup() %>%
    dplyr::select(rn)

  if(ncol(ctlg) != length(rn)) {
    stop("Unable to locate all columns from data dictionary. Missing: ", paste(dict$source_id[!dict$catalog_id %in% colnames(ctlg)], collapse = ", "), call. = FALSE)
  }

  for(req in dict$catalog_id[dict$required]) {
    problems <- ctlg %>%
      dplyr::filter_(glue::glue("is.na(`{req}`) | `{req}` == '' | `{req}` == 'NA'"))
    if(nrow(problems) > 0) {
      samp_id <- private$dictionary_obj$catalog_id[private$dictionary_obj$sample_id]
      message("Problems found in ", self$protocol[1], " - ", self$catalog_name)
      for(i in seq(nrow(problems))) {
        r <- problems[i, ]
        private$add_problem(r[[samp_id]], req, "Required value is missing or NA")
      }
    }
    ctlg <- ctlg %>%
      dplyr::filter_(sprintf("!is.na(`%s`)", req)) %>%
      dplyr::filter_(sprintf("`%s` != 'NA'", req)) %>%
      dplyr::filter_(sprintf("`%s` != ''", req))
  }

  myeval <- function(...) {
    eval(parse(text = glue::glue(...)))
  }

  samp_id <- private$dictionary_obj$catalog_id[private$dictionary_obj$sample_id]
  ctlg[[samp_id]][is.na(ctlg[[samp_id]])] <- make_sample_ids(sum(is.na(ctlg[samp_id])))

  fields <- colnames(ctlg)

  smpl_id <- private$dictionary_obj$catalog_id[private$dictionary_obj$sample_id]

  ctlg <- myeval("ctlg %>% dplyr::group_by(`{paste(fields, collapse = '`, `')}`)") %>%
    dplyr::summarize_all(Mode) %>%
    dplyr::ungroup() %>%
    dplyr::distinct()

#   ctlg <- ctlg %>%
#     dplyr::group_by(.dots = fields) %>%
#     dplyr::summarize_all(Mode) %>%
# #  ctlg <-  myeval("ctlg %>% dplyr::group_by({smpl_id}, .__distributable_quantity) %>% dplyr::summarize_all(Mode)") %>%
#     dplyr::ungroup() %>%
#     dplyr::distinct()

  while(sum(duplicated(ctlg[samp_id])) > 0) {
    #private$add_problem("Duplicate Sample IDs found. Appending a .1...")
    ctlg <- myeval("ctlg %>% dplyr::group_by({smpl_id})") %>%
      dplyr::mutate(.__group_id = row_number()) %>%
      dplyr::mutate(.__group_cnt = n()) %>%
      dplyr::ungroup()
    ctlg = myeval("ctlg %>% dplyr::mutate({smpl_id} = ifelse(.__group_cnt > 1, paste({smpl_id}, .__group_id, sep='.'), {smpl_id}))")
    ctlg <- ctlg %>%
      dplyr::select( -.__group_cnt, -.__group_id)
  }

  ctlg <- ctlg %>%
    dplyr::select(-.__distributable_quantity)

  if("postprocess" %in% ls(private$build_environment)) {
    ctlg <- private$build_environment$postprocess(dplyr::ungroup(ctlg), private$config_obj, private$dictionary_obj)
  }

  special_types <- c("image", "link")

  # ctlg_rows <- lapply(seq(nrow(ctlg)), function(i) {
  #   as.list(ctlg[i, ])
  # })

  removed_fields <- sapply(seq(nrow(dict)), function(i) {
    if(is.na(dict$type[i])) {
      return(NULL)
    } else if(dict$type[i] == "image") {
      return(dict$catalog_id[i])
    } else {
      return(NULL)
    }
  })
  removed_fields <- removed_fields[!sapply(removed_fields, is.null)]

  #Get rid of NAs

  #Convert to specified types
  for(i in seq(ncol(ctlg))) {
    col <- colnames(ctlg[i])
    type <- dict$type[dict$catalog_id == col]
    if(length(type) > 0) {
      if(is.na(type)) {
          if(is.character(ctlg[, i])) {
            ctlg[is.na(ctlg[, i]), i] <- "NA"
            ctlg[ctlg[,i] == "NA", i] <- ""
          }
        } else {
          if(!type %in% special_types) {
            ctlg[[col]] <- as(ctlg[[col]], Class = type)
          } else {
            xxx <<- ctlg[[col]]
            ctlg[[col]] <- buildField(ctlg[[col]], type, ctlg_rows, private$config_obj$build$attribute_definitions, removed_fields)
          }
        }

    }
  }

  for(i in seq(ncol(ctlg))) {
    if(is.character(ctlg[,i])) {
      ctlg[is.na(ctlg), i] <- ""
    }
  }

  private$catalog_obj <- ctlg
  private$last_update <- Sys.time()

  return(invisible(self))

}
