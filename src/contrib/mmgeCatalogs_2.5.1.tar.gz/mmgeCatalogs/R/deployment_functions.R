deployment_functions <- list(
  hgdata = function(self, private, deploy, dev, ...) {
    try({
      tryCatch({

        dict <- private$dictionary_obj

        ctlg <- private$catalog_obj
        ctlg <- ctlg[, sapply(dict$type, function(t) {
          if(is.na(t)) return(TRUE)
          return(t != "image")
        })]

        if(nrow(private$problems_obj) > 0) {
          ctlg <- list(
            Catalog = ctlg,
            Problems = private$problems_obj
          )
        }

        mmge::save_report(ctlg, name = private$config_obj$name,
                          protocol = self$protocol[1], save_group = 'year',
                          type = 'xlsx', ...)

      }, error = function(e) {
        print(e)
        self$log_event(level = 'error', event = "HG-Data Save", msg = e['message'])
        return(NULL)
      })
    })

  },
  mongo = function(self, private, deploy, dev, ...) {
    tryCatch({

      message("Saving to mongodb")

      config <- private$config_obj
      config$last_update <- private$last_update

      db <- "mmgeCatalogs"

      if(interactive()) {
        message("Saving catalog to ", collection("catalog", dev = dev, self = self), " in ", db, ".")
      }

      mmgeMongo::save_to_mongo(data = self$catalog, database = db, collection = collection("catalog", dev = dev, self = self))
      mmgeMongo::save_to_mongo(data = private$dictionary_obj, database = db, collection = collection('dictionary', dev = dev, self = self))
      mmgeMongo::save_to_mongo(data = config, database = db, collection = collection('config', dev = dev, self = self))

    }, error = function(e) {
      self$log(level = 'error', event = "Mongo Data Upload", msg = e['message'])
    })

  },
  loni = function(self, private, deploy, dev, ...) {
    tryCatch({
      if(is.list(private$config_obj$deploy$loni)) {
        study <- private$config_obj$deploy$loni$study
        table <- private$config_obj$deploy$loni$table
        catalog <- self$catalog
        catalog[catalog=="NA"] <- ""
        result <- paste(push_to_loni(catalog, study = study, table = table, intern = TRUE), collapse = "\n")
        message(result)
        if(result != "Server has accepted the data.") {
          stop(result)
        } else {
          self$log(level = 'info', event = "LONI Data Upload", msg = result)
        }
      } else {
        warning("Cannot recognize LONI data push parameters.", call. = FALSE)
      }
    }, error = function(e) {
      self$log(level = 'error', event = "LONI Data Upload", msg = e)
    })
  },
  nform = function(self, private, deploy, ...) {
    try({
      print(private$config_obj$deploy$nform)
      message(IUGBAPI::postCatalog(self$catalog, colnames = private$config_obj$deploy$nform$colnames, api_name=private$config_obj$deploy$nform$api_name))
    })
  }
)