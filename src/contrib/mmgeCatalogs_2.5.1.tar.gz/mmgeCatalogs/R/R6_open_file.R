R6_open_file <- function(name) {
  if(rstudioapi::isAvailable()) {
    if(name %in% c('config', 'config.yaml', 'dictionary', 'dictionary.yaml')) {
      if(!grepl("yaml$", name)) name = paste0(name, ".yaml")
      fp <- file.path(self$catalog_dir, name)
    } else if(grepl("^preprocess|startup|mutates|postprocess", name)) {
      fname <- gsub("\\.R$", "", name)
      if(!grepl("\\.R$", name)) name = paste0(name, ".R")
      fp <- file.path(self$catalog_dir, 'scripts', name)
      if(!file.exists(fp)) {
        if(rstudioapi::showQuestion("Create File", paste0("Do you want to create the file? \n", fp, ""))) {
          if(!dir.exists(file.path(self$catalog_dir, 'scripts'))) {
            dir.create(file.path(self$catalog_dir, "scripts"))
          }
          f <- glue::glue("library(dplyr)\n\n{fname} <- function(df, config, dictionary) {{\n\n\n\n\treturn(df)\n}}\n")
          writeLines(f, con = fp)

        } else {
          return(invisible(FALSE))
        }
      }
    } else if(grepl('settings', name, fixed = TRUE)) {
      fp <- file.path(self$protocol_dir, "Settings", 'settings.yaml')
    } else {
      stop("Cannot interpret ", name, "...")
    }
    rstudioapi::navigateToFile(fp)
    if(grepl("^preprocess", name)) {
      file_name <- gsub("^preprocess_", "", name)
      file_name <- gsub("\\.R$", "", file_name)
      assign("df", value = private$open_data_file(file_name), envir = .GlobalEnv)
      assign("config", value = private$config_obj, envir = .GlobalEnv)
      assign("dictionary", value = private$dictionary_obj, envir = .GlobalEnv)
    }
  } else {
    warning("This method isn't available outside RStudio.")
  }
}