build_inventory <- function(config, clean = TRUE) {

  if(config$verbose) message("Building Inventory")

  if("external_data" %in% names(config)) {
    for(i in seq_along(config$external_data)) {
      name <- gsub("\\..+$", "", names(config$external_data)[i])
      join <- unlist(config$external_data[[i]]$join)
      config$env$query <- dplyr::left_join(config$env$query, config$env[[name]], by = join)
    }
  }

  build_field <- function(f, config) {

    type = names(config$fields[[f]])[1]

    switch(type,
      field = {
        config$env$query[[unlist(config$fields[[f]]$field)]]
      },
      annotation = {
        config$env$query[[anno_format(config$fields[[f]]$annotation)]]
      },
      value = {
        unname(unlist(config$fields[[f]], recursive = TRUE))
      },
      formula = {
        eval(parse(text = paste0("dplyr::mutate(query, ", f, " = ", unname(unlist(config$fields[[f]]$formula)), ")")), envir = config$env)[[f]]
      },
      external = {
        config$env$query[[unlist(config$fields[[f]]$external)]]
      })
  }

  if(!"query" %in% names(config$env)) {
    config <- query_oncore(config)
  }

  inventory <- data.frame(stringsAsFactors = FALSE)
  missing <- data.frame(stringsAsFactors = FALSE)

  for(f in names(config$fields)) {
    if(nrow(inventory) == 0) {
      x <- list()
      x[[f]] = build_field(f, config)
      inventory <- as.data.frame(x, stringsAsFactors = FALSE)
    } else {
      inventory[[f]] <- build_field(f, config)
    }
  }

  inventory$KEEP = TRUE

  for(i in seq_along(config$not_na)) {
    x <- config$not_na[i]
    m <- inventory[is.na(inventory[[x]]), ]
    if(nrow(m) > 0) {
      m$REASON = paste0("Missing ", x)
      missing <- rbind(missing, m)
      inventory$KEEP[is.na(inventory[[x]])] <- FALSE
    }
  }

  inventory = inventory[inventory$KEEP, ]
  inventory$KEEP = NULL
  inventory[is.na(inventory)] <- ""

  config$inventory <- inventory
  config$dropped_records <- missing

  return(invisible(config))

}
