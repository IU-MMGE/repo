anno_format <- function(anno) {
#  substr(make.names(toupper(gsub(" ", "_", anno, fixed = TRUE))), 1, 29)
  make.names(toupper(gsub(" ", "_", anno, fixed = TRUE)))
}
