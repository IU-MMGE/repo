#'@export
publish_inventory <- function(config) {

  if(!"publish" %in% names(config)) {
    stop("Inventory config file must contain a `publish` argument to use the publish_inventory function.")
  } else {
    if(config$verbose) message("Publishing Inventory...")
  }

  if(toupper(config$publish$where) == "LONI") {
    inventory <- as.data.frame(config$inventory)
    if("table" %in% names(config$publish)) {
      mmge::push_to_loni(df = inventory, table = config$publish$table, study = config$publish$study)
    } else if("type" %in% names(config$publish)) {
      mmge::push_to_loni(df = inventory, type = config$publish$type, study = config$publish$study)
    } else {
      stop("Couldn't determine which table to publish inventory to.")
    }
  } else {
    stop("Did not recognize publish `where` statement...")
  }

  return(invisible(config))

}
