#'@importFrom magrittr '%>%'
#'@export
magrittr::`%>%`
