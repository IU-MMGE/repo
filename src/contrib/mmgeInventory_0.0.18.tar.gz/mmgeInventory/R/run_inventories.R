#'@export
run_inventories <- function(dir = mmge::hgdata()) {

  protocols <- list.dirs(dir, full.names = FALSE, recursive = FALSE)
  protocols <- protocols[grepl("^([[:alnum:]]+-){2,}([[:alnum:]])+$", protocols)]

  for(protocol in protocols) {
    if("inventory.yaml" %in% list.files(file.path(dir, protocol, "settings"), full.names = FALSE)) {
      conf_file <- file.path(dir, protocol, "settings", "inventory.yaml")
      conf <- yaml::yaml.load_file(conf_file)
      if(check_when(conf)) {
        message("Running inventory for ", protocol)
        inventory <- read_config(conf_file) %>%
          query_oncore() %>%
          build_inventory()
        if("publish" %in% names(inventory)) {
          publish_inventory(inventory)
        }
        save_inventory(inventory)
      } else {
        message("Skipping inventory for ", protocol)
      }
    }
  }

}

check_when <- function(conf) {
  if(!("when" %in% names(conf))) {
    return(FALSE)
  } else {
    when <- conf$when
    x <- Sys.Date()
    today <-   c(
      format(x, "%d"),
      paste0("W", format(x, "%W")),
      format(x, "%A"),
      format(x, "%a"),
      format(x, "%x"),
      format(x, "%D"),
      format(x, "%Y"),
      format(x, "%j")
    )
    if(all(when %in% today)) {
      return(TRUE)
    }
  }
  return(FALSE)
}
