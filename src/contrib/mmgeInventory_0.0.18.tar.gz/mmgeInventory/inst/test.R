rm(list = ls())
library(dplyr)
devtools::load_all()

config_file = "/media/HG-Data/MMGE-MJFF-PPMI-BIO/Settings/inventory.yaml"

config <- read_config(config_file) %>%
  query_oncore() %>%
  build_inventory() %>%
  publish_inventory() %>%
  save_inventory()

x <- build_protocol_inventory("MMGE-NIA-NCRAD") %>%
  save_inventory() %>%
  publish_inventory()

create_inventory <- function(protocol) {

  config_file <- file.path(mmge::hgdata(protocol), "Settings/inventory.yaml")

  x <-read_config(config_file) %>%
    query_oncore() %>%
    build_inventory() %>%
    publish_inventory() %>%
    save_inventory()

}
