#'@export
final_check = function(x){
  x$SPECIMEN_COMMENTS = ifelse(is.na(x$SPECIMEN_COMMENTS),"",x$SPECIMEN_COMMENTS)
  test = x%>%
    mutate(MAIN_BU = ifelse(grepl("TK",SPECIMEN_STORAGE_LOCATION),"1",ifelse(grepl("main",SPECIMEN_STORAGE_LOCATION,ignore.case=TRUE),"2","3")))%>%
    mutate(IPSC = ifelse(grepl("PPMI",PROTOCOL_NO)&CELL_TYPE=="iPSC"&COLLECTION_GROUP=="PBMC"&VENDOR=="IUGB",
                         "A",
                         ifelse(grepl("PPMI",PROTOCOL_NO)&CELL_TYPE=="iPSC"&COLLECTION_GROUP=="PBMC"&VENDOR=="CDI",
                                "B",
                                ifelse(grepl("PPMI",PROTOCOL_NO)&CELL_TYPE=="iPSC"&COLLECTION_GROUP=="PBMC"&VENDOR=="WiCell",
                                       "C",
                                       ifelse(grepl("PPMI",PROTOCOL_NO)&CELL_TYPE=="iPSC"&COLLECTION_GROUP=="PBMC"&VENDOR=="RUCDR",
                                              "D",
                                              ifelse(grepl("PPMI",PROTOCOL_NO)&CELL_TYPE=="iPSC"&COLLECTION_GROUP=="PBMC"&VENDOR=="NYSCF",
                                                     "E","Z"))))))%>%
    arrange(IPSC,SPECIMEN_COMMENTS,MAIN_BU,SPECIMEN_NO)
  return(test)
}
