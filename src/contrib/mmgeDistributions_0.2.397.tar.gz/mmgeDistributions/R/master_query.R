

master_fields = c("PROTOCOL_NO","SPECIMEN_NO",
                  "SPECIMEN_STORAGE_LOCATION",
                  "PARENT_SPECIMEN_ID","ALTERNATE_MRN",
                  "PATIENT_ID","SUBJECT_LAST_NAME",
                  "COLLECTION_GROUP","SPECIMEN_TYPE",
                  "VISIT","CASE_NO","SPECIMEN_QUANTITY",
                  "SPECIMEN_BAR_CODE","SPECIMEN_STATUS",
                  "PCS_SPECIMEN_ID","SPECIMEN_COMMENTS",
                  "SEQUENCE_NUMBER","SPECIMEN_REQUEST_ID",
                  "GENDER","UNIT_OF_MEASURE","ACCESSION_DATE",
                  "COLLECTION_DATE","SUBJECT_FIRST_NAME",
                  "ALIQUOT_CREATION_DATE_TIME",
                  "COLLECTION_DATE_TIME","REASON_DESTROYED",
                  "SUBJECT_MRN","ALIQUOT_CREATION_DATE",
                  "PROCEDURE_DATE","BIRTH_DATE","STUDY_SITE",
                  "RACE","ETHNICITY","ARM_CODE","SPECIMEN_UOM",
                  "PREPARATION_DATE","TIMEPOINT_LABEL",
                  "EMAIL","SUBJECT_MIDDLE_NAME","RECRUITED_BY_LAST",
                  "RECRUITED_BY_FIRST")

master_annotations = c("Kit Number","Freeze / Thaw Cycle",
                       "Concentration","Concentration UOM",
                       "Instrument for QC","Volume","Volume UOM",
                       "DNA Source","Genotyped",
                       "Genotyping Instrument",
                       "Last Date Genotyped",
                       "Nucleic Acid Derivative",
                       "Collection Container","Storage Container",
                       "Cell Type","Hemoglobin Assay",
                       "Researcher Reserved For","Hemolysis Grade",
                       "Turbidity Grade","260/230 Ratio",
                       "260/280 Ratio","RIN Value",
                       "Case or Control",
                       "Non-Conformance Detail (specimen)",
                       "Non-Conformance Reason (specimen)",
                       "RNA QC Instrument","Initial Quantity",
                       "Initial Quantity UOM",
                       "Duration of Centrifugation",
                       "Temperature of Centrifugation",
                       "Rate of Centrifugation (xg)",
                       "Freezing Media","Viability (%)",
                       "Storage Temperature","Date Frozen",
                       "Fasting","CSF Collected",
                       "Site Centrifugation Time",
                       "Site Aliquot Time","Time Frozen",
                       "Collection Site","Hospital Site","Vendor","Non-Conformance Issue(s)")

exclude_protocol_table = data.frame(PROTOCOL_NO = c("9401-17","IUCRO-0221","IUCRO-0280","PHO-IIR-RENBARGER-IPB08","IUCRO-0216",
                                                        "IUCRO-0256","IUCRO-0031","IUCRO-0514","1111007321","IUCRO-0454","IUCRO-0473",
                                                        "PHO-IIR-RENBARGER-IPB02","IUSCC-0534","IUCRO-0288","ENMD-2076","CC06-C-0213",
                                                        "SGN35-013","11-PIR-11","SGI-110-02","020221","IUCRO-0191","P11-3","IUCRO-0205",
                                                        "GS-US-295-0203","PHO-IIR-RENBARGER-IPB07","IUCRO-0495","IUCRO-0228","SGN00-001",
                                                        "INCB18424-262","IMA901-301","IUCRO-0300","EX0309-17","IUSCC-0678","GU10-148","MA32",
                                                        "9805-03EX","GOG199","MM-121-04-02-08","TPU-TAS-114-101","IUCRO-0057","04-066",
                                                        "IUCRO-0373","EX0303-11","GI03-53","CP1005B016","CTKI258A2211","GOG136","IUCRO-0130",
                                                        "MEF4982G","IUSCC-0630","GO25632","GU12-160","IUCRO-0381","IUCRO-0137","GOG175",
                                                        "AGS-003-004","TPU-TAS-102-301","IPI-504-14","GI05-92","0401-59","IUCRO-0198","GOG210",
                                                        "P53","AGS-003-007","GI-IIR-LAMMERT-ADENOMA"))

recode_list = c("REASON_DESTROYED","RECRUITED_BY_FIRST",
                "RECRUITED_BY_LAST","COLLECTION_SITE","HOSPITAL_SITE",
                "INITIAL_QUANTITY_UOM",
                "NON.CONFORMANCE_REASON_.SPECIMEN.","INSTRUMENT_FOR_QC",
                "CELL_TYPE","VENDOR","GENOTYPING_INSTRUMENT",
                "CONCENTRATION_UOM","VOLUME_UOM","DNA_SOURCE",
                "GENOTYPED","RESEARCHER_RESERVED_FOR","STORAGE_CONTAINER",
                "CASE_OR_CONTROL","TURBIDITY_GRADE","CELL_TYPE",
                "NON.CONFORMANCE_REASON_.SPECI","NUCLEIC_ACID_DERIVATIVE",
                "HEMOLYSIS_GRADE")

category_list = c("REASON_DESTROYED","RECRUITED_BY_FIRST",
                  "RECRUITED_BY_LAST","COLLECTION_SITE","HOSPITAL_SITE",
                  "INITIAL_QUANTITY_UOM",
                  "BSM_SPECIMEN_NON-CONFORMANCE","DNA_QC_ANALYSIS_METHOD",
                  "CELL_TYPE","BSM_VENDOR","GENOTYPING_INSTRUMENT",
                  "CONCENTRATION_UOM","VOLUME_UOM","DNA_SOURCE",
                  "GENOTYPED","RESEARCHER_RESERVED_FOR","STORAGE_CONTAINER",
                  "CASE_OR_CONTROL","TURBIDITY_GRADE","CELL_TYPE",
                  "NON.CONFORMANCE_REASON_.SPECI","NUCLEIC_ACID_DERIVATIVE",
                  "HEMOLYSIS_GRADE")

#'@export
master_query = function (runs = 4,env = "PRD",recode = TRUE)
{
  require(dplyr)


  cycle_div_fields = seq(1,length(master_fields),by=floor(length(master_fields)/runs))
  cycle_div_annotations = seq(1,length(master_annotations),
                              by=floor(length(master_annotations)/runs))
  cycle_div_fields[runs+1] = length(master_fields)
  cycle_div_annotations[runs+1] = length(master_annotations)

  for(i in 1:runs){
    if(i==runs){
      last = 0
    } else{
      last=1
    }
    eval(parse(text=paste0("query_fields",i," = unique(c('SPECIMEN_BAR_CODE',master_fields[cycle_div_fields[",i,"]:(cycle_div_fields[",i+1,"]-",last,")]))")))
    eval(parse(text=paste0("query_annotations",i," = master_annotations[cycle_div_annotations[",i,"]:(cycle_div_annotations[",i+1,"]-",last,")]")))

  }

  for(i in 1:runs){
    eval(parse(text = paste0("query",i," <- oncore2::oncore_connect(env = env) %>% oncore2::select_fields_(.dots = query_fields",i,") %>%
    oncore2::select_annotations(.dots = query_annotations",i,")%>%oncore2::execute_query()")))

    eval(parse(text = paste0("query",i," = query",i,"%>%select(-contains('JOIN'))")))

    if(i==1){
      query = query1
      rm(query1)
    } else{
      eval(parse(text = paste0("query = query%>%left_join(query",i,",by='SPECIMEN_BAR_CODE');rm(query",i,")")))
    }
  }


  ####QUERY_CLEANUP
  if(recode){
    for(i in 1:length(recode_list)){
      # try({
      #   query = recode_field(query,recode_list[i],category = category_list[i])
      # })
      tryCatch({
        query = oncore2::recode_field(query,recode_list[i])

      }, warning = function(w) {
        print(paste0("warning: ",recode_list[i]," ...trying with category"))
        query = oncore2::recode_field(query,recode_list[i],force_recode = TRUE)
        print(w)
      }, error = function(e) {
        print(paste0("error: ",recode_list[i]))
        print(e)
      })
    }
  }


  query = query%>%anti_join(exclude_protocol_table,by="PROTOCOL_NO")
  query$SPECIMEN_COMMENTS = ifelse(is.na(query$SPECIMEN_COMMENTS),
                                   "", query$SPECIMEN_COMMENTS)
  query = query %>% dplyr::arrange(SPECIMEN_COMMENTS)
  query = query%>%
    mutate(PROTOCOL_GROUP =
             ifelse(grepl("ADC",PROTOCOL_NO)&!grepl("ADCCC|ADCFB",PROTOCOL_NO),"MMGE-NIA-NCRAD-ADC",
                    ifelse(grepl("CTSI-IB-CC",PROTOCOL_NO),"MMGE-CTSI-IB-CC",
                           ifelse(grepl("MMGE-CTSI-IB",PROTOCOL_NO)&!grepl("CTSI-IB-CC",PROTOCOL_NO),"MMGE-CTSI-IB",PROTOCOL_NO))))
  ######################
  return(query)

}


