#'@export

#############################################################################################################################################
add_final_box_positions <- function(df, box) {
  if(is.null(df)) return(NULL)
  tb <- box %>%
    dplyr::ungroup() %>%
    dplyr::select_("SPECIMEN_NO", "FINAL_BOX_NO", "FINAL_BOX_POSITION")
  # stopifnot({
  #   nrow(tb %>% dplyr::distinct(CASE_NO)) == nrow(box)
  # })
  dplyr::left_join(df, tb)
}
#############################################################################################################################################
#'@export
split_aliquots = function(aliquot,number_of_children,config){
  if(missing(config)){
    split_id=F
  } else{
    split_id=T
  }
  if(nrow(aliquot) > 0) {
    aliquot_number = list(aliquot)
    aliquot_test = aliquot
    if(number_of_children>1){
      for (i in 1:number_of_children){
        aliquot_number[[i]] = aliquot
        aliquot_number[[i]]$SPECIMEN_NO = gsub("$",paste0(".",i),aliquot_number[[i]]$SPECIMEN_NO)
        if(split_id){
          aliquot_number[[i]][[config$subject_ids$blinded]] = gsub("$",paste0(".",i),aliquot_number[[i]][[config$subject_ids$blinded]])
        }

        if(i>1){
          aliquot_test = full_join(aliquot_number[[i]],aliquot_test)
        }
        else{
          aliquot_test = aliquot_number[[i]]
        }
      }
    }
    else{
      aliquot_test = aliquot
    }
  }
  else{
    aliquot_test = NULL
  }
  return(aliquot_test)
}
#############################################################################################################################################
create_aliquot_cols = function(aliquot,number_of_children,box_name,box_size,extra_fields,dir){
  if(nrow(aliquot) > 0) {
    child_barcodes = c()
    for (i in 1:number_of_children){
      cola = paste0("CHILD_BAR_CODE",i,collapse = "_")
      aliquot[[cola]]=""
      child_barcodes[i] = cola
    }
  rearranged_colnames <- c("SPECIMEN_NO", "SPECIMEN_BAR_CODE", child_barcodes)
  aliquot = aliquot%>%
    select_pullsheet_fields(.dots = c(extra_fields,child_barcodes),dir=dir,box_name=box_name,box_size = box_size)
  cn <- colnames(aliquot)
  cn <- c(rearranged_colnames, cn[!cn %in% rearranged_colnames])
  aliquot <- dplyr::select_(aliquot, .dots = cn)
  }
  else{
    aliquot = NULL
  }
  return(aliquot)
}
#############################################################################################################################################
dupes <- function(df, colname = "SPECIMEN_NO") {
  df[df[[colname]] %in% df[[colname]][duplicated(df[[colname]])], ]
}
#############################################################################################################################################
add_scanned_barcode = function(wb,name,data,box=F){
  txtStyle <- openxlsx::createStyle(numFmt = "TEXT")
  negStyle <- openxlsx::createStyle(fontColour = "#9C0006", bgFill = "#FFC7CE", numFmt = "TEXT")
  posStyle <- openxlsx::createStyle(fontColour = "#006100", bgFill = "#C6EFCE", numFmt = "TEXT")
  k=which(colnames(data)=="SCANNED_BAR_CODE")
  if(k<=9){
    letter = chartr("123456789","ABCDEFGHI",k)
    letter2 = chartr("123456789","ABCDEFGHI",k+1)
  }
  if(k>9){
    l=k-9
    letter = chartr("123456789","JKLMNOPQR",l)
    letter2 = chartr("123456789","ABCDEFGHI",l+1)
  }
  openxlsx::addStyle(wb, name, cols = k, rows = 2:(nrow(data) + 1), style = txtStyle, stack = TRUE)
  openxlsx::conditionalFormatting(wb, name, cols = k, rows = 2:(nrow(data) + 1), rule = paste0('AND($',letter,'2<>"", $A2=$',letter,'2)'), style = posStyle, stack = TRUE)
  openxlsx::conditionalFormatting(wb,name, cols = k, rows = 2:(nrow(data) + 1), rule = paste0('AND($',letter,'2<>"", $A2<>$',letter,'2)'), style = negStyle, stack = TRUE)
}
#############################################################################################################################################
