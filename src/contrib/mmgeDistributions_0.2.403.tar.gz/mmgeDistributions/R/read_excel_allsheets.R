#'@export
read_excel_allsheets <- function(filename, tibble = FALSE) {
  require(readxl)
  if(grepl("csv",list.files(file.path(filename)))){
    x = read.csv(file.path(filename,list.files(file.path(filename))))
  }

  if(grepl("xls",list.files(file.path(filename)),ignore.case = T)){
    sheets <- readxl::excel_sheets(file.path(filename,list.files(file.path(filename))))
    x <- lapply(sheets, function(X) readxl::read_excel(file.path(filename,list.files(file.path(filename))), sheet = X))
    if(!tibble) x <- lapply(x, as.data.frame)
    names(x) <- sheets
  }
  x
}