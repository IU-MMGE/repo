#' Get requested specimens
#'
#' Access the requested specimens table in OnCore.
#'
#' @param requests an optional list of request ids to filter on
#' @param dir The directory for the distribution
#'
#' @export
get_requested_specimens <- function(requests = NULL, dir = ".") {

  config <- get_pullsheet_config(dir)

  requested_specimens <- oncore2::queryOncore("SELECT * FROM ONCORE.SV_BSM_REQUEST_SPECIMENS", env = config$oncore_environment)

  if(!is.null(requests)) {
    requested_specimens <- requested_specimens %>%
      filter(SPECIMEN_REQUEST_ID %in% requests)
  }

  return(requested_specimens)

}