get_pullsheet_config <- function(dir = ".") {

  config <- yaml::yaml.load_file(file.path(dir, "config.yaml"))

}

get_manifest_config <- function(dir = "..") {

  config <- yaml::yaml.load_file(file.path(dir, "R", "config.yaml"))

}