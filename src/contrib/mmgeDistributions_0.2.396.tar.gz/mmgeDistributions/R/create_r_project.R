create_r_project <- function(request_data) {

  r_dir <- file.path(request_data$directory, "R")
  if(!dir.exists(r_dir)) {
    dir.create(r_dir)
  }
  suppressWarnings({
    dir.create(file.path(r_dir, "data"))
    dir.create(file.path(r_dir, "scripts"))
  })

  if(inherits(try(get_footprints_attachments(request_data$number, file.path(r_dir, "data"))), "try-error")) {
    warning("Attachments may not have downloaded properly...", call. = FALSE)
  }

  write_pullsheet_r(request_data)
  write_rproj(request_data)
  write_yaml(request_data)

  return(invisible(TRUE))

}

write_pullsheet_r <- function(request_data) {

  required_packages <- c("oncore2", "dplyr", "openxlsx", "mmge", "mmgeDistributions", "mmgeProtocols", "future")

  libraries <- paste("library(", required_packages, ")", collapse = "\n", sep = "")

  desc <- strsplit(request_data$desc, "\n", fixed = TRUE)[[1]]
  desc <- paste("##", desc, sep = " ", collapse = "\n")

  info <- glue::glue(.sep = "\n",
    glue::collapse(rep("#", times = 80)),
    "##",
    "##            Protocol: {mmge::protocol_match(request_data$protocol)}",
    "##        Project Name: {request_data$project_name}",
    "##   Oncore Request ID: {request_data$oncore_request_id}",
    "## Footprints Issue ID: {request_data$number}",
    "##       Creation Date: {Sys.Date()}",
    "##",
    "## Subject: {request_data$subject}",
    "##",
    "## Description:",
    "## ------------",
    "##",
    desc,
    "##",
    glue::collapse(rep("#", times = 80))
  )
  file <- file(file.path(request_data$directory, "R", "pullsheet.R"))
  pullsheet <- glue::glue(.sep = "\n",
    "rm(list = ls())",
    "",
    libraries,
    "",
    info,
    "",
    "process_data_files()",
    "load_support_scripts()",
    "",
    "plan(multisession)",
    "query %<-% oncore_pullsheet_query()",
    "",
    "pull <- query %>%",
    "  select_distributable_aliquots() %>%",
    "  select_aliquots()",
    "",
    "aliquot <- query %>%",
    "  remove_pullable(pull) %>%",
    "  select_parent_aliquots() %>%",
    "  select_aliquots()",
    "",
    "box_design <- design_box(pull, aliquot, maximize_fullness = TRUE)",
    "",
    "wb <- build_pullsheet_wb(pull = pull, aliquot = aliquot, box_design = box_design)",
    "file_name <- save_pullsheet_workbook(wb)",
    "",
    "### Uncomment the line below to automatically send pullsheet to requestor ###",
    '#send_pullsheet(file_name, msg = "Requested pullsheet attached. See how it looks...")'
  )

  writeLines(pullsheet, file)

  close(file)

}

write_rproj <- function(request_data) {

  file <- file(file.path(request_data$directory, "R", paste0(request_data$order_name, ".Rproj")))

  writeLines(glue::glue(.sep = "\n",
    "Version: 1.0",
    "",
    "RestoreWorkspace: Default",
    "SaveWorkspace: Default",
    "AlwaysSaveHistory: Default",
    "",
    "EnableCodeIndexing: Yes",
    "UseSpacesForTab: Yes",
    "NumSpacesForTab: 2",
    "Encoding: UTF-8",
    "",
    "RnwWeave: Sweave",
    "LaTeX: pdfLaTeX"
  ), file)

  close(file)

}

write_yaml <- function(request_data) {

  kept_values <- c("number", "subject", "protocol", "project_name", "oncore_id",
                   "collection_group", "order_name", "directory", "assignees",
                   "submitter", "submitdate", "last_name", "first_name",
                   "username", "email_address", "descriptions")

  request_data <- request_data[kept_values]

  if(is.null(request_data$verbose)) {
    request_data$verbose <- TRUE
  }

  if(is.null(request_data$oncore_environment)) {
    request_data$oncore_environment <- "CLN"
  }

  if(is.null(request_data$only_available)) {
    request_data$only_available_specimens <- TRUE
  }

  protocol_settings <- mmgeProtocols::get_protocol_settings(request_data$protocol)

  for(n in names(protocol_settings)) {
    if(!n %in% request_data) {
      request_data[[n]] <- protocol_settings[[n]]
    }
  }

  file <- file(file.path(request_data$directory, "R", "config.yaml"))

  writeLines(yaml::as.yaml(request_data), file)

  close(file)

}

write_rproj_user <- function(request_data) {

  dir.create(file.path(request_data$directory, ".Rproj.user"))
  dir.create(file.path(request_data$directory, "shared"))

}