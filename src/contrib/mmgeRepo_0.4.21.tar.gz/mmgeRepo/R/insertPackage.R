#'@export
insertPackage <- function(pkg = ".", commit = NULL, increment="patch", add_all = TRUE, merge_with = NULL) {

  # Make sure `pkg` contains an R package
  if(testForPackage(pkg)) {

    # Must be on either "dev" or "master" branch
    branch <- system(glue::glue("git -C {pkg} rev-parse --abbrev-ref HEAD"), intern = TRUE)
    if(!branch %in% c("dev", "master")) {
      if(is.null(merge_with)) {
        message("You can only insert the `dev` or `master` branch. Current branch is `", branch, "`.")
        if(tolower(readline("Would you like to merge this branch before inserting? (y/N)")) %in% c('y', 'yes')) {
          merge_with <- mergeBranch(pkg)
        } else {
          stop("Update Aborted")
        }
      }
    }

    # Must provide a commit message
    if(is.null(commit)) {
      commit <- readline("Enter commit message: ")
      if(trimws(commit) == "") {
        stop("You must provide a commit message")
      }
    }

    if(confirmUpdate(pkg, increment, merge_with)) {

      update_package_date(pkg)
      update_package_version(pkg, increment)
      devtools::document(pkg)

      #Add all files to commit
      if(add_all) system(glue::glue("git -C {pkg} add -A"), wait = TRUE)

      # Commit the update
      system(glue::glue("git -C {pkg} commit -m '{commit}'"), wait = TRUE)
      system(glue::glue("git -C {pkg} push"), wait = TRUE)

      # If merge_with isn't null, merge the branch
      if(!is.null(merge_with)) {
        system(glue::glue("git -C {pkg} checkout {merge_with}"), wait = TRUE)
        system(glue::glue("git -C {pkg} merge {branch}"), wait = TRUE)
        system(glue::glue("git -C {pkg} push"), wait = TRUE)
        system(glue::glue("git -C {pkg} checkout {branch}"), wait = TRUE)
      }

    }

  }

}