#' Automatically read in xlsx and csv files
#'
#'Primarily meant to streamline pullsheet projects by automating the inclusion
#'of support data into the global environment
#'
#'@param protocol the name of the protocol
#'@param pattern A regular expression to match file names to
#'@param \dots Specific files to load from the data directory
#'
#'@export
load_protocol_data <- function(protocol, ..., pattern) {

  files_requested <- list(...)

  p <- protocol_path(protocol, "Data")

  file_ext_re <- "\\.csv$|.xlsx$|.txt$|.rda$|.rdata$|.json$|.yaml$|.yml$"

  files_present <- list.files(p, pattern = file_ext_re)
  files_present <- files_present[!grepl("^~", files_present)] # Filter out excel temp files

  if(length(files_requested) == 0 & !missing(pattern)) {
    data_files <- grep(pattern, files_present, value = TRUE)
  } else if(length(files_requested) > 0) {
    if(!missing(pattern)) {
      warning("`pattern` argument ignored when file names are passed to `load_protocol_data`", call. = FALSE)
    }

    data_files <- c()
    for(file in files_requested) {
      if(grepl(file_ext_re, file)) {
        f <- files_present[files_present == file]
      } else {
        f <- files_present[grepl(paste0("^", file), files_present)]
      }
      if(length(f) == 1) {
        data_files <- c(data_files, f)
      } else if(length(f) == 0) {
        stop("Could not associate a file with ", f, call. = FALSE)
      } else {
        stop("'", f, "' matched multiple files. Try setting the `pattern` argument if this is a desired behavior.", call. = FALSE)
      }
    }
  } else {
    stop("You must either pass file names or set `pattern` argument.", call. = FALSE)
  }

  if(length(data_files) > 0) {
    for(df in data_files) {
      vn <- gsub("_[0-9]+_[0-9]+$", "", make.names(gsub(".xlsx|.csv|.rda|.rdata|.txt|.yaml|.yml|.json", "", df)))
      fp <- file.path(p, df)
      if(grepl("csv$", df)) {
        eval(parse(text = sprintf("x <- read.csv('%s', stringsAsFactors = FALSE)", fp)))
        assign(vn, x, envir = .GlobalEnv)
      } else if(grepl("txt$", df)) {
        x <- trimws(readLines(fp))
        assign(vn, x, envir = .GlobalEnv)
      } else if(grepl("xlsx$", df)) {
        fn <- file.path(p, df)
        sheets <- openxlsx::getSheetNames(fn)
        if(length(sheets) == 1) {
          eval(parse(text = glue::glue("x <- openxlsx::read.xlsx('{fn}', sheet = 1)")))
          assign(vn, x, envir = .GlobalEnv)
        } else {
          for(sn in sheets) {
            vn <- make.names(sn)
            eval(parse(text = glue::glue("x <- openxlsx::read.xlsx('{fn}', sheet = '{sn}')")))
            assign(vn, x, envir = .GlobalEnv)
          }
        }
      } else if(grepl("rda$|rdata$", df)) {
        load(fp, envir = .GlobalEnv)
      } else if(grepl("json$", df)) {
        x <- jsonlite::fromJSON(readLines(fp))
        assign(vn, x, envir = .GlobalEnv)

      } else if(grepl("yaml$|yml$", df)) {
        x <- yaml::yaml.load_file(fp)
        assign(vn, x, envir = .GlobalEnv)

      }
    }
  } else {
    warning("No files met loading criteria...", call. = FALSE)
  }

}

#'@export
save_protocol_data <- function(..., name, format, protocol, overwrite = FALSE) {

  #mmgeProtocols::save_protocol_data(all_visits, loni_data, visit_table, visit_months, visit_arms, kit_table, build_date, name = "compliance_data.rda", protocol = "MMGE-MJFF-PPMI-BIO", overwrite = TRUE)


  protocol <- check_protocol(protocol)
  allowed_formats <- c("csv", "xlsx", "yaml", "rda", "rdata")

  data <- list(...)

  # I would bet there is a better way to do this... getting the names from the ...
  data_names <- deparse(substitute(list(...)), width.cutoff = 500)
  data_names <- gsub("^list\\(", "", data_names)
  data_names <- gsub("\\)$", "", data_names)
  data_names <- strsplit(data_names, ", ")[[1]]

  names(data) <- data_names

  if(grepl("\\..+$", name)) {
    format = regmatches(name, regexec("\\.(.+$)", name))[[1]][2]
  } else if(missing(format)) {
    stop("You must provide a file extension or a format `argument`", call. = FALSE)
  } else {
    name <- paste0(name, ".", format)
  }

  save_rda <- function(data, fp) {
    save(list = names(data), file = fp, envir = as.environment(data))
  }

  if(!format %in% allowed_formats) {
    stop('`format` or file extension must be one of: ', paste(allowed_formats, collapse = ", "), call. = FALSE)
  } else {
    fp <- file.path(protocol_path(protocol), "Data", name)
    if(file.exists(fp) & !overwrite) {
      stop(fp, " already exists and `overwrite` == FALSE", call. = FALSE)
    } else {
      switch(format,
        csv = {
          if(is.data.frame(data[[1]]) & length(data) == 1) {
            write.csv(data, file = fp, row.names = FALSE)
          } else {
            stop("`data` must be a single data.frame if `format` == 'csv'", call. = FALSE)
          }
        },
        xlsx = {
          if(length(data) > 1) {
            stop("A single data.frame or a single list of data.frames required when `format` == 'xlsx'", call. = FALSE)
          }
          data <- data[[1]]
          data2 <<- data
          if(is.list(data) & !is.data.frame(data)) {
            for(i in seq(length(data))) {
              if(!is.data.frame(data[[i]])) {
                stop("All elements of list must be data.frames if `format` == 'xlsx'", call. = FALSE)
              }
            }
          } else if(!is.data.frame(data)) {
            stop("`data` must be a data.frame or a list of data.frames if `format` == 'xlsx'", call. = FALSE)
          }

          openxlsx::write.xlsx(data, fp)

        },
        yaml = {
          if(length(data) > 1) {
            stop("Only one data structure is allowed when `format` == 'yaml'", call. = FALSE)
          }
          yaml::write_yaml(data, fp)
        },
        rda = {
          save_rda(data, fp)
        },
        rdata = {
          save_rda(data, fp)
        }
      )

    }

  }
}