#' test for existence of a protocol
#'
#' Checks for the existence of a protocol in the HG-Data drive
#'
#' @param protocol_name The name of the protocol to test
#'
#' @return \code{TRUE} if the protocol exists, otherwise \code{FALSE}
#' @export
#'
#' @examples
#'
#' protocol_exists("MMGE-MJFF-PPMI-BIO")
#'
protocol_exists <- function(protocol_name) {

  protocol_name %in% list.dirs(protocol_path(), full.names = FALSE, recursive = FALSE)

}