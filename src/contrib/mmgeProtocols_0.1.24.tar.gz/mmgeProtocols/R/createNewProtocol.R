#'@export
create_new_protocol <- function(protocol_name, protocol_email = "", manager_name = "", manager_email = "") {

  prt_dir <- file.path(getOption("protocol_root_dir"), protocol_name)

  if(dir.exists(prt_dir)) stop(protocol_name, " already has a directory.", call. = FALSE)

  dir.create(prt_dir, recursive = TRUE)

  readmes <- yaml::yaml.load_file(system.file("templates/master.yaml", package = "mmgeProtocols"))
  sub_dirs <- c("Settings", "Catalogs", "Data", "Reports", "Scripts")
  for(dir in sub_dirs) {
    dir.create(file.path(prt_dir, dir))
    readme <- glue::glue(readmes[[dir]]$readme)
    writeLines(readme, con = file.path(prt_dir, dir, "README.txt"))
  }

  settings <- glue::glue(paste(readLines(system.file("templates/settings.yaml", package = "mmgeProtocols")), collapse = "\n"))
  writeLines(settings, con = file.path(prt_dir, "Settings", "settings.yaml"))

}