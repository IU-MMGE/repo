validate_settings_file <- function(protocol) {

  value_check <- function(check, ...) {
    if(check) {
      return(NULL)
    } else {
      return(paste(..., collapse = "", sep = ""))
    }
  }

  is_numeric <- function(x) {
    suppressWarnings(!is.na(as.numeric(unlist(x))))
  }

  get_names <- function(x, l) {
    paste("    ", clisymbols::symbol$pointer, " ", names(x)[l], sep = "", collapse = "\n")
  }

  f <- get_protocol_settings(protocol)

  report <- list()

  settings <- suppressWarnings(yaml::yaml.load_file(protocol_path("protocol_settings.yaml"))$protocol_validation)

  report$missing_fields <- settings$required_fields[!settings$required_fields %in% names(f)]
  report$extra_fields <- names(f)[!names(f) %in% settings$required_fields]


  report$check <- list()

  report$check$protocol <- value_check(f$protocol == protocol,
                                       "The protocol field (", f$protocol, ") does not match the file name (", protocol, ").")
  report$check$email <- value_check(grepl("^[[:alnum:]]+@iu\\.edu$", f$email),
                                    f$email, " does not appear to be a valid IU email address.")
  report$check$manager_email <- value_check(grepl("^[[:alnum:]]+@iu\\.edu$", f$manager_email),
                                            f$manager_email, " does not appear to be a valid IU email address.")
  l <- names(f$aliquot_sizes) %in% settings$allowed_collection_groups
  report$check$valid_aliquot_sizes_names <- value_check(all(l),
                                                        "Some aliquot_sizes names are invalid:\n", get_names(f$aliquot_sizes, !l))
  l <- is_numeric(f[['aliquot_sizes']])
  report$check$numeric_aliquot_sizes <- value_check(all(l),
                                                    "Some aliquot sizes appear to be non-numeric:\n", get_names(f$aliquot_sizes, !l))
  l <- unlist(f$aliquot_sizes) > 0
  report$check$numeric_aliquot_sizes <- value_check(all(l),
                                                    "Some aliquot sizes are set to 0:\n", get_names(f$aliquot_sizes, !l))
  l <- is_numeric(f[['depletion_warning_levels']])
  report$check$numeric_depletion_warning_levels <- value_check(all(l),
                                                               "Some depletion_warning_levels appear to be non-numeric:\n", get_names(f$depletion_warning_levels, !l))
  l <- names(f$depletion_warning_levels) %in% settings$allowed_collection_groups
  report$check$valid_depletion_warning_levels_names <- value_check(all(l),
                                                                   "Some depletion_warning_levels names are invalid:\n", get_names(f$depletion_warning_levels, !l))

  report$pass <- length(report$missing_fields) == 0 && length(report$extra_fields) == 0 && length(report$check) == 0
  class(report) <- c("protocol_validation", class(report))

  return(report)

}

print.protocol_validation <- function(x) {
  suppressWarnings({
    cat_line(crayon::silver("<protocol_validation>"))
    if(x$pass) {
      cat_line(crayon::bold(crayon::green(clisymbols::symbol$tick, "Validation Successful!")))
    } else {
      cat_line(crayon::bold(crayon::red(clisymbols::symbol$cross, "Validation Failed!")))
      if(length(x$missing_fields) != 0) {
        cat_line(crayon::bold("Missing Fields:\n"), paste("  ", clisymbols::symbol$bullet, " ", x$missing_fields, sep = "", collapse = "\n"))
      }
      if(length(x$extra_fields != 0)) {
        cat_line(crayon::bold("Extra Fields:\n"), paste("  ", clisymbols::symbol$bullet, " ", x$extra_fields, sep = "", collapse = "\n"))
      }
      if(length(x$check != 0)) {
        cat_line(crayon::bold("Failed Checks:"))
        cat_line(paste("  ", clisymbols::symbol$bullet, " ", x$check, collapse = "\n", sep = ""))
      }
    }
  })
  return(x)
}
