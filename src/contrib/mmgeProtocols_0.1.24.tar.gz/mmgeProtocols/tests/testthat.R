library(testthat)
library(mmgeProtocols)

test_check("mmgeProtocols")
