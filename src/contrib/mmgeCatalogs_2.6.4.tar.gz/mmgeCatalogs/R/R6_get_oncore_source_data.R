R6_get_oncore_source_data <- function() {

  db <- debugR::debug("oncore_data")

  fields <- settings$default_fields
  filters <- list(
    PROTOCOL_NO = list(
      `in` = private$config_obj$protocol
    ),
    SPECIMEN_STATUS = list(
      `in` = "Available"
    )
  )

  if('filters' %in% names(private$config_obj$build$oncore_settings)) {
    f <- private$config_obj$build$oncore_settings$filters
    if("PROTOCOL_NO" %in% names(f)) {
      filters$PROTOCOL_NO <- f$PROTOCOL_NO
    }
    if("SPECIMEN_STATUS" %in% names(f)) {
      filters$SPECIMEN_STATUS <- f$SPECIMEN_STATUS
    }
    filters <- utils::modifyList(filters, private$config_obj$build$oncore_settings$filters)
  }

  oncore_fields <- unique(c(private$dictionary_obj$source_id[private$dictionary_obj$source == 'oncore'], private$config_obj$build$oncore_settings$fields, names(filters)))

  fields <- unique(c(fields, oncore_fields))

  # An attempt to merge multiple oncore copies, assuming the mongo will be the most up-to-date

  key <- data.frame(
    oncore_names = fields,
    r_names = oncore2:::standard_names(fields),
    mongo_names = gsub(".", "_", oncore2:::mung_column_names(fields), fixed = TRUE),
    stringsAsFactors = FALSE
  )

  mongo_fields <- key$mongo_names[key$oncore_name %in% fields]

  for(i in seq(length(filters))) {

    field <- names(filters)[i]
    filter <- filters[[i]]
    if("not" %in% names(filter)) {
      mod_not <- filter$not
      filter$not <- NULL
    } else {
      mod_not <- FALSE
    }
    names(filter) <- paste0("$", names(filter))
    if("$regex" %in% names(filter)) {
      if(!"$options" %in% names(filter)) {
        filter$`$options` = ""
      }
    }
    filter <- jsonlite::toJSON(filter, auto_unbox = !"$in" %in% names(filter))
    if(mod_not) {
      filter <- glue::glue("{{\"$not\": {filter}}}")
    }
    filters[[i]] <- glue::glue("{{\"{field}\": {filter}}}")

  }

  filters <- unname(unlist(filters))
  filters <- glue::glue("{{\"$and\": [{paste(filters, collapse = ', ')}]}}")

  query <- mmgeMongo::mongo_query(settings$mongo$database, settings$mongo$data_collection, query = filters, fields = mongo_fields)

  colnames(query) <- sapply(colnames(query), function(x) key$oncore_names[key$mongo_names == x], USE.NAMES = FALSE)

  cq <- colnames(query)
  dn <- c(private$config_obj$build$oncore_settings$fields,
          private$dictionary_obj$source_id[private$dictionary_obj$source == 'oncore'])

  if(length(dn[!dn %in% colnames(query)]) > 0) {
    stop("Required fields missing from Mongo database:\n", paste0("  ", dn[!dn %in% colnames(query)], collapse = "\n"), call. = FALSE)
  }

  if("preprocess_oncore" %in% ls(private$build_environment)) {
    query <- private$build_environment$preprocess_oncore(dplyr::ungroup(query), private$config_obj, private$dictionary_obj)
  }

  query <- dplyr::ungroup(query)

  if(nrow(query) > 0) {
    private$sources$oncore <- query
    db(glue::glue("OnCore Records: {nrow(private$sources$oncore)}"))
  } else {
    stop("Could not locate any OnCore data for the catalog.", call. = FALSE)
  }

  return(invisible(self))

}
