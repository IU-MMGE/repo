#' recode_field
#'
#' Recode an oncore field based on a lookup table. An updated version of recodeField.
#'
#'@param data a dataframe that contains a field you want to recode
#'@param field_name The name of the field you want to recode
#'@param lookup_table Optional data.frame that contains lookup values
#'@param code If supplying a custom lookup_table this is the field name that contains the encoded values
#'@param value If supplying a custom lookup_table this is the field name that contains the decoded values
#'@param category When using the default lookup_table this allows you to subset the lookup_table by categories
#'
#' This function is designed to be piped and used like dplyr functions.
#'
#'@export
recode_field <- function(data, field_name, lookup_table, code = "CODE_ID",
                        value = "DESCRIPTION", category, force_recode = FALSE) {

  if(missing(lookup_table)) lookup_table <- oncore2::lookup_table()
  if(!missing(category)) lookup_table <- lookup_table[lookup_table$CATEGORY == category, ]

  data_backup <- data

  if(any(grepl("|", x = data[[field_name]], fixed = TRUE))) {
    values <- unique(unlist(strsplit(unique(data[[field_name]]), "|", fixed = TRUE)))
  } else {
    values <- unique(data[[field_name]])
  }

  lookup_table <- lookup_table[lookup_table[[code]] %in% values, ]

  if(length(lookup_table) == 0) {
    return(data)
  }

  if(force_recode == FALSE) {
    if("CATEGORY" %in% colnames(lookup_table)) {
      if(length(unique(lookup_table$CATEGORY)) != 1) {
        return(data)
      }
    }
  }

  if(length(grep("|", data[[field_name]], fixed = TRUE)) == 0) {
    data[[field_name]] <- lookup_table[match(data[[field_name]], lookup_table[, code]), value]
  } else {
    data[[field_name]][is.na(data[[field_name]])] <- ""
    for(i in seq(nrow(lookup_table))) {
      data[[field_name]] <- gsub(pattern = lookup_table[[code]][i], replacement = lookup_table[[value]][i], data[[field_name]], fixed = TRUE)
    }

#    data[[field_name]] <- sapply(data[[field_name]], function(v) {
#      paste(lookup_table[match(strsplit(v, "|", fixed = TRUE)[[1]], lookup_table[, code]), value], collapse = "; ")
#    })
  }

  data[[field_name]][is.na(data[[field_name]])] <- data_backup[[field_name]][is.na(data[[field_name]])]

  return(data)

}

#' recodeField
#'
#' Recode an oncore field based on a lookup table
#'
#'@param data a dataframe that contains a field you want to recode
#'@param field.name The name of the field you want to recode
#'@param lookup_table Optional data.frame that contains lookup values
#'@param code If supplying a custom lookup_table this is the field name that contains the encoded values
#'@param value If supplying a custom lookup_table this is the field name that contains the decoded values
#'@param category When using the default lookup_table this allows you to subset the lookup_table by categories
#'
#' This function is designed to be piped and used like dplyr functions. Its a copy of recode_field, left for backwards compatibility
#'
#'@export
recodeField <- recode_field
