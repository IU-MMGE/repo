R6_get_dictionary <- function() {

  db <- debugR::debug('dictionary')

  dictionary <- try(yaml::yaml.load_file(file.path(self$catalog_dir, "dictionary.yaml")), silent = TRUE)
  if(inherits(dictionary, 'try-error')) {
    stop("`dictionary.yaml` in `", self$catalog_dir, "` not readable as yaml.", call. = FALSE)
  }

  set_column <- function(df = dictionary, column_name, default_value) {

    if(length(default_value) == 1) {
      default_value <- rep(default_value, times = nrow(df))
    }

    if(!column_name %in% colnames(df)) df[[column_name]] <- default_value

    df[[column_name]][is.na(df[[column_name]])] <- default_value[is.na(df[[column_name]])]

    return(df)

  }

  dictionary <- plyr::rbind.fill(lapply(dictionary, as.data.frame, stringsAsFactors = FALSE)) %>%
    dplyr::mutate(catalog_id = names(dictionary)) %>%
    set_column("include", TRUE) %>%
    set_column("required", FALSE) %>%
    set_column("calculate", TRUE) %>%
    set_column("description", "") %>%
    set_column("source", NA) %>%
    set_column("formula", NA) %>%
    set_column("priority", 10) %>%
    set_column("type", NA) %>%
    set_column("filter_type", NA) %>%
    set_column("join", .$source_id %in% private$config_obj$build$attribute_definitions[c("subject_id", "visit_id", "specimen_type")]) %>%
    set_column("default", FALSE) %>%
    set_column("filter", TRUE) %>%
    set_column("hidden", FALSE) %>%
    set_column("recode", TRUE) %>%
    set_column("sample_id", FALSE) %>%
    dplyr::mutate(source_id = ifelse(is.na(source_id), catalog_id, source_id)) %>%
    dplyr::mutate(source = ifelse(!is.na(formula) & is.na(source), "mutate", source)) %>%
    dplyr::select(catalog_id, description, source, source_id, required, include, sample_id,
                  recode, type, filter_type, join, default, filter, hidden, calculate,
                  formula, priority)


  sample_id = dictionary$catalog_id[dictionary$source == "_sample_id"]
  sample_id <- sample_id[!is.na(sample_id)]
  if(length(sample_id) == 0) {
    sample_id = dictionary$catalog_id[dictionary$sample_id]
    if(length(sample_id) == 0) {
      message("No sample id defined. Choosing first column... This will cause an error in future versions")
      sample_id = dictionary$catalog_id[1]
    } else {
      warning("Please update catalog dictionary to v3 format (sample_id source attribute should equal `_sample_id`)")
    }
  }

  if(length(sample_id) > 1) {
    message(glue::glue("Multiple sample_ids defined. Selecting {sample_id[1]}..."))
    sample_id <- sample_id[1]
  }

  dictionary$sample_id <- FALSE
  dictionary$sample_id[dictionary$catalog_id == sample_id] <- TRUE

  if(is.na(dictionary$source[dictionary$sample_id == TRUE])) {
    dictionary$source[dictionary$sample_id == TRUE] <- "sample_id"
  }

  private$dictionary_obj <- dictionary

  return(invisible(self))

}
