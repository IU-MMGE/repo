#'@export
process_catalogs <- function(dirs, fn) {

  if(missing(dirs)) {
    dirs <- get_catalog_directories()
    if(interactive()) {
      message("Found ", length(dirs), " catalog directories for processing...")
    }
  }

  catalogs <- list()

  for(i in seq(length(dirs))) {

    dir <- dirs[i]
    config <- yaml::yaml.load_file(file.path(dir, "config.yaml"))
    protocol <- config$protocol[1]
    if(grepl("Catalogs\\/(.+)", dir)) {
      catalog_name <- config$short_name
      message(crayon::white("\n\n -- Processing catalog for ", crayon::green(protocol), ":", crayon::green(catalog_name), " --"))
    } else {
      catalog_name <- NULL
      message(crayon::white("\n\n -- Processing catalog for ", crayon::green(protocol), " --"))
    }

    catalogs[[length(catalogs)+1]] <- fn(protocol, catalog_name, config, dir)

  }

  return(invisible(catalogs))

}