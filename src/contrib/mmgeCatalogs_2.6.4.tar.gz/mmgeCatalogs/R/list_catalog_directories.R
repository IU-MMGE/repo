#'@export
find_catalog_directories <- function(catalog_dir = getOption("catalog_dir")) {

  x <- list.files(catalog_dir, recursive = TRUE, full.names = TRUE)
  x <- x[grepl("Catalogs/(.*/)*(config|catalog).yaml", x)]
  x <- gsub("/(config|catalog).yaml$", "", x)

  return(x)

}

get_catalog_strings <- function(catalog_dir = getOption("catalog_dir")) {

  catalog_directories <- find_catalog_directories(catalog_dir)

  x <- gsub(catalog_dir, "", catalog_directories)
  x <- gsub("^/", "", x)
  x <- gsub("/Catalogs", "", x)
  x <- gsub("/", ".", x)

  return(x)

}

#'@export
update_catalogs <- function(catalog_dir = getOption("catalog_dir"), tesla = FALSE,
                            global = FALSE, save = TRUE, deploy = TRUE) {

  catalog_strings <- get_catalog_strings(catalog_dir)
  catalogs <- list()

  for(catalog in catalog_strings) {
    try({

      message("Building Catalog for ", catalog)
      catalog_name <- NULL

      if(grepl("\\.", catalog)) {
        x <- unlist(strsplit(catalog, split = "\\."))
        protocol = x[1]
        catalog_name = x[2]
      } else {
        protocol <- catalog
      }


      catalogs[[gsub("-", "_", catalog)]] <- mmgeCatalog$new(protocol, catalog_name = catalog_name, use_tesla_for_oncore = tesla)$build()
      if(global) .GlobalEnv[[gsub("-", "_", catalog)]] <- catalogs[[gsub("-", "_", catalog)]]
      if(save) catalogs[[gsub("-", "_", catalog)]]$save()
      if(deploy) catalogs[[gsub("-", "_", catalog)]]$deploy("connect_dev")

    })
  }
  return(catalogs)
}
