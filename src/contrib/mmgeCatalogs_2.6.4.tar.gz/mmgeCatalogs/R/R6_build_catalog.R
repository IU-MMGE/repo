R6_build_catalog <- function() {

  db <- debugR::debug('build')

  private$get_sources()
  private$recode_data()
  private$merge_data()
  private$mutate_data()
  private$finalize_catalog()

  if(interactive()) {
    message("Catalog Complete: ", nrow(self$catalog), " Records Found")
  }

  return(invisible(self))

}

