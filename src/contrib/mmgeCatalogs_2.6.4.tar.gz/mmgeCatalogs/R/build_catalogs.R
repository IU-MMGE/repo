#'@export
build_catalogs <- function(dirs, save = TRUE, deploy = FALSE, dev = TRUE, console_output = interactive(), email = c("baileye@iu.edu", "chobbick@iu.edu")) {

  catalogs <- process_catalogs(fn = function(protocol, catalog_name, config, dir) {

    suppressMessages(suppressWarnings({
      x <- try(mmgeCatalog$new(protocol = protocol, catalog_name = catalog_name), silent = TRUE)
      if(!inherits(x, 'try-error')) {
        invisible(capture.output(name <- x$config$name))
        prev_catalog_path <- mmge:::report_file_path(name, protocol = protocol,
                                         latest=TRUE, ext = '.xlsx')
        if(file.exists(prev_catalog_path)) {
          prev_catalog <- try(readxl::read_excel(prev_catalog_path, sheet = 1), silent = TRUE)
          prev_problems <- try(readxl::read_excel(prev_catalog_path, sheet = 2), silent = TRUE)
        } else {
          prev_catalog <- NULL
          prev_problems <- NULL
        }
        x <- try({x$build()}, silent = TRUE)
        catalog_name <- config$short_name
      } else {
        catalog_name <- ""
      }
      y <- list(protocol = protocol, catalog_name = config$short_name, result = x, prev_catalog = prev_catalog, prev_problems = prev_problems)
      if(!inherits(y$result, "try-error")) {
        if(nrow(y$result$catalog) > 0) {
          if(save) {s <- y$result$save(dev = dev, deploy = !dev)}
          if(deploy) {y$result$deploy(dev = dev)}
        } else {
          y$result$log("error", event = "Catalog Build", msg = "Zero-length catalog created")
        }
      } else {
        write_log(protocol = protocol, catalog = catalog_name, level = "error", event = "Catalog Build", message = y$result['message'])
      }
    }))
    if(inherits(y$result, 'try-error')) {
      message((crayon::red(clisymbols::symbol$cross, "ERROR:")), " ", protocol, " ", config$short_name)
    } else {
      records <- nrow(y$result$catalog)
      if(records > 0) {
        message((crayon::green(clisymbols::symbol$tick, "SUCCESS:")), " ", protocol, "\b:", config$short_name, "-", crayon::green("Records: ", records))
      } else {
        message(crayon::bgBlack(crayon::magenta(clisymbols::symbol$cross, "ERROR:")), " ", protocol, " - No records produced")
      }
    }

    return(y)

  })

  show_build_result(catalogs, console = console_output, dev = dev, email = email)

  return(invisible(catalogs))

}

show_build_result <- function(catalogs, console = interactive(), email = NULL, dev) {

  con <- mmgeMongo::mongo_connection("mmgeCatalogs", collection = "updateLog")

  x <-as.data.frame(matrix(unname(unlist(lapply(catalogs, function(y) {
    z <- list(
      DATE = as.character(Sys.Date()),
      PROTOCOL = y$protocol[[1]],
      CATALOG = y$catalog_name
    )
    if(inherits(y$result, 'mmgeCatalog')) {
      if(nrow(y$result$catalog) > 0) {
        z$result = "SUCCESS"
      } else {
        z$result = "FAILURE"
      }
      z$problems = nrow(y$result$problems)
      if(inherits(y$prev_problems, "data.frame")) {
        diff <- nrow(y$result$problems) - nrow(y$prev_problems)
        if(diff > 0) {
          diff <- paste0("+", diff)
        }
        z$prob_diff <- diff
      } else {
        z$prob_diff <- NA
      }
      z$count = nrow(y$result$catalog)
      if(inherits(y$prev_catalog, "data.frame")) {
        diff = nrow(y$result$catalog) - nrow(y$prev_catalog)
        if(diff > 0) {
          diff <- paste0("+", diff)
        }
        z$diff <- diff
      } else {
        z$diff = NA
      }
    } else {
      z$result = "FAILURE"
      z$problems = NA
      z$prob_diff = NA
      z$count = NA
      z$diff = NA
    }
    return(z)
    con$update(glue::glue('{{"DATE": "{z$DATE}", "PROTOCOL": "{z$PROTOCOL}", "CATALOG": "{z$CATALOG}"}}'), paste0('{"$set":', jsonlite::toJSON(z, auto_unbox = TRUE), '}'), upsert = TRUE)

  }))), ncol=8, byrow = TRUE), stringsAsFactors = FALSE)
  colnames(x) <- c("DATE", "PROTOCOL", "CATALOG", "RESULT", "PROBLEMS", "PROB_DIFF", "COUNT", "COUNT_DIFF")
  if(console) {
    console_result(x, catalogs)
  }
  if(!is.null(email)) {
    email_result(x, catalogs, dev, email)
  }

}

console_result <- function(x, catalogs) {
  message("console output temporarily disabled")
  # p_char <- max(nchar(c(x$PROTOCOL, "PROTOCOL")))
  # c_char <- max(nchar(c(x$CATALOG, "CATALOG")))
  # r_char <- max(nchar(c(x$RESULT, "RESULT")))
  # e_char <- max(c(nchar(x$PROBLEMS, allowNA = TRUE, keepNA = FALSE) + nchar(x$PROB_DIFF, allowNA = TRUE, keepNA = FALSE), nchar("PROBLEMS"))) + 2
  # l_char <- max(c(nchar(x$COUNT, allowNA = TRUE, keepNA = FALSE) + nchar(x$COUNT_DIFF, allowNA = TRUE, keepNA = FALSE), nchar("COUNT"))) + 2
  # x$PROTOCOL <- sprintf(paste0("%", p_char, "s"), x$PROTOCOL)
  # x$CATALOG <- sprintf(paste0("%", c_char, "s"), x$CATALOG)
  # x$RESULT <- paste0(fP(x$RESULT, r_char), ifelse(x$RESULT == "SUCCESS", fT(x$RESULT, color = "green"), fT(x$RESULT, bgColor = "red")))
  # x$PROBLEMS <- paste0(fP(paste0(x$PROBLEMS, "(", x$PROB_DIFF, ")"), e_char), x$PROBLEMS, "(", fT(x$PROB_DIFF, color = ifelse(x$PROB_DIFF < 0, "green", ifelse(x$PROB_DIFF > 0, "red", NULL))), ")")
  # x$COUNT <- sprintf(paste0("%", l_char, "s"), paste0(x$COUNT, "(", x$COUNT_DIFF, ")"))
  #
  # make_header <- function(header, width) {
  #   nc <- nchar(header)
  #   fs <- floor((width - nc) / 2)
  #   h <- paste0(c(header, rep(" ", times = fs)), collapse = "")
  #   sprintf(paste0("%", width, "s"), h)
  # }
  #
  # cat(make_header("PROTOCOL", p_char), " | ", make_header("CATALOG", c_char), " | ", make_header("RESULT", r_char), " | ", make_header("PROBLEMS", e_char), " | ", make_header("COUNT", l_char), "\n")
  # cat(paste(paste(rep("-", times = p_char), collapse = ""),
  #           paste(rep("-", times = c_char), collapse = ""),
  #           paste(rep("-", times = r_char), collapse = ""),
  #           paste(rep("-", times = e_char), collapse = ""),
  #           paste(rep("-", times = l_char), collapse = ""),
  #           sep = "--|--"), "\n")
  # for(r in seq(nrow(x))) {
  #   cat(x$PROTOCOL[r], " | ", x$CATALOG[r], " | ", x$RESULT[r], " | ", x$PROBLEMS[r], " | ", x$COUNT[r] , "\n")
  # }
  # cat("\n\n")
  # for(x in catalogs) {
  #   if(inherits(x$result, 'try-error')) {
  #     l <- paste0("  ", x$protocol, " - ", x$catalog_name)
  #     l <- paste(c(l, rep(" ", times = (80 - nchar(l)))), collapse = "")
  #     cat(crayon::bgWhite(crayon::blue(crayon::bold(sprintf("%80s", l)))))
  #     cat("\n", x$result, "\n\n")
  #   }
  # }
}

email_result <- function(x, catalogs, dev, email) {

  msg <- "<p>The build catalogs script has completed. Output is below:</p>"

  t <- htmltools::tags

  tbl <- x
  tbl$RESULT <- fT(tbl$RESULT, color = ifelse(tbl$RESULT == "SUCCESS", 'green', 'red'), output="html")
  tbl$PROB_DIFF <- fT(paste0("(", tbl$PROB_DIFF, ")"), color = ifelse(as.numeric(tbl$PROB_DIFF) < 0, 'green', ifelse(as.numeric(tbl$PROB_DIFF) > 0, 'red', 'black')), output="html")
  tbl$COUNT_DIFF <- fT(paste0("(", tbl$COUNT_DIFF, ")"), color = ifelse(as.numeric(tbl$COUNT_DIFF) < 0, 'red', ifelse(as.numeric(tbl$COUNT_DIFF) > 0, 'green', 'black')), output="html")


  tbl <- t$table(style = "border: solid black 1px; border-collapse: collapse",
    t$thead(
      t$th("PROTOCOL", style = "background-color: #0000AA; color: white; border: solid black 1px; padding: 10px;"),
      t$th("CATALOG", style = "background-color: #0000AA; color: white; border: solid black 1px; padding: 10px;"),
      t$th("RESULT", style = "background-color: #0000AA; color: white; border: solid black 1px; padding: 10px;"),
      t$th("PROBLEMS", colspan=2, style = "background-color: #0000AA; color: white; border: solid black 1px; padding: 10px;"),
      t$th("COUNT", colspan=2, style = "background-color: #0000AA; color: white; border: solid black 1px; padding: 10px;")
    ),
    t$tbody(
      lapply(seq(nrow(tbl)), function(i) {
        t$tr(
          t$td(tbl$PROTOCOL[i], style = "border: solid black 1px; padding: 5px 20px;"),
          t$td(tbl$CATALOG[i], style = "border: solid black 1px; padding: 5px 20px;"),
          t$td(htmltools::HTML(tbl$RESULT[i]), style="text-align: center; border: solid black 1px; padding: 5px 20px;"),
          t$td(htmltools::HTML(tbl$PROBLEMS[i]), style="text-align: right; border: solid black 1px; border-right: none; padding: 5px 1px 5px 20px; "),
          t$td(htmltools::HTML(tbl$PROB_DIFF[i]), style="text-align: left; border: solid black 1px; border-left: none; padding: 5px 20px 5px 1px;"),
          t$td(htmltools::HTML(tbl$COUNT[i]), style="text-align: right; border: solid black 1px; border-right: none; padding: 5px 1px 5px 20px;"),
          t$td(htmltools::HTML(tbl$COUNT_DIFF[i]), style="text-align: left; border: solid black 1px; border-left: none; padding: 5px 20px 5px 1px;")
        )
      })
    )
  )

  msg <- paste0(msg, as.character(tbl))

  for(catalog in catalogs) {
    if(inherits(catalog$result, 'try-error')) {
      msg <- paste0(msg, "<h3>", catalog$protocol, " - ", catalog$catalog_name, "</h3>")
      msg <- paste0(msg, "<p><pre>", catalog$result, "</pre></p>")
    }
  }

  if(dev) {
    sub <- glue::glue("mmgeCatalogs Dev Report - {Sys.Date()}")
  } else {
    sub <- glue::glue("mmgeCatalogs Report - {Sys.Date()}")
  }

  pymailr::send_email(sub, html_body = as.character(msg), to = email, from = "hgreport")

}

#formatText
fT <- Vectorize(function(x, bgcolor = NULL, color = NULL, output = "console") {

  if(output == "console") {
    if(!is.null(color)) {
      y <- try(eval(parse(text = paste0("crayon::", color, "('", x, "')"))), silent = TRUE)
      if(!inherits(y, "try-error")) {
        x <- y
      }
    }
    if(!is.null(bgcolor)) {
      bgcolor = paste0("bg", toupper(substring(bgcolor, 1,1)), substring(bgcolor, 2))
      y <- try(eval(parse(text = paste0("crayon::", bgcolor, "('", x, "')"))), silent = TRUE)
      if(!inherits(y, "try-error")) {
        x <- y
      }
    }
  } else if(output == "html") {
    styles <- c('background-color' = bgcolor, color = color)
    styles <- paste(names(styles), styles, sep = ": ", collapse = "; ")
    x <- paste0("<span style = '", styles, "'>", x, "</span>")
  }
  return(x)

})

# frontPadding
fP <- function(x, fl) {
  sapply(fl - nchar(x), function(l) {paste(rep(" ", times = l), collapse = "")})
}