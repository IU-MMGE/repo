function show_sort(v) {

  window.alert(v);

}

function initialize_options(ns) {

  $(".options-dropdown").find('input[type="checkbox"]').on('click', function(e) {
    let x = e.currentTarget;
    let p = $(x).data().purpose;
    let $t = $("#" + ns + "comp_table");
    if(p === 'style-toggle') {
      $t.toggleClass("not-" + x.value, !x.checked);
    } else if(p === 'show-dates') {
      $t.toggleClass("show-window-dates", x.checked);
    }
  });

}

$(document).ready(function() {

  $(".options-dropdown .dropdown-menu").children().on('click', function(e) {
    e.stopPropagation();
  });

});

function fit_box(box) {

  let $box = $(box);

  // Get window and content section measurements
  let total_height = window.innerHeight;
  let navbar_height = $(".navbar").height();
  let pad_top = parseInt($('section.content').css('padding-top'));
  let pad_bottom = parseInt($('section.content').css('padding-bottom'));
  let avail_height = total_height - (navbar_height + pad_top + pad_bottom);

  // Limit the fitted box to the available height;
  $box.css({'max-height': avail_height + 'px'});

  // Get the box measurements
  let box_header_height = $box.find('.box-header').height;
  let box_total_height = $box.find('.box-body').height();
  let box_body_height = avail_height - (($box.outerHeight() - $box.innerHeight()) + $box.find(".box-header").outerHeight());

  $box.find(".box-body").css({'max-height': box_body_height + "px"});

  if(box_total_height > box_body_height) {
    $box.find(".box-body").css({'overflow-y': "scroll"});
  } else {
    $box.find(".box-body").css({'overflow-y': "default"});
  }
}

function resizeAllFittedBoxes() {
  $('.fitted-box').each(function(i) {fit_box(this)});
}

$(document).ready(function() {
/*  $(document).on('shiny:value', function(event) {
    let $el = $("#" + event.target.id);
    let $fb = $el.closest(".fitted-box");
    if($fb.length > 0) {
      fit_box($fb);
    }
  });*/
  window.addEventListener("resize", resizeAllFittedBoxes);
});
