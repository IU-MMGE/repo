#'@import shiny
#'@import shinydashboard
#'@importFrom magrittr '%>%'
#'@export
magrittr::`%>%`

#'@importFrom rlang '.data'
#'@export
rlang::.data

#'@importFrom rlang ':='
#'@export
rlang::`:=`

#'@importFrom lubridate '%m-%'
#'@export
lubridate::`%m-%`

#'@importFrom lubridate '%m+%'
#'@export
lubridate::`%m+%`

.onLoad <- function(...) {

  # Create link to javascript and css files for package
  shiny::addResourcePath("ppmiverse", system.file("www", package="ppmiverse"))
  settings <- yaml::yaml.load_file(file.path("/media", "HG-Data", "MMGE-MJFF-PPMI-BIO", "Settings", "ppmiverse.yaml"))
  vct_settings <- yaml::yaml.load_file(system.file("visit_compliance_table.yaml", package="ppmiverse"))
  assign('settings', value = settings, pos = parent.env(environment()))
  assign('vct_settings', value = vct_settings, pos = parent.env(environment()))
  #Shamelessly stolen from dplyr's onLoad hook
  # op <- options()
  # op.mongo <- list(
  #   mongo.url = "mongodb://nformmgo.medgen.iupui.edu/?ssl=true",
  #   mongo.cert = openssl::read_cert(system.file("ssl/baileye.pem", package = "mmgeMongo")),
  #   mongo.key = openssl::read_key(system.file("ssl/baileye.key", package = "mmgeMongo")),
  #   mongo.ca = system.file("ssl/mmgeCA.pem", package = "mmgeMongo")
  # )
  # toset <- !(names(op.mongo) %in% names(op))
  # if (any(toset)) options(op.mongo[toset])

}

recode_fields <- function(df) {

  df <- dplyr::mutate_at(df, colnames(df), recode_field)
  return(df)

}

recode_field <- function(x) {

  id <- deparse(substitute(x))

  recode <- mmgeMongo::load_from_mongo(settings$database, 'loni_code_list', query = glue::glue('{{"ITM_NAME": "{id}"}}', fields = c("CODE", "DECODE")), verbose = FALSE)
  if(nrow(recode) > 0) {

    y <- x
    rc <- recode$DECODE
    names(rc) <- recode$CODE

    x <- suppressWarnings(dplyr::recode(x, !!!rc))

    if(sum(is.na(x)) != sum(is.na(y))) {
      warning("NAs created during recode of ", id, ". Changing back to original value.", call. = FALSE)
      x[is.na(x)] <- y[is.na(x)]
    }

  }

  return(x)

}

check_visit <- Vectorize(function(visit, arm, visit_arms) {
  #x <- visit_arms[[visit]]
  return(arm %in% names(visit_arms))
})

check_lp <- Vectorize(function(visit, arm, visit_arms) {
  x <- visit_arms[[visit]]
  if(arm %in% names(x)) {
    print(x[[arm]])
    return(x[[arm]])
  } else {
    print(FALSE)
    return(FALSE)
  }
})

get_window <- Vectorize(function(ed, td, window = c(-30, 30)) {

  if(length(ed) > 1) {
    print(ed)
  }

  if(is.na(ed)) {
    if(Sys.Date() > td + window[2]) {
      'missed'
    } else {
      'na'
    }
  } else if(ed < td + window[1]) {
    'early'
  } else if(ed > td + window[2]) {
    'late'
  } else {
    'window'
  }

})

get_csf <- Vectorize(function(csf_coll, csf_req, window) {
  if(is.na(csf_coll) & csf_req == TRUE & !(window %in% c('na', "missed"))) {
    'noform'
  } else if(is.na(csf_coll)) {
    'na'
  } else if(csf_coll == "Collected") {
    'yescsf'
  } else if(csf_coll == 'Not Attempted') {
    'nocsf'
  } else if(!is.na(csf_coll)) {
    'trycsf'
  } else {
    'na'
  }
})

get_updrs <- Vectorize(function(meduse, updrs_off, updrs_on, off_med_hrs) {

  if(is.na(meduse)) {
    'na'
  } else if(meduse == "No") {
    'na'
  } else if(is.na(updrs_off) | !updrs_on) {
    'missedupdrs'
  } else if(is.na(off_med_hrs)) {
    "badupdrs"
  } else if(off_med_hrs < 0 | off_med_hrs >= 24) {
    'badupdrs'
  } else if(off_med_hrs <= 6) {
    'shortupdrs'
  } else {
    'goodupdrs'
  }

})

get_rolling_score <- function(data, type, label) {

  if(missing(label)) {
    label <- paste0(type, "_SCORE")
  }

  get_rs <- function(current_month, cno) {

    im <- c(current_month %m-% months(1:3))
    m <- data[data$month %in% im & data$CNO == cno, ]

    s <- round(mean(m[[paste0(type, "_SCORE")]], na.rm = TRUE))

    if(is.nan(s)) s = NA

    return(s)

  }

  res <- sapply(seq(nrow(data)), function(i, data) {

    get_rs(data$month[i], data$CNO[i])

  }, data = data)

  data[[label]] <- res

  return(data)

}

get_one <- function(x) {

  id <- deparse(substitute(x))
  y <- unique(x)
  y <- y[!is.na(y)]
  if(length(y) == 0) {
    warning("No valid values found for ", id)
    y <- as(NA, Class = typeof(y))
  } else if(length(y) > 1) {
    warning("Multiple values found for same subject in ", id, " column. Taking first value.")
    y <- y[1]
  }

  return(y)

}

reduce_duplicates <- function (x)
{
  if (nrow(x) > 1) {
    for (i in seq(ncol(x))) {
      y <- unique(x[[i]])
      try({
        y <- y[!is.na(y)]
        y <- y[y != ""]
        y <- y[!is.null(y)]
      }, silent = TRUE)
      if (length(y) == 0) {
        y <- as(NA, class(x[[i]]))
      }
      if (length(y) > 1) {
        stop("Cannot reduce group to 1")
      }
      x[[i]] <- y
    }
  }
  return(x)
}