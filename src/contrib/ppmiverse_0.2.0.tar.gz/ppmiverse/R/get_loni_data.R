#'@export
get_loni_data <- function(table_list, rebuild = NULL) {

  if(missing(table_list)) {
    table_list <- settings$loni_tables
  }

  recode <- settings$recode

  updated <- unlist(mmgeMongo::load_from_mongo(settings$database, 'loni_data_date', verbose = FALSE))
  refresh <- updated < Sys.Date()
  if(length(refresh) == 0) {
    refresh <- TRUE
  } else if(!is.null(rebuild)) {
    refresh <- rebuild
  }

  if(refresh) {
    code_list <- read.csv("/media/HG-Data/MMGE-MJFF-PPMI-BIO/Data/LONI_DATA_DICTIONARY/Code_List.csv", stringsAsFactors = FALSE)
    data_dictionary <- read.csv("/media/HG-Data/MMGE-MJFF-PPMI-BIO/Data/LONI_DATA_DICTIONARY/Data_Dictionary.csv", stringsAsFactors = FALSE)

    mmgeMongo::save_to_mongo(code_list, settings$database, "loni_code_list", indices = 'ITM_NAME')
    mmgeMongo::save_to_mongo(data_dictionary, settings$database, 'loni_data_dictionary', indices = 'ITM_NAME')

  }

  loni_tables <- lapply(seq(length(table_list)), function(i) {

    table_name <- settings$loni_tables[i]
    if(refresh) {
      if(interactive()) message("Pulling `", table_name, "` from LONI...")
      data <- suppressMessages(mmge::pull_from_loni(study = settings$study, file_name = table_name, add_dates = FALSE, add_loni = FALSE))
      data <- recode_fields(data)
      mmgeMongo::save_to_mongo(data, settings$database, table_name)
      try(mmgeProtocols::save_protocol_data(data, name = file.path("LONI_DATA", paste0(table_name, ".csv")), protocol = "MMGE-MJFF-PPMI-BIO", overwrite = TRUE))
    } else {
      data <- mmgeMongo::load_from_mongo(settings$database, table_name)
    }

    return(data)

  })

  s <- settings
  s$build_date <- Sys.Date()
  mmgeMongo::save_to_mongo(s, settings$database, 'loni_data_meta')
  return(loni_tables)

}