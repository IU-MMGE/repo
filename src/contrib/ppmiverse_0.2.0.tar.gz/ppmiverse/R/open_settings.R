get_settings_location <- function(settings_location = NULL) {
  if(is.null(settings_location)) {
    settings_location <- getOption("ppmiverse.settings")
    if(is.null(settings_location)) {
      settings_location <- file.path("/media", "HG-Data", "MMGE-MJFF-PPMI-BIO", "Settings", "ppmiverse.yaml")
      if(!file.exists(settings_location)) {
        stop("Could not locate a settings file for ppmiverse...")
      }
    }
  }
  if(file.exists(settings_location)) {
    return(settings_location)
  } else {
    stop(settings_location, " does not exist")
  }
}

#'@export
load_settings <- function(settings_location = NULL) {

  settings_location <- get_settings_location(settings_location)
  settings <- yaml::yaml.load_file(settings_location)
  assign('settings', value = settings, pos = parent.env(environment()))
  message("Settings loaded from ", settings_location)

}

#'@export
open_settings <- function(settings_location = NULL) {
  if(rstudioapi::isAvailable()) {
    fp <- get_settings_location(settings_location)
    rstudioapi::navigateToFile(fp)
  } else {
    warning("This method isn't available outside RStudio")
  }
}