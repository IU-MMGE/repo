#@export
find_loni_table <- function(...) {

  fields <- list(...)
  fields <- list("PATNO", "EVENT_ID", "BLDDNA")
  tables <- read.csv("/media/HG-Data/MMGE-MJFF-PPMI-BIO/Data/LONI_DATA_DICTIONARY/Data_Dictionary.csv", stringsAsFactors = FALSE)
  matched_tables <- tables$MOD_NAME[tables$ITM_NAME == fields[1]]

  for(i in seq(2, length(fields))) {
    t <- tables$MOD_NAME[tables$ITM_NAME == fields[i]]
    matched_tables <- matched_tables[matched_tables %in% t]
  }


}