loni_data_ui <- function(id) {

  ns <- NS(id)

  tabItem(id,
    fluidRow(
      column(width = 6,
        tags$h2(style = "margin: 0;", textOutput(ns("table_title")))
      ),
      column(width = 2,
        selectInput(ns("table_name"), label = NULL, choices = settings$loni_tables)
      ),
      column(width = 2,
        selectInput(ns('fields'), NULL, choices = c(), selected = c(), multiple = TRUE)
      ),
      column(width = 1,
        actionButton(ns('dictionary'), "Dictionary", icon = icon('book'), `data-toggle` = "modal", `data-target` = "#dataDictionaryModal")
      ),
      column(width = 1,
        downloadButton(ns('download'))
      )
    ),
    DT::DTOutput(ns('table')),
    tags$div(class = "modal fade", id = "dataDictionaryModal", tabindex = "-1", role = "dialog",
      tags$div(class = "modal-dialog modal-lg", role = "document",
        tags$div(class = "modal-content",
          tags$div(class = "modal-header",
            tags$button(type = "button", class = "close", `data-dismiss` = "modal", HTML("&times;")),
            tags$h4(class = "modal-title", icon("book", class = "fa-fw fa-lg"),  "Data Dictionary")
          ),
          tags$div(class = "modal-body",
            tableOutput(ns("dataDictionary"))
          ),
          tags$div(class = "modal-footer",
            tags$button(type="button", class="btn btn-default", `data-dismiss`="modal", "Close")
          )
        )
      )
    )

  )

}

loni_data_server <- function(input, output, session) {

  values <- reactiveValues(table_title = "")

  output$table_title <- renderText({

    table_title <- ""
    if(nrow(dictionary()) > 0) {
      if("" %in% dictionary()$ITM_NAME) {
        table_title <- dictionary()$DSCR[dictionary()$ITM_NAME == ""][1]

      }
    }
    return(table_title)

  })

  loni_table <- reactive({

    print(input$table_name)
    x <- mmgeMongo::load_from_mongo(settings$database, input$table_name)
    return(x)

  })

  fields <- reactive({
    if(is.null(input$fields)) {
      return(colnames(loni_table()))
    } else {
      return(input$fields)
    }
  })

  observe({
    updateSelectInput(session, 'fields', choices = colnames(loni_table()))
  })

  selected_loni_table <- reactive({
    loni_table()[, fields(), drop = FALSE]
  })

  dictionary <- reactive({

    input$table_name

    mod <- toupper(gsub("_dates$", "", gsub("^loni_", "", input$table_name)))
    filter <- paste0('{"MOD_NAME": "', mod, '"}')
    d <- try(mmgeMongo::load_from_mongo(settings$database, 'loni_data_dictionary', query = filter), silent = TRUE)
    if(inherits(d, 'try-error')) {
      values$table_title = ""
      return(data.frame())
    }

    return(d)

  })

  output$dataDictionary <- renderTable({
    dictionary() %>%
      dplyr::filter(ITM_NAME %in% fields()) %>%
      dplyr::select(-MOD_NAME, -SEQ_NO, -CODELIST)
  })

  output$table <- DT::renderDT({

    dt <- selected_loni_table()

    DT::datatable(dt, rownames = FALSE, options = list(
      deferRender = TRUE
    ))
  })

  output$download <- downloadHandler(
    filename = function() {
      glue::glue("{input$table_name}_{mmgeMongo::load_from_mongo(settings$database, 'loni_data_meta')$build_date}.csv")
    },
    content = function(file) {
      write.csv(selected_loni_table(), file, row.names = FALSE)
    }
  )

}