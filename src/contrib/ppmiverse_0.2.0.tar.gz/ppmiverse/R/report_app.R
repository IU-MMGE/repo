report_ui <- function(id) {

  ns <- NS(id)

  tabItem(id,

    tags$h1("Hello Report")

  )

}

report_server <- function(input, output, session) {

}