subject_row_aligned <- function(subject, cno = TRUE, all_visits, visit_window, report_window) {
  empty <- 15 - subject$window_visit[[1]]
  visits <- tagList(lapply(seq(15), function(j) {
    if(j <= empty) {
      return(tags$td(class = 'empty-cell'))
    }

    v <- sprintf("V%02i", j - empty)

    targetdt <- as.Date(subject[[paste0(v, "_target")]], origin = as.Date("1970-01-01"))
    maxvisdt <- targetdt + visit_window[2]
    minvisdt <- targetdt + visit_window[1]
    eventdt <- as.Date(subject[[paste0(v, "_eventdt")]], origin = as.Date("1970-01-01"))

    av <- all_visits[all_visits$PATNO == subject$PATNO & all_visits$EVENT_ID == v, ]

    if(is.na(targetdt)) {
      tdcl = 'not-scheduled'
    } else if(minvisdt > report_window[2]) {
      tdcl = "future"
    } else if(maxvisdt >= report_window[1]) {
      tdcl = "window"
    } else if(!is.na(eventdt)) {
      tdcl = "past"
    } else {
      tdcl = 'missed'
    }

    tags$td(class = tdcl,
            tagList(
              tags$div(class = "watermark", v),
              if(tdcl == 'window') {
                tags$span(class = 'window_date', targetdt)
              } else {
                tagList(lapply(seq(length(vct_settings$icons)), function(i) {
                  if(tdcl == 'na') {
                    status = 'noview'
                  } else if(tdcl == 'missed' & vct_settings$icons[[i]]$label == "Visit Window") {
                    status = 'missed'
                  } else if(tdcl %in% c('future', 'window')) {
                    status = 'pending'
                  } else {
                    status = subject[[paste0(v, vct_settings$icons[[i]]$suffix)]]
                  }
                  if('tooltip' %in% names(vct_settings$icons[[i]])) {
                    tooltip = eval(parse(text = vct_settings$icons[[i]]$tooltip))
                  } else {
                    tooltip = NULL
                  }
                  visit_icon(vct_settings$icons[[i]]$icon, status, tooltip)
                }))
              }
            )
    )

  }))

  tags$tr(#class = trcl,
    tags$td(subject$PATNO),
    tags$td(subject$APPRDX),
    if(cno) {tags$td(subject$CNO)} else {NULL},
    visits
  )

}


subject_row <- function(subject, cno = TRUE, all_visits, visit_window, report_window) {

  visits <- tagList(lapply(sprintf("V%02i", seq(1,15)), function(v) {

    targetdt <- as.Date(subject[[paste0(v, "_target")]], origin = as.Date("1970-01-01"))
    maxvisdt <- targetdt + visit_window[2]
    minvisdt <- targetdt + visit_window[1]
    eventdt <- as.Date(subject[[paste0(v, "_eventdt")]], origin = as.Date("1970-01-01"))

    av <- all_visits[all_visits$PATNO == subject$PATNO & all_visits$EVENT_ID == v, ]

    if(is.na(targetdt)) {
      tdcl = 'not-scheduled'
    } else if(minvisdt > report_window[2]) {
      tdcl = "future"
    } else if(maxvisdt >= report_window[1]) {
      tdcl = "window"
    } else if(!is.na(eventdt)) {
      tdcl = "past"
    } else {
      tdcl = 'missed'
    }

    tags$td(class = tdcl,
            if(tdcl == 'window') {
              tags$span(class = 'window_date', targetdt)
            } else {
              tagList(lapply(seq(length(vct_settings$icons)), function(i) {
                if(tdcl == 'na') {
                  status = 'noview'
                } else if(tdcl == 'missed' & vct_settings$icons[[i]]$label == "Visit Window") {
                  status = 'missed'
                } else if(tdcl %in% c('future', 'window')) {
                  status = 'pending'
                } else {
                  status = subject[[paste0(v, vct_settings$icons[[i]]$suffix)]]
                }
                if('tooltip' %in% names(vct_settings$icons[[i]])) {
                  tooltip = eval(parse(text = vct_settings$icons[[i]]$tooltip))
                } else {
                  tooltip = NULL
                }
                visit_icon(vct_settings$icons[[i]]$icon, status, tooltip)
              }))
            }
    )

  }))

  tags$tr(#class = trcl,
    tags$td(subject$PATNO),
    tags$td(subject$APPRDX),
    if(cno) {tags$td(subject$CNO)} else {NULL},
    visits
  )

}

table_header <- function(cno) {
  tags$thead(
    tags$tr(
      tags$th("PATIENT"),
      tags$th("STUDY ARM"),
      if(cno) {tags$th("SITE")} else {NULL},
      tagList(lapply(seq(15), function(i) {tags$th(sprintf("V%02i", i))}))
    )
  )
}

table_header_aligned <- function(cno) {
  tags$thead(
    tags$tr(
      tags$th("PATIENT"),
      tags$th("STUDY ARM"),
      if(cno) {tags$th("SITE")} else {NULL},
      tagList(lapply(seq(15), function(i) {
        if(i == 15) {
          tags$th("Window Visit")
        } else {
          tags$th("")
        }
      }))
    )
  )
}

visit_icon <- function(icon, status, tooltip = NULL) {
  cl = paste(c('visit-icon', icon, status), collapse = " ")
  if(!is.null(tooltip) & status != 'noview') {
    tags$i(class = cl, `data-toggle` = "tooltip", `data-placement` = "bottom", `data-html` = TRUE, title = tooltip)
  } else {
    tags$i(class = cl)
  }
}

options_dropdown <- function(ns, title = "Options") {

  tags$div(class = 'btn-group options-dropdown',
           tags$button(class = 'btn btn-primary dropdown-toggle', type = 'button', `data-toggle` = 'dropdown', id = ns('table-options'), icon('gear'), "Options", tags$span(class = 'caret')),
           tags$div(class = 'dropdown-menu dropdown-menu-right dropdown-options',
                    tags$div(class = 'box box-solid box-primary options-box',
                             tags$div(class = 'box-header', tags$h3(class = 'box-title', title), tags$button(type = 'button', onclick = "$(this).parents('.options-dropdown').removeClass('open')", class = 'close', icon('times'), style = 'float: right')),
                             tags$div(class = 'box-body',
                                      tags$div(class = 'row', style = "width: 400px;",
                                               tags$div(class = 'col-xs-6',
                                                        tags$div(class = 'form-group',
                                                                 tags$label("Display Icons"),
                                                                 tagList(lapply(vct_settings$icons, function(i) {
                                                                   tags$div(class = 'checkbox', tags$label(tags$input(type = 'checkbox', name = ns('display_icon'), `data-purpose` = 'style-toggle', value = i$icon, checked = TRUE), tags$i(class = paste('opt-icon', 'fa', 'fa-fw', i$icon, collapse = " ")), i$label))
                                                                 }))
                                                        )
                                               ),
                                               tags$div(class = 'col-xs-6',
                                                        tags$div(class = 'form-group',
                                                                 tags$label("Display Levels"),
                                                                 tagList(lapply(seq(length(vct_settings$levels)), function(i) {
                                                                   tags$div(class = 'checkbox', tags$label(tags$input(type = 'checkbox', name = ns('display_level'), `data-purpose` = 'style-toggle', value = vct_settings$levels[[i]], checked = TRUE), tags$i(class = paste('opt-icon', 'fa', 'fa-fw', 'fa-square', vct_settings$levels[[i]], collapse = " ")), names(vct_settings$levels)[i]))
                                                                 }))
                                                        )
                                               )
                                      ),
                                      tags$div(class = 'row',
                                               tags$div(class = 'col-xs-6',
                                                        tags$div(class = 'form-group',
                                                                 tags$label("Cell Colors"),
                                                                 tagList(lapply(seq(length(vct_settings$cells)), function(i) {
                                                                   tags$div(class = 'checkbox', tags$label(tags$input(type = 'checkbox', name = ns('display_cell'), `data-purpose` = 'style-toggle', value = vct_settings$cells[[i]], checked = TRUE), tags$div(class = paste(vct_settings$cells[[i]], "legend-ex")), names(vct_settings$cells)[i]))
                                                                 }))
                                                        )
                                               ),
                                               tags$div(class = 'col-xs-6',
                                                        tags$div(class = 'form-group',
                                                                 tags$label("Other Options"),
                                                                 tags$div(class = 'checkbox', tags$label(tags$input(type = 'checkbox', id = ns('show_dates'), `data-purpose` = 'show-dates'), "Show In-Window Dates")),
                                                                 tags$div(class = 'checkbox', tags$label(tags$input(type = 'checkbox', id = ns('align_window'), `data-purpose` = 'align-visits'), "Align In-Window Visits"))
                                                        )
                                               )
                                      )
                             )
                    )
           )
  )



}

updrs_tooltip <- function(av) {
  if(nrow(av) == 0) {
    return(NULL)
  } else if(is.na(av$PDMEDYN)) {
    return(NULL)
  } else if(av$PDMEDYN == "No") {
    return(NULL)
  } else {
    last_med <- try(format(lubridate::as_datetime(paste(av$PDMEDDT, av$PDMEDTM)), "%m/%d/%Y %H:%M"))
    if(is.na(last_med)) last_med = "Not Reported"
    off_updrs <- try(format(lubridate::as_datetime(paste(av$NUPDRDT, av$NUPDRTM)), "%m/%d/%Y %H:%M"))
    if(is.na(off_updrs)) off_updrs = "Not Reported"
    off_med_dur <- av$OFF_MED_HRS
    if(is.na(off_med_dur)) {
      off_med_dur <- "Unknown"
    } else {
      off_med_dur = paste(off_med_dur, " hours")
    }
    on_updrs <- av$ON_UPDRS
    tags$table(class = 'tooltip-table updrs-table',
               tags$tr(
                 tags$td("Last Med:"),
                 tags$td(last_med)
               ),
               tags$tr(
                 tags$td("Off-Med UPDRS:"),
                 tags$td(off_updrs)
               ),
               tags$tr(
                 tags$td("Off-Med Duration:"),
                 tags$td(off_med_dur)
               ),
               tags$tr(
                 tags$td("On-Med UPDRS:"),
                 tags$td(ifelse(on_updrs, "Yes", "No"))
               )
    )
  }

}

legend <- function(rows = 1) {

  icon_table <- function(x) {

    tags$table(class = 'table table-condensed legend-table',
               tags$thead(
                 tags$tr(
                   tags$th(colspan = 2, x$label)
                 )
               ),
               tags$tbody(
                 tagList(lapply(seq(length(x$statuses)), function(j) {
                   tags$tr(
                     tags$td(visit_icon(x$icon, names(x$statuses)[j])),
                     tags$td(x$statuses[[j]])
                   )
                 }))
               )
    )

  }

  cells <- length(vct_settings$icons) + 1
  cols <- ceiling(cells / rows)

  tables <- lapply(vct_settings$icons, function(t) {
    icon_table(t)
  })
  tables[[length(tables) + 1]] <- tags$table(class = 'table table-condensed legend-table visit-legend-table',
                                             tags$thead(
                                               tags$tr(
                                                 tags$th(colspan = 2, "Visit Status")
                                               )
                                             ),
                                             tags$tbody(
                                               tags$tr(
                                                 tags$td(style = 'display: none;'),
                                                 tags$td(style = 'display: none;')
                                               ),
                                               tags$tr(
                                                 tags$td(class = 'missed'),
                                                 tags$td("Missed Visit")
                                               ),
                                               tags$tr(
                                                 tags$td(class = 'window'),
                                                 tags$td("In-Window Visit")
                                               ),
                                               tags$tr(
                                                 tags$td(class = 'future'),
                                                 tags$td("Future Visit")
                                               ),
                                               tags$tr(
                                                 tags$td(class = 'not-scheduled'),
                                                 tags$td("Not Scheduled")
                                               )
                                             )
  )

  tags$table(align = 'center',
             tagList(lapply(seq(rows), function(r) {
               tags$tr(tagList(
                 lapply(seq(cols), function(c) {
                   cell <- (r - 1) * cells + c
                   if(cell <= cells) {
                     tags$td(width = paste0(round(100/cols, 0), "%"), class = 'legend-holder', tables[[cell]])
                   } else {
                     return(NULL)
                   }
                 })
               ))
             }))
  )

}
