kit_schedule_ui <- function(id) {

  ns <- NS(id)

  months <- local({
    months <- as.Date(format(Sys.Date(), "%Y-%m-01"))
    lubridate::month(months) <- lubridate::month(months) + 2
    return(format(months, "%m-%Y"))
  })

  months <- as.Date(paste0("01-", months), format = "%d-%m-%Y")
  start_date <- min(months)
  end_date <- max(months)
  lubridate::day(end_date) <- lubridate::days_in_month(end_date)

  tabItem(id,
    shiny::tabsetPanel(
      shiny::tabPanel("Report",

        fluidRow(style="margin-top: 10px;",
          column(width = 2,
            dateRangeInput(ns('dates'), "Target Date Range", start = start_date, end = end_date, max = as.Date("2030-12-31"), min = as.Date("2010-01-01"))
          ),
          column(width = 2,
            selectInput(ns('fields'), "Fields", choices = c(), selected = c(), multiple = TRUE)
          ),
          # column(width = 3,
          #   sliderInput(ns('window'), "Window (days)", min = 0, max = 90, value = 30, step = 1)
          # ),
          column(width = 2, style="height: 100%;",
            downloadButton(ns('download'))
          ),
          column(width=2, offset=4, style = "text-align: right;",
            textOutput(ns("update_date"))
          )
        ),
        DT::DTOutput(ns('report'))
      ),
      tabPanel(title="Visits",
        uiOutput(ns('visits')),
        actionButton(ns("saveVisits"), "Save Visit Schedule", width="100%")
      )
    )
  )

}

kit_schedule_server <- function(input, output, session) {

  values <- reactiveValues(
    visits = mmgeMongo::load_from_mongo(settings$database, 'visit_schedule'),
    cohorts = c("PD", "HC", "SWEDD", "PRDRML", "GC_PD", "GC_UNAFF")
  )

  schedule <- reactive({

    sd <- input$dates[1]
    ed <- input$dates[2]

    date_range_start <- glue::glue('{{"TARGET_DATE": {{"$gte": "{as.Date(sd)}"}}}}')
    date_range_end <- glue::glue('{{"TARGET_DATE": {{"$lte": "{as.Date(ed)}"}}}}')
    filter <- glue::glue('{{"$and": [{date_range_start}, {date_range_end}]}}')

    x <- mmgeMongo::load_from_mongo(settings$database, "kit_schedule_data", query = filter)

  })

  selected_schedule <- reactive({
    schedule()[, fields(), drop = FALSE]
  })

  output$update_date <- renderText({
    d <- mmgeMongo::load_from_mongo(settings$database, "kit_schedule_meta")
    return(paste0("Last Updated: ", d$updated))
  })

  fields <- reactive({
    if(is.null(input$fields)) {
      return(colnames(schedule()))
    } else {
      return(input$fields)
    }
  })

  observe({
    updateSelectInput(session, 'fields', choices = colnames(schedule()))
  })

  output$visits <- renderUI({
    dt <- values$visits
    op <- "<table class='table table-bordered'><tr>"
    for(n in names(dt)) {
      op <- paste0(op, glue::glue("<th>{n}</th>"))
    }
    for(i in seq(nrow(dt))) {
      opts <- list("A", "B","C", "D", "E", "F")
      v <- dt$visit[i]
      r <- glue::glue("<tr><td style = 'padding: 0; width: 100px;'>{v}</td><td style = 'padding: 0; width: 100px;'>{numericInput(session$ns(paste0('when_', v)), value = dt$when[i], label=NULL, width='100%')}</td>")
      for(x in values$cohorts) {
        k <- strsplit(dt[[x]][i], "+", fixed = TRUE)[[1]]
        d <- glue::glue("<td style = 'padding: 0'>{selectInput(session$ns(paste0(x,'_',v)), label=NULL, choices=opts, selected=k, multiple=TRUE, width='100%')}</td>")
        r <- paste0(r, d)
      }
      r <- paste0(r, "</tr>")
      op <- paste0(op, r)
    }
    op <- paste0(op, "</table>")
    return(HTML(op))
  })

  output$report <- DT::renderDT({

    dt <- selected_schedule()

    DT::datatable(dt, extensions = 'Scroller', rownames = FALSE, options = list(
      deferRender = TRUE,
      scrollY = 500,
      scroller = TRUE
    ))

  })

  output$download <- downloadHandler(
    filename = function() {
      glue::glue("ppmi_kit_schedule_{input$dates[1]}-{input$dates[2]}({Sys.Date()}).csv")
    },
    content = function(file) {
      write.csv(schedule(), file, row.names = FALSE)
    }
  )

  observeEvent(input$saveVisits, {
    old <- values$visits
    new <- data.frame(stringsAsFactors = FALSE)
    for(i in seq(nrow(old))) {
      v <- old$visit[i]
      r <- list(visit = v)
      r$when <- input[[paste0("when_", v)]]
      for(x in values$cohorts) {
        r[[x]] <- paste(input[[paste0(x, "_", v)]], collapse = "+")
      }
      new <- rbind(new, r, stringsAsFactors = FALSE)
    }
    values$visits <- new
    mmgeMongo::save_to_mongo(new, settings$database, 'visit_schedule')
    kit_schedule_data()
    updateActionButton(session, "saveVisits", label = "Saved!")
  })

}