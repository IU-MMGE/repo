#'@export
kit_schedule_data <- function() {

  visits <- mmgeMongo::load_from_mongo(settings$database, 'visit_schedule')
  kit_schedule_data <- make_loni_table(settings$kit_schedule$tables)

  data <- local({

    kits_data <- tidyr::pivot_longer(visits, c(-when, -visit), names_to = "APPRDX", values_to = "KIT") %>%
      dplyr::filter(!is.na(KIT))

    data <- kit_schedule_data %>%
      dplyr::filter(!is.na(!!rlang::sym(settings$kit_schedule$enroll_date_field))) %>% # Filter out subjects with missing Start Dates
      dplyr::filter(!!rlang::sym(settings$kit_schedule$arm_code_field) != '') %>% # Filter out subjects with missing arm codes
      dplyr::left_join(kits_data, by = "APPRDX") %>% # Join all subjects to all vists with kit info
      dplyr::mutate(ENROLL_DATE = as.Date(ENROLL_DATE)) %>%
      dplyr::mutate(TARGET_DATE = (function(ed, w) {
        lubridate::month(ed) <- lubridate::month(ed) + w
        return(ed)
      })(ENROLL_DATE, when)) %>%
      dplyr::mutate(EARLIEST_DATE = TARGET_DATE - 30) %>%
      dplyr::rename(EVENT_ID = visit, MONTH = when)

    return(data)

  })

  if("mutates" %in% names(settings$kit_schedule)) {
    for(i in seq_along(settings$mutates)) {
      eval(parse(text = paste0("data <- dplyr::mutate(data, ", names(settings$mutates)[i], "=", settings$mutates[[i]], ")")))
    }
  }

  if("filters" %in% names(settings$kit_schedule)) {
    for(f in settings$kit_schedule$filters) {
      data <- dplyr::filter_(data, f)
    }
  }

  indices = intersect(colnames(data), list("PATNO", "EVENT_ID", "CNO", "ENROLL_DATE", "APPRDX"))
  y <- expand.grid(indices, indices, stringsAsFactors = FALSE)
  y <- unique(lapply(seq(nrow(y)), function(i) unique(sort(unlist(y[i, ])))))
  mmgeMongo::save_to_mongo(data, settings$database, "kit_schedule_data", indices = y)
  mmgeMongo::save_to_mongo(paste0("{\"updated\": \"", as.character(Sys.Date()), "\"}"), settings$database, "kit_schedule_meta")

}