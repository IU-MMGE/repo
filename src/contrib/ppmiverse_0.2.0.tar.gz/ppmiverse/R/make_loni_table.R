#'@export
make_loni_table <- function(table_list, loni_tables = NULL, save_as = NULL, convert_arms = TRUE) {

  tables <- lapply(seq(length(table_list)), function(i) {

    table <- table_list[[i]]

    data <- NULL
    if(!is.null(loni_tables)) {
      data <- try(loni_tables[[names(table_list)[i]]], silent = TRUE)
    }
    if(inherits(data, 'try-error')) {
      data <- NULL
    }

    if(is.null(data)) {
      data <- mmgeMongo::load_from_mongo(settings$database, names(table_list)[i])
    }

    if('filter' %in% names(table)) {
      data <- data %>% dplyr::filter_(table$filter)
    }

    if('mutate' %in% names(table)) {
      for(j in seq(length(table$mutate))) {
        data <- eval(parse(text = paste0("data %>% dplyr::mutate(", names(table$mutate)[j], " = ", table$mutate[j], ")")))
      }
    }

    if('rename' %in% names(table)) {
      for(j in seq(length(table$rename))) {
        new <- names(table$rename)[j]
        old <- table$rename[[j]]
        names(old) <- new
        data <- dplyr::rename(data, !! new := old)
      }
    }
    if('PATNO' %in% colnames(data)) {
      data <- dplyr::mutate(data, PATNO = as.character(PATNO))
    }

    data <- data %>%
      dplyr::select(!!!table$fields) %>%
      dplyr::distinct()

    dts <- grep("DT$", colnames(data))
    if(length(dts) > 0) {
      for(j in dts) {
        data[[j]][data[[j]] == ""] <- NA
        z <- try(as.Date(data[[j]]), silent = TRUE)
        if(!inherits(z, 'try-error')) {
          data[[j]] <- as.Date(data[[j]])
        } else {
          warning("Couldn't convert column `", colnames(data)[j], "` to a date")
        }
      }
    }

    return(data)

  })

  names(tables) <- names(table_list)

  table <- tables[[1]]
  if(length(tables) > 1) {
    for(i in seq(2, length(tables))) {
      t2 <- tables[[i]]
      join_by = intersect(intersect(colnames(table), colnames(t2)), c("PATNO", "EVENT_ID", "CNO"))
      if(length(join_by) > 0) {
        table <- dplyr::full_join(table, t2, by = join_by)
      } else {
        warning("Cannot join table `", names(loni_tables)[i] ,"`")
      }
    }
  }

  if(convert_arms) {
    y <- names(settings$arm_code_recode)
    names(y) <- unname(unlist(settings$arm_code_recode))
    table$COHORT <- dplyr::recode(table$COHORT, !!!y)
  }

  if(!is.null(save_as)) {
    indices = intersect(colnames(table), list("PATNO", "EVENT_ID", "CNO"))
    y <- expand.grid(indices, indices, stringsAsFactors = FALSE)
    y <- unique(lapply(seq(nrow(y)), function(i) unique(sort(unlist(y[i, ])))))
    mmgeMongo::save_to_mongo(table, settings$database, save_as, indices = y)
  }

  return(table)

}