
#'@param manifests a manifest object as created by create_manifest
#'@export
check_manifest <- function(manifest, verbose = TRUE) {

  manifest <- create_manifest("data/GU_manifest.xlsx")

  manifest <- check_pullsheet(manifest, verbose)

  manifest <- check_request(manifest, verbose)

}

get_oncore_request <- function(request_id, env = "CLN") {
  sql <- paste0("
SELECT
  r.specimen_request_id,
  wls.pcs_specimen_id,
  s.specimen_bar_code,
  s.specimen_no,
  s.specimen_status
FROM
  ONCORE.bsms_working_list_specimens wls,
  ONCORE.bsms_specimen_request r,
  ONCORE.bsms_pcs_specimen s
WHERE
  r.working_list_id = wls.working_list_id AND
  wls.pcs_specimen_id = s.pcs_specimen_id AND
  r.specimen_request_id = ", request_id)

  oncore2::queryOncore(sql, env)
}

check_request <- function(manifest, verbose) {

  mf <- do.call(rbind, manifest)
  rq <- get_oncore_request(attr(manifest, 'specimen_request_id'))
  if(verbose) {
    message("Checking manifest against OnCore Request ID: ", attr(manifest, "specimen_request_id"))
  }

  mf_missing <- rq %>%
    dplyr::anti_join(mf)

  if(nrow(mf_missing) > 0) {
    problem <- paste0("Manifest missing ", nrow(mf_missing), " SPECIMEN_BAR_CODEs found in request")
    attr(manifest, "manifest_missing") <- mf_missing
    attr(manifest, "problems") <- c(attr(manifest, "problems"), problem)
    if(verbose) message(problem)
  }

  mf_extra <- mf %>%
    dplyr::anti_join(rq)

  if(nrow(mf_extra) > 0) {
    problem <- paste0("Manifest contains ", nrow(mf_extra), " SPECIMEN_BAR_CODEs not found in request")
    attr(manifest, "manifest_extra") <- mf_extra
    attr(manifest, "problems") <- c(attr(manifest, "problems"), problem)
    if(verbose) message(problem)
  }

}

check_pullsheet <- function(manifest, verbose) {

  ps <- attr(manifest, "pullsheet")
  mf <- do.call(rbind, manifest)

  if(nrow(mf) != nrow(ps)) {
    problem <- paste0("Record Count Mismatch: (Manifest: ", nrow(mf), "; Pullsheet: ", nrow(ps), ")")
    if(verbose) message(problem)
    attr(manifest, "problems") <- c(attr(manifest, "problems"), problem)

    mf_missing <- ps %>%
      dplyr::anti_join(mf)

    if(nrow(mf_missing) > 0) {
      problem <- paste0("Manifest missing ", nrow(mf_missing), " SPECIMEN_BAR_CODEs found in pullsheet")
      attr(manifest, "manifest_missing") <- mf_missing
      attr(manifest, "problems") <- c(attr(manifest, "problems"), problem)
      if(verbose) message(problem)
    }

    mf_extra <- mf %>%
      dplyr::anti_join(ps)

    if(nrow(mf_extra) > 0) {
      problem <- paste0("Manifest contains ", nrow(mf_extra), " SPECIMEN_BAR_CODEs not found in pullsheet")
      attr(manifest, "manifest_extra") <- mf_extra
      attr(manifest, "problems") <- c(attr(manifest, "problems"), problem)
      if(verbose) message(problem)
    }


    attr(manifest, "manifest_extra") <- mf %>%
      dplyr::anti_join(ps)

  } else {
    if(verbose) {
      message("Manifest and Pullsheet in agreement")
    }
  }

  return(manifest)

}
