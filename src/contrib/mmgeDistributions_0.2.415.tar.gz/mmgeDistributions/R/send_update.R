#'@export
send_update <- function(msg, attachments = NULL) {

  config <- get_pullsheet_config()

  subject <- paste0(config$subject, " ISSUE=", config$number, " PROJ=161")

  if(!is.null(attachments)) {
    if(is.null(names(attachments))) names(attachments) <- rep("", times = length(attachments))
    for(i in seq_along(attachments)) {
      if(is.data.frame(attachments[[i]])) {
        td <- tempdir()
        if(names(attachments)[i] == "") {
          n <- deparse(substitute(attachments[[i]]))
        }
        fn <- sprintf()
      }
    }
  }

  mmge::send_email(subject, msg, "mmgehelp@iu.edu", "hgreport", attachments = attachments)

}