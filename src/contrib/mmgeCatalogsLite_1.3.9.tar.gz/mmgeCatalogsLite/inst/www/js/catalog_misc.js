function prettyNumber(x) {
  var parts = x.toString().split(".");
  parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return parts.join(".");
}


columnControlBinding = new Shiny.InputBinding();
$.extend(columnControlBinding, {
  find: function(scope) {
    return $(scope).find(".catalog-control");
  },
  getValue: function(el) {

    var $el = $(el);
    var id = $el.attr("id");
    var value = {};
    value.filter = Shiny.shinyapp.$inputValues[id + "_filter"];
    value.remove_missing = Shiny.shinyapp.$inputValues[id + "_missing"];
    value.filter_type = $el.data("filter_type");
    value.filter_visible = $el.find(".collapse").hasClass("in");
    value.column_visible = Shiny.shinyapp.$inputValues[id + "_show"];
    value.column_name = $el.data("column");
    return value;

  },
  setValue: function(el, value) {

    var $el = $(el);
    var id = $el.attr("id");

  },
  subscribe: function(el, callback) {

    let $el = $(el);
    let control = new mmgeControl($el.attr("id"));
    $el.data("control", control);

    //  window.catalog.controls[$el.data('column')] = control;

    $el.on("catalogChange", function(e, binding, bindingType) {
      callback();
    });

    $el.find(".collapse").on("shown.bs.collapse, hidden.bs.collapse", function(e) {
      callback();
    });

  }
});
Shiny.inputBindings.register(columnControlBinding);
