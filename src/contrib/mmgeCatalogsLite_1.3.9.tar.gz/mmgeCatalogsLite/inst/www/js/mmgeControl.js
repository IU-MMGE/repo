class mmgeControl {

  constructor(controlId) {

    this.id = controlId;
    this.control = $("#" + controlId);
    this.columnName = this.control.data("column");
    this.filterType = this.control.data("filter_type");
    this.inputBinding = this.control.data("shinyInputBinding");

    //helper function for binding all the control elements
    let initializeControl = (selector, event, handler) => {
      let el = this.control.find(selector);
      el.on(event, $.proxy(handler, this));
      return el;
    };

    this.visibilityControl = initializeControl(
      "#" + controlId + "_show",
      "click",
      this.toggleColumnVisibility
    );
    this.filterControl = this.control.find("#" + controlId + "_filter");
    this.missingControl = initializeControl(
      "#" + controlId + "_missing",
      "change",
      $.proxy(this.sendSearchFilter, this)
    );
    this.filterToggle = initializeControl(
      ".filter-toggle",
      "click",
      this.toggleShowFilter
    );
    this.filterReset = initializeControl(
      " .filter-reset",
      "click",
      this.resetFilter
    );
    this.filter = Shiny.shinyapp.$inputValues[controlId];

    // Get the shiny input binding for the filter element
    if(this.filterControl.data("shinyInputBinding") === undefined) {
      let that = this;
      this.filterControl.on("shiny:bound", function(binding, bindingType) {
        mmgeControl.bindFilter(binding.binding, this, that);
      });
    } else {
      mmgeControl.bindFilter(this.filterControl.data("shinyInputBinding"), this.control[0]);
    }

  }

  get catalog() {
    try {
      return window.catalog;
    } catch(err) {
      return false;
    }
  }

  get column() {
    try {
      return this.catalog.table.datatable.column(this.columnName + ":name");
    } catch(err) {
      return false;
    }
  }

  get isDefault() {
    let s;
    if(this.filterType == "slider") {
      s = this.filterControl.data("ionRangeSlider");
      return s.result.from == s.options.min && s.result.to == s.options.max && !this.missingControl.is(":checked");
    } else if(this.filterType == "select") {
      s = this.filterControl.data("selectize");
      return s.items.length === 0 && !this.missingControl.is(":checked");
    } else {
      return this.filterControl.data("shinyInputBinding").getValue(this.filterControl[0]) === "" && !this.missingControl.is(":checked");
    }
  }

  trigger(event, data) {
    $(this.control).trigger(event, data);
  }

  on(event, handler) {
    $(this.control).on(event, $.proxy(handler, this));
  }

  toggleColumnVisibility(visible) {
    visible = (typeof visible === 'boolean') ? visible : this.visibilityControl.is(":checked");
    if(this.column) {
      this.column.visible(visible);
      this.trigger("catalogChange");
    }
  }

  sendSearchFilter() {
    if(this.filterControl.data("shinyInputBinding")) {
      let data = JSON.stringify({
        "filter": this.filterControl.data("shinyInputBinding").getValue(this.filterControl[0]),
        "type": this.filterType,
        "filter_missing": this.missingControl.is(":checked")
      });
      if(typeof this.column === "object") {
        this.column.search(data);
        this.trigger("search", {
          "control": this,
          "data": data
        });
        this.checkFilter();
      }
    }
  }

  checkFilter() {
    if(this.isDefault) {
      this.filterReset.addClass("hidden");
    } else {
      this.filterReset.removeClass("hidden");
    }
  }

  resetFilter() {

    switch(this.filterType) {
      case "slider":
        let slider = this.filterControl.data("ionRangeSlider");
        slider.update({
          from: slider.options.min,
          to: slider.options.max
        });
        break;
      case "select":
        this.filterControl.data("selectize").clear();
        break;
      default:
        this.filterControl.data("shinyInputBinding").setValue(this.filterControl[0], "");

    }

    this.missingControl.prop("checked", false);
    this.filterControl.trigger("change");

  }

  static bindFilter(binding, el, control) {
    binding.subscribe(el, () => {
      control.filter = binding.getValue(el);
      control.sendSearchFilter();
    });
  }

}
