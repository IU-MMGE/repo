class mmgeCatalog {

  constructor(tableId) {

    this.tableId = tableId;
    this.table = new mmgeTable(tableId);
    this.controls = {};

//    $(this.tableId).one("shiny:bound", function() {
//      mmgeCatalog.initialize(tableId);
//    });

    this.table.on("update", (type, table, originalEvent) => {
      this.updateHeight();
      this.updateFooter();
      this.updateHeader();
    });

    $("#columnControlFilterSearch").on("keyup", this.filterFilters);

    $("#dataDictionaryModal").on("shown.bs.modal", () => {
      setTimeout(() => {
        $('[data-toggle="popover"]').popover({
          sanitize: false,
          placement: "left"
        });
      }, 300);
    });

  }

  filterFilters() {
    var re = new RegExp($("#columnControlFilterSearch").val(), "i");
    $(".catalog-control").each(function(i) {
      $(this).toggleClass("hidden", $(this).data("column").match(re) === null);
    });
  }

  updateHeader() {
    $("#download_selected").parent().toggleClass("disabled", this.table.count === 0);
  }

  updateFooter() {
    let message = "Displaying " + prettyNumber(this.table.stats.recordsDisplay) + " records";
    if(this.table.stats.recordsDisplay !== this.table.stats.recordsTotal) {
      message = message + " filtered from " + prettyNumber(this.table.stats.recordsTotal) + " total";
    }
    message = message + " (" + prettyNumber(this.table.stats.recordsSelected) + " Selected)";
    $(".table-info").text(message);
  }

  updateHeight() {
    let windowHeight = window.innerHeight | 0,
        headerHeight = $(".main-header").height() | 0,
        footerHeight = $(".table-footer").height() | 0,
        filterHeight = ($("#columnControlFilter").height() | 0) + 20,
        scrollHeight = $(".dataTables_scrollHead").height() | 0;

    let h =  windowHeight - (headerHeight + footerHeight + scrollHeight),
        h2 = windowHeight - (headerHeight + filterHeight);

    $("#" + this.tableId + " .dataTables_scrollBody").css("height", h + "px");
    $("#menu").css("height", h2 + "px");
  }

  setCatalogColor(color) {
    $("body").removeClass(function (index, className) {
      return (className.match (/(^|\s)skin-\S+/g) || []).join(' ');
    }).addClass("skin-" + color);
  }

  static drawCallback(settings) {
    if(window.catalog !== undefined) {
      let table = window.catalog.table.datatable,
          selected_rows = table.rows(table.mmgeTable.selectedRows);

      selected_rows.iterator('row', (context, index) => {
        context.aoData[index]._select_selected = true;
      });

      $(table.rows().nodes()).removeClass("selected");
      $(selected_rows.nodes()).addClass("selected");
      window.catalog.updateHeight();
    }
  }

  static initComplete(settings, json) {

    $("#helpModal .help-tab").on("click", function(e) {
      $("#helpModal .help-page").removeClass("shown");
      $($(this).data("target")).addClass("shown");
      $("#helpModal .help-tab").parent().removeClass("active");
      $(this).parent().addClass("active");
    });

    window.catalog = new mmgeCatalog("catalogTable");
    window.catalog.updateHeight();
    window.catalog.updateFooter();
    $(window).resize($.proxy(window.catalog.table.draw, window.catalog.table));

  }

}
