#creates the UI for the join modal for the shiny app
joinModal <- function() {

  tags$div(class = "modal fade", id = "joinModal", tabindex = "-1", role = "dialog",
           tags$div(class = "modal-dialog modal-sm", role = "document",
                    tags$div(class = "modal-content",
                             tags$div(class = "modal-header",
                                      tags$button(type = "button", class = "close", `data-dismiss` = "modal", HTML("&times;")),
                                      tags$h4(class = "modal-title", icon("compress", class = "fa-fw fa-lg"), "Join External Data")
                             ),
                             tags$div(class = "modal-body",
                                      tags$p("Select files to join to the catalog. Once joined you can filter results based on the new data"),
                                      tags$p(tags$b("Note:"), "You can choose to upload and join multiple files but they all must be selected at the same time. Once one join operation has been performed, this option will be deactivated."),
                                      fileInput("file_upload", NULL, multiple = TRUE, width = "100%")
                             ),
                             tags$div(class = "modal-footer",
                                      tags$button(type="button", class="btn btn-default", `data-dismiss`="modal", "Close")
                             )
                    )
           )
  )

}