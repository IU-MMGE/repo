#'@export
mmgeCatalog <- R6::R6Class("mmgeCatalog",
  public = list(
    protocol = NULL,
    catalog_name = NULL,
    catalog_dir = NULL,
    protocol_dir = NULL,
    env = NULL,
    view = function() {
      if(rstudioapi::isAvailable()) {
        if(!is.null(private$last_update)) {
          View(private$catalog_obj, title = private$config_obj$name)
        } else {
          warning("The catalog isn't available. Run the `build` method before using `view`.")
        }
      } else {
        warning("This method isn't available outside RStudio.")
      }
      return(invisible(self))
    },
    initialize = R6_initialize_catalog_object,
    deploy = R6_deploy_catalog,
    get = R6_get_catalog,
    display = R6_display_catalog,
    log = R6_log_event
  ),
  active = list(
    catalog = function(value) {
      if(missing(value)) {
        if(is.null(private$last_update)) {
          self$get()
        }
        return(private$catalog_obj)
      }
    }
  ),
  private = list(
    config_obj = NULL,
    dictionary_obj = NULL,
    catalog_obj = NULL,
    last_update = NULL,
    catalog_ui = R6_catalog_ui,
    catalog_server = R6_catalog_server,
    catalogHeader = R6_catalogHeader,
    catalogSidebar = R6_catalogSidebar,
    catalogBody = R6_catalogBody
  )
)