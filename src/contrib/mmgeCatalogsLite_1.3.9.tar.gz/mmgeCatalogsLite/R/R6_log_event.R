R6_log_event <- function(level = 'info', user = unname(Sys.info()['user']), event, msg = "") {

  write_log(
    protocol = self$protocol[1],
    catalog  = private$config_obj$short_name,
    level    = level,
    user     = user,
    event    = event,
    message  = msg
  )

  return(invisible(self))

}