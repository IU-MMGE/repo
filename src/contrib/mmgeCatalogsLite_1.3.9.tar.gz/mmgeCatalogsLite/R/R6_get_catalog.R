R6_get_catalog <- function() {

  for(data_type in c("catalog", "dictionary", "config")) {

    m <- mmgeMongo::mongo_connection(
      database = "mmgeCatalogs",
      collection = collection(data_type, self = self)
    )

    if(data_type == 'config') {
      data <- jsonlite::fromJSON(m$iterate("{}")$json())
      data$last_update <- mmgeMongo::load_from_mongo("mmgeCatalogs", "query_data")$start_time
    } else if(data_type == "catalog") {
      data <- try(m$find("{}"))
    } else {
      data <- try(m$find("{}"))
    }

    private[[paste0(data_type, "_obj")]] <- data

  }

  field_order <- private$dictionary_obj$catalog_id
  field_order <- field_order[private$dictionary_obj$include == TRUE && private$dictionary_obj$hidden == FALSE]
  private$catalog_obj <- private$catalog_obj[, field_order[field_order %in% colnames(private$catalog_obj)]]
  private$dictionary_obj <- private$dictionary_obj[private$dictionary_obj$catalog_id %in% colnames(private$catalog_obj), ]

  private$last_update <- private$config_obj$last_update

  # Create a 'type' column in dictionary if it doesn't exist.
  # If no types were declared during catalog creation this doesn't get saved
  # to mongo.
  if(!'type' %in% colnames(private$dictionary_obj)) {
    private$dictionary_obj$type <- NA
  }

  if(private$config_obj$display$allow_joins == TRUE) {
    if(sum(private$dictionary_obj$join) == 0) {
      message("`allow_joins` == TRUE but no join fields declared in dictionary. Disabling joins...")
      private$config_obj$display$allow_joins = FALSE
    }
  }

  return(invisible(self))

}

collection <- function(name, protocol, catalog_name, dev, self) {

  if(missing(dev)) {
    env <- get_env()
    dev = env %in% c("STG", "DEV")
  }

  if(!missing(self)) {
    protocol <- self$protocol[1]
    catalog_name <- self$catalog_name
  }

  if(dev) {
    paste(protocol, catalog_name, name, "dev", sep = "_")
  } else {
    paste(protocol, catalog_name, name, sep = "_")
  }

}


