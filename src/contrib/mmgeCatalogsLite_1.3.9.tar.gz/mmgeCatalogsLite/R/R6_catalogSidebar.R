#Function that builds the UI for the Sidebar of the shiny application
R6_catalogSidebar <- function() {
  htmltools::attachDependencies(shinydashboard::dashboardSidebar(
    width = private$config_obj$display$sidebar_width,
    tags$div(`data-display-if`='output.enabled==true', class = "input-group", id = "columnControlFilter",
             tags$input(type = "text", class = "form-control", placeholder = "Column Filter Search", id = "columnControlFilterSearch"),
             tags$span(class = "input-group-btn",
                       tags$button(class = "btn btn-default", type = "button", icon("undo", class = "fa-fw"), onclick="$('#columnControlFilterSearch').val('').trigger('keyup')")
             )
    ),
    tags$div(`data-display-if`="output.enabled == true", shinydashboard::sidebarMenuOutput("menu"))
  ), mmgeCatalogsDep)
}