R6_add_alert <- function(alert) {

  if(is.null(alert)) {
    return(tags$script("var special_alerts = [];"))
  }

  if(!any(c('title', 'message') %in% names(alert))) {
    warning("Every alert must have a `title` or a `message`. Dropping alert #", i,"...", call. = FALSE)
    return(NULL)
  } else {
    alert['message'] <- shiny::HTML(alert['message'])
    if('id' %in% names(alert)) {
      id = alert['id']
    } else if('title' %in% names(alert)) {
      id = alert['title']
    } else {
      id = alert['message']
    }
    alert['id'] <- gsub("=", "", base64enc::base64encode(charToRaw(git2r::hash(id))))
    if(!'expires' %in% names(alert)) {
      alert['expires'] <- "2100-01-01"
    }
    alert['expires'] <- format(as.Date(alert['expires']), "%Y-%m-%d")
    if(!"type" %in% names(alert)) {
      alert['type'] <- 'info'
    }
    if(!alert['type'] %in% c("info", "success", "warning", "danger")) {
      warning("alert type:", alert['type'], " not a valid alert type. Defaulting to 'info'.", call. = FALSE)
      alert['type'] <- 'info'
    }
    json_alert <- jsonlite::toJSON(as.list(alert), auto_unbox = TRUE, pretty = TRUE)

    return(tags$script(glue::glue("var special_alert = {json_alert};")))
  }



}