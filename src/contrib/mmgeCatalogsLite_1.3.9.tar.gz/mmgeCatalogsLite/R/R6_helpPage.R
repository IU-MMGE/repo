# Builds the UI for a single help modal page
R6_helpPage <- function(name, config, shown = FALSE) {

  default_help_dir <- system.file("help", package="mmgeCatalogsLite")
  custom_help_dir <- file.path(config$catalog_dir, "help")

  help_file <- NULL

  if(file.exists(sprintf("%s/%s.md", default_help_dir, name))) {
    help_file <- sprintf("%s/%s.md", default_help_dir, name)
  }

  if(dir.exists(custom_help_dir)) {
    if(file.exists(sprintf("%s/%s.md", custom_help_dir, name))) {
      help_file <- sprintf("%s/%s.md", custom_help_dir, name)
    }
  }

  if(is.null(help_file)) {
    stop("could not locate help file for ", name)
  }

  tags$div(id = sprintf("%sHelp", name), class = if(shown) {"help-page shown"} else {"help-page"}, HTML(markdown::markdownToHTML(help_file, fragment.only = TRUE)))

}