#function that builds the UI for the header of the shiny application
R6_catalogHeader <- function() {

  if(!is.null(private$config_obj$display$logo_file)) {
    logo <- file.path("catalogData", private$config_obj$displa$logo_file)
  } else {
    logo <- NULL
  }
  dH <- shinydashboard::dashboardHeader(title = private$config_obj$name, titleWidth = 350, disable = FALSE)

  if(!is.null(logo)) dH$children[[2]] <- tags$span(class = "logo", tags$img(src = 'logo.png'))

  dH$children[[3]]$children[[2]] <- NULL

  dH$children[[3]]$children[[2]] <- tags$div(class = "navbar-custom-menu", style = "float: left;",
                                             tags$ul(class = "nav navbar-nav",
                                                     if(private$config_obj$display$allow_dictionary) {tags$li(`data-display-if`='output.enabled==true', id = "dictionaryButton", tags$a(href = "#", icon("book", class = "fa-fw"), "Dictionary", `data-toggle` = "modal", `data-target` = "#dataDictionaryModal"))},
                                                     if(private$config_obj$display$allow_joins) {tags$li(`data-display-if`='output.enabled==true', id = "joinButton", tags$a(href = "#", icon("compress", class = "fa-fw"), "Join Data", `data-toggle` = "modal", `data-target` = "#joinModal"))},
                                                     if(private$config_obj$display$allow_orders) {tags$li(`data-display-if`='output.enabled==true', id = "selectionButton", class = "dropdown",
                                                                                                      tags$a(href = "#", class = "dropdown-toggle", `data-toggle` = "dropdown", role = "button", icon("mouse-pointer", class = "fa-fw"), "Selection", tags$span(class = "caret")),
                                                                                                      tags$ul(class = "dropdown-menu",
                                                                                                              tags$li(tags$a(id = "selectAll", href = "#", onClick = "window.catalog.table.selectAll()", "Select All")),
                                                                                                              tags$li(tags$a(id = "selectNone", href = "#", onClick = "window.catalog.table.selectNone()", "Select None")),
                                                                                                              tags$li(tags$a(id = "selectInverse", href = "#", onClick = "window.catalog.table.selectInvert()", "Invert Selection")),
                                                                                                              tags$li(tags$a(id = "clearSelection", href = "#", onClick = "window.catalog.table.clearSelection()", "Clear All Selections"))
                                                                                                      )
                                                     )},
                                                     if(private$config_obj$display$allow_orders) {tags$li(`data-display-if`='output.enabled==true', id = "downloadButton", class = "dropdown",
                                                                                                      tags$a(href = "#", class = "dropdown-toggle", `data-toggle` = "dropdown", role = "button", icon("download", class = "fa-fw"), "Download", tags$span(class = "caret")),
                                                                                                      tags$ul(class = "dropdown-menu",
                                                                                                              tags$li(tags$a(href = "", id = "download_all", target = "_blank", class = "shiny-download-link", download = NA, "Download All")),
                                                                                                              tags$li(tags$a(href = "", id = "download_filtered", target = "_blank", class = "shiny-download-link", download = NA, "Download Filtered")),
                                                                                                              tags$li(class = 'disabled', tags$a(href = "", id = "download_selected", target = "_blank", class = "shiny-download-link", download = NA, "Download Selected"))
                                                                                                      )
                                                     )},
                               #                      tags$li(id = "bookmarkButton", tags$a(href = "#", icon("bookmark", class = 'fa-fw'), "Save State")),
                                                     tags$li(`data-display-if`='output.enabled==true', id = "helpButton", tags$a(href = "#", icon("question-circle", class = "fa-fw"), "Help", `data-toggle` = "modal", `data-target` = "#helpModal")),
                               #                      tags$li(`data-display-if`='output.enabled==true', id = "tourButton", tags$a(href = "#", icon("car", class = "fa-fw"), "Tour")),
                                                     tags$li(id = "settingsButton", `data-display-if`="output.internalUser", tags$a(href = "#", icon("wrench", class = 'fa-fw'), "Settings", `data-toggle`='modal', `data-target`='#settingsModal')),
                                                     tags$li(id = "logsButton", `data-display-if`="output.internalUser", tags$a(href = "#", icon("clipboard-list", class = 'fa-fw'), "Logs", `data-toggle`='modal', `data-target`='#logsModal'))

                                             )
  )

  dH$children[[3]]$children[[3]] <- tags$p(class="navbar-text navbar-right", "Signed in as", textOutput("user", container = span), a(icon("sign-out"), "Logout", href="__logout__"))

  return(htmltools::attachDependencies(dH, mmgeCatalogsDep))

}
