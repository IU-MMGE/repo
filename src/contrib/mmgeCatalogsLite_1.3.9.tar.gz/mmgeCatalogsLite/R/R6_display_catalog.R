R6_display_catalog <- function(...) {

  options = list(...)
  if(any(is.null(c(private$dictionary_obj, private$config_obj, private$catalog_obj)))) {
    message("Getting the most recent saved catalog data")
    self$get_catalog()
  }

  if(inherits(try(options(shiny.minified = self$env == "PRD")), "try-error")) {
    warning("Have you set the `catalog_environment` option at the server? Setting to `STG`")
    self$env <- "STG"
    options(catalog_environment = "STG", shiny.minified = FALSE)
  }

  if(self$env == "DEV") {
    if(!"port" %in% names(options)) {
      p <- sample.int(5000, 1) + 3000
      message("Assigning random port: ", p)
      options$port <- sample.int(5000, 1) + 3000;
    }
    orig_wd <- getwd()
    setwd(self$catalog_dir)
    on.exit(setwd(orig_wd))
  }

  ui = private$catalog_ui(private)
  server = private$catalog_server

  if(dir.exists(file.path(self$catalog_dir, "www", "images"))) {
    addResourcePath("images", file.path(self$catalog_dir, "www", "images"))
  }
  shiny::shinyApp(ui = ui, server = server, options = options)

}