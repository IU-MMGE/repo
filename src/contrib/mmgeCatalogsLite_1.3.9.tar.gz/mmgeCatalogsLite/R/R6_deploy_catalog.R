R6_deploy_catalog <- function(dev = TRUE) {

  if(dev) {
    env = "DEV"
    where = "connect_dev"
  } else {
    env = "PRD"
    where = "connect_prd"
  }

  td <- file.path(tempdir(), self$protocol[1], self$catalog_name)
  dir.create(td, recursive = TRUE)

  transfer_dirs <- c("www", 'help')

  for(dir in transfer_dirs) {
    if(dir %in% list.files(self$catalog_dir)) {
      file.copy(file.path(self$catalog_dir, dir), file.path(td), recursive = TRUE)
    }
  }

  config <- list(
    protocol = self$protocol[1],
    catalog_name = self$catalog_name,
    short_name = private$config_obj$short_name,
    version = private$config_obj$version
  )

  yaml::write_yaml(config, file = file.path(td, "config.yaml"))

  app <- glue::glue(.sep = "\n",
    "options(catalog_env='{env}')",
    "Sys.setenv(catalog_env=\"{env}\")",
    "library(mmgeCatalogsLite)",
    "x <- mmgeCatalog$new()",
    "x$display()\n"
  )

  writeLines(app, con = file.path(td, "app.R"))

  try(mmgeLDAP::create_application("Catalog", config$short_name), silent = TRUE)

  print(td)

  x <- try(rsconnect::deployApp(td, appName = glue::glue("{config$short_name}_Catalog"), server = where, account = Sys.info()['user']), silent = TRUE)

  if(inherits(x, 'try-error')) {
    l <- 'error'
    e <- x['message'][1]
  } else {
    l <- 'info'
    e <- ""
  }

  self$log(level = l, event = 'Deploy Catalog', msg = e)

  return(invisible(self))

}