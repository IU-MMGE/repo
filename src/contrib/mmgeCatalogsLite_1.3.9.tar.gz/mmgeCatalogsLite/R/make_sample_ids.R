make_sample_ids <- function(catalog, field, grouping) {

  # x <- catalog[ ,grouping]
  #
  # y <- lapply(grouping, function(g) {
  #   v <- sort(unique(catalog[[g]]))
  #   l <- 1
  #   s <- toupper(substr(v, 1, l))
  #   while(length(unique(s)) != length(s)) {
  #     l <- l + 1
  #     s <- substr(v, 1, l)
  #   }
  #   names(s) <- v
  #   return(s)
  # })
  # names(y) <- grouping
  #
  # ids <-

  catalog[[field]] <- 100000 + sample.int(n = 899999, size = nrow(catalog))

  return(catalog)

}