# Helper function that processes a file that needs to be joined to the catalog
processJoin <- function(file_name, file_path, date.formats = c("%Y-%m-%d", "%m/%d/%Y", "%Y/%m/%d"), config) {

  read_fn_name <- config$display$join_readers[[tools::file_ext(file_name)]]

  if(!is.null(read_fn_name)) {

    read_fn <- eval(parse(text = read_fn_name))

    saf <- default.stringsAsFactors()

    options(stringsAsFactors = FALSE)

    tf <- read_fn(file_path)

    options(stringsAsFactors = saf)

    for(i in seq(ncol(tf))) {
      x <- tf[, i]
      if(!is.character(x) | is.factor(x)) next
      if(all(is.na(x))) next
      for(f in date.formats) {
        complete.x <- !is.na(x) & x != ""
        d <- as.Date(lubridate::parse_date_time(as.character(x), f, quiet = TRUE))
        d.na <- d[complete.x]
        if(any(is.na(d.na))) next
        tf[, i] <- d
      }
    }

  } else {
    tf <- NULL
  }

  return(tf)

}
