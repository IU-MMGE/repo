#'@export
get_env <- function(default = NULL) {

  env <- getOption("catalog_environment")
  if(is.null(env)) {
    env <- Sys.getenv("catalog_environment")
    if(env == "") env <- NULL
  }
  if(is.null(env)) {
    env <- default
  }
  if(is.null(env)) {
    stop("You must set the `catalog_environment` option or environment variable to PRD, DEV, or STG.", call. = FALSE)
  } else {
    return(env)
  }

}