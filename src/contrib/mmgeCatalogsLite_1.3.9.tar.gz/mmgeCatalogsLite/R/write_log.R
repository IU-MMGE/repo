#'@export
write_log <- function(protocol = "", catalog = "",
                      user = unname(Sys.info()['user']),
                      level = "info", event = "", message = "") {

  try({
    con <- mmgeMongo::mongo_connection("mmgeCatalogs", "logs")

    msg <- list(
      protocol = protocol,
      catalog = catalog,
      level = level,
      user = user,
      event = event,
      message = message,
      timestamp = Sys.time()
    )

    con$insert(msg)

    con$disconnect()
  })

}