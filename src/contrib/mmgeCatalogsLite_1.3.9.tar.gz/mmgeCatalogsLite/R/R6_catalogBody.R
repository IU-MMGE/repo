# function that builds the UI for the body of the shiny application
R6_catalogBody <- function() {

  config <- private$config_obj
  last_update <- private$last_update
  catalog_dir <- self$catalog_dir

  htmltools::attachDependencies(shinydashboard::dashboardBody(
    shinyBS2::bsAlert("join_info", inline = FALSE),
    tags$div(class = "watermark", style = 'display: none;', `data-display-if`='output.draft==true', "DRAFT"),

    # Include custom script if available
    if(dir.exists(file.path(catalog_dir, "www"))) {
      if('script.js' %in% list.files(file.path(catalog_dir, 'www'))) {
        includeScript(file.path(catalog_dir, 'www', 'script.js'))
      }
    },

    tags$span(`data-display-if`='output.enabled==true', style = 'display: none',
      DT::dataTableOutput("catalogTable"),
      tags$div(class = "table-footer",
        tags$div(class = "catalog-info", HTML(sprintf("mmgeCatalogs v.%s - Catalog Data Generated: %s", packageVersion("mmgeCatalogsLite"), last_update))),
        tags$div(class = "table-info")
      )
    ),
    tags$div(id = 'disabled_message', class = 'disabled_message shiny-text-output', style = 'display: none;', `data-display-if`='output.enabled===false'),
    if(config$display$allow_dictionary) {dictionaryModal()},
    if(config$display$allow_joins) {joinModal()},
    tags$div(class = "modal fade", tabindex='-1', role = 'dialog', id='settingsModal',
             tags$div(class = 'modal-dialog', role = 'document',
                      tags$div(class = 'modal-content',
                               tags$div(class = 'modal-header',
                                        tags$button(type = 'button', class = 'close', `data-dismiss`='modal', HTML("&times;")),
                                        tags$h4(class = 'modal-title', "Settings")
                               ),
                               tags$div(class = 'modal-body',
                                        uiOutput("settings_controls")
                               ),
                               tags$div(class = 'modal-footer',
                                        tags$button(type = 'button', class = 'btn btn-default', `data-dismiss`='modal', "Close"),
                                        tags$button(id = 'settings_save', type = 'button', class = 'btn btn-primary action-button', `data-dismiss`='modal', "Save Changes")
                               )
                      )
             )
    ),
    R6_helpModal(config),
    tags$div(class = "modal fade", tabindex='-1', role = 'dialog', id='logsModal',
             tags$div(class = 'modal-dialog modal-lg', role = 'document',
                      tags$div(class = 'modal-content',
                               tags$div(class = 'modal-header',
                                        tags$button(type = 'button', class = 'close', `data-dismiss`='modal', HTML("&times;")),
                                        tags$h4(class = 'modal-title', "Logs")
                               ),
                               tags$div(class = 'modal-body',
                                        DT::dataTableOutput("logsTable")
                               ),
                               tags$div(class = 'modal-footer',
                                        tags$button(type = 'button', class = 'btn btn-default', `data-dismiss`='modal', "Close"),
                                        downloadButton("logs_download", label = "Download Logs")
                               )
                      )
             )
    ),
    tags$div(class = "modal fade", tabindex="-1", role = "dialog", id="imageModal",
      tags$div(class = 'modal-dialog modal-lg', role = 'document',
        tags$div(class = 'modal-content',
          tags$div(class = 'modal-header',
            tags$button(type = 'button', class = 'close', `data-dismiss`='modal', HTML("&times;")),
            tags$button(type = 'button', class = 'close', icon("info"), style = 'margin-right: 10px;', onclick="showImageInfo(event)"),
            tags$h4(id = "imageTitle", class = 'modal-title')
          ),
          tags$div(class = 'modal-body', id = "imageModalBody",
            fluidRow(
              column(width = 2, id = "imageThumbnails"),
              column(width = 10, id = "imageFullSizeCol",
                tags$img(`data-toggle`="magnify", id="imageFullSize", class = "specimen-image img-responsive img-thumbnail center-block")
              ),
              column(width = 4, id = "imageInfo", style = "display: none;")
            )
          ),
          tags$div(class = 'modal-footer',
            tags$button(type = 'button', class = 'btn btn-default', `data-dismiss`='modal', "Close")
          )
        )
      )
    ),
    tags$script(src = "mmgeCatalogs/special_alerts.js"),
    R6_add_alerts(config$display$alerts)
  ), mmgeCatalogsDep)
}
