#'@export

switch_bd = function(box_design,mrn="ALTERNATE_MRN"){
  mrn1 = readline(prompt = "Enter first MRN to swap:")
  mrn2 = readline(prompt = "Enter second MRN to swap:")
  mrn_vector = as.character(c(mrn1,mrn2))
  eval(parse(text = paste0("switch_vector = c(box_design$FINAL_RUN_NO[box_design$",mrn,"=='",mrn_vector[1],"']",",box_design$FINAL_RUN_NO[box_design$",mrn,"=='",mrn_vector[2],"'])")))
  
  eval(parse(text = paste0("box_design$FINAL_RUN_NO[box_design$",mrn,"=='",mrn_vector[1],"']=",switch_vector[2])))
  eval(parse(text = paste0("box_design$FINAL_RUN_NO[box_design$",mrn,"=='",mrn_vector[2],"']=",switch_vector[1])))
  print(box_design_summary(box_design,"APPRDX"))
  return(box_design)
}
