#'Source all the R scripts in a given directory
#'
#'Primarily meant to streamline pullsheet projects by automating the inclusion
#'of support files into the global environment
#'
#'@param dir The path to the directory to source
#'
#'@export
load_support_scripts <- function(dir = "scripts") {

  files <- list.files(dir, pattern = "\\.R$", full.names = TRUE)

  if(length(files) > 0) {

    for(i in seq(length(files))) {

      source(files[i], local = FALSE)

    }

  }

}