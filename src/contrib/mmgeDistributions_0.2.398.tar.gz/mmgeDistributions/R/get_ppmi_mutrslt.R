#' Get PPMI Subject Mutation Data from LONI
#'
#' @param wide Should the data be converted to wide format
#'
#' @export
get_ppmi_mutrslt <- memoise::memoise(function(wide = TRUE) {

  codes <- mmge::pull_from_loni("code_decode", add_dates = FALSE)

  codes <- codes[codes$PAG_NAME == "MUTRSLT", ]

  mutrslt <- mmge::pull_from_loni("mutrslt")

  cols <- c("PATNO")

  for(i in seq(ncol(mutrslt))) {

    cn <- colnames(mutrslt)[i]

    if(cn %in% codes$ITM_NAME) {

      cols <- c(cols, cn)

      x <- codes[codes$ITM_NAME == cn, c("CODE", "DECODE")]
      y <- x$DECODE
      names(y) <- x$CODE

      mutrslt[[cn]] <- y[as.character(mutrslt[[cn]])]

    }

  }

  if(wide) {
    mutrslt <- mutrslt %>%
      filter(!is.na(GENECAT)) %>%
      mutate(GBACD = ifelse(is.na(GBACD), NA, paste0("GBA:", GBACD))) %>%
      mutate(LRRKCD = ifelse(is.na(LRRKCD), NA, paste0("LRRK2:", LRRKCD))) %>%
      mutate(SNCACD = ifelse(is.na(SNCACD), NA, paste0("SNCA:", SNCACD))) %>%
      mutate(MUTATION = ifelse(!is.na(GBACD), GBACD, ifelse(!is.na(LRRKCD), LRRKCD, SNCACD))) %>%
      mutate(STATUS = ifelse(MUTRSLT == "Negative", "Negative", ALLELST)) %>%
      distinct(PATNO, MUTATION, STATUS) %>%
      reshape2::dcast(PATNO ~ MUTATION, value.var = "STATUS")
  }

  mutrslt$PATNO <- as.character(mutrslt$PATNO)

  return(mutrslt)

})
