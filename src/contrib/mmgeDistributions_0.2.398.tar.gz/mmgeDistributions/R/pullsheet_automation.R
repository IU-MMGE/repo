#'@export
pullsheet = function(record_id=0,subject_sheet=NULL,protocol="",oncore_request_id="", name="",collection_group="",specimen_type="",
                     filter_pullsheet=FALSE,box=FALSE,A_or_E = "aliquot",run_size=0,balance_vars="",box_size=81,
                     one_per_subject = TRUE,one_per_group = FALSE,specimen_quantity=0,aliquot_quantity=0,query=NULL,extra_fields="none",extra_annotations = "none",
                     specimen_status="",split_design=1,multiple_per_visit=F,number_of_children=1,overwrite=F,barcode=F,storage_spec="",all_pull = F,number = 1,dna=FALSE,
                     depletion = TRUE,extra_f=TRUE,extra_a=TRUE,include_residuals = FALSE,ref_pools = "",num_ref_pools = 0){

  options(java.parameters = "-Xmx8192m")
  ran=FALSE
  dna=FALSE
  if(extra_fields == "none"){
    extra_fields = c()
    extra_f=FALSE
  }
  if(extra_annotations == "none"){
    extra_annotations = c()
    extra_a=FALSE
  }
  require(dplyr)

  if(record_id!=0){
    dir = mmgeDistributions::create_pullsheet_redcap(record_id = record_id,overwrite = overwrite,open=FALSE)
    setwd(dir)
    if(length(list.files(file.path(dir,"samples")))>0){
      subject_sheet = mmgeDistributions::read_excel_allsheets("samples")
    }
    subject_sheet = subject_sheet[1]
    if(protocol==""){
      protocol = paste(mmgeDistributions::redcap_table()$oncore_protocol_number[mmgeDistributions::redcap_table()$record_id==record_id])
      if(grepl("CTSI-IB",protocol)){
        protocol="MMGE-CTSI-IB"
      }
    }
    if(name==""){
      name = gsub(" ","_",mmgeDistributions::redcap_table()$researcher[mmgeDistributions::redcap_table()$record_id==record_id],fixed=T)
    }
    if(oncore_request_id==""){
      oncore_request_id = mmgeDistributions::redcap_table()$oncore_request_num1[mmgeDistributions::redcap_table()$record_id==record_id]
    }
    if(run_size==0){
      run_size = mmgeDistributions::redcap_table()$samples_per_run[mmgeDistributions::redcap_table()$record_id==record_id]
    }
    if(ref_pools==""){
      ref_pools = mmgeDistributions::redcap_table()$reference_pools[mmgeDistributions::redcap_table()$record_id==record_id]
      num_ref_pools = mmgeDistributions::redcap_table()$ref_pools_per_run[mmgeDistributions::redcap_table()$record_id==record_id]
      if(ref_pools=="None"){
        ref_pools = ""
        num_ref_pools = 0
      }
    }

  } else{
    if(protocol==""){
      protocol = "MMGE-ALL"
    }
    if(oncore_request_id==""){
      oncore_request_id = "00000"
    }
    if(name==""){
      name = "test"
    }
    setwd(mmgeDistributions::create_pullsheet_redcap(protocol,oncore_request_id, name,collection_group,number=number,overwrite=overwrite,open=FALSE))
  }

  config = mmgeDistributions:::get_pullsheet_config()

  if(collection_group==""){
    collection_group = config$collection_group
    if(is.null(collection_group)){
      collection_group=""
    }
    if(is.na(collection_group)){
      collection_group =""
    }
    if(collection_group=="NA"){
      collection_group=""
    }
  }
  if(grepl("[",collection_group,fixed=T)&grepl("]",collection_group,fixed=T)){
    one_per_group = TRUE
    collection_group1 = collection_group
    collection_group1 = gsub("[","",collection_group1,fixed = T)
    collection_group1 = gsub("\\,.*","",collection_group1)
    collection_group2 = gsub("]","",collection_group,fixed = T)
    collection_group2 = gsub(".*\\,","",collection_group2)
    collection_group = c(collection_group1,collection_group2)
  }

  if(grepl("[",specimen_type,fixed=T)&grepl("]",specimen_type,fixed=T)){
    specimen_type1 = specimen_type
    specimen_type1 = gsub("[","",specimen_type1,fixed = T)
    specimen_type1 = gsub("\\,.*","",specimen_type1)
    specimen_type2 = gsub("]","",specimen_type,fixed = T)
    specimen_type2 = gsub(".*\\,","",specimen_type2)
    specimen_type = c(specimen_type1,specimen_type2)
  }
  if(any(collection_group%in%c("DNA","PBMC","BUFFY COAT","RNA"))){
    dna=TRUE
  }

  if(dna){
    A_or_E = "extract"
  }
  if(is.na(specimen_quantity)){
    specimen_quantity=0
  }
  if(missing(specimen_quantity)){
    specimen_quantity=0
  }
  if(specimen_quantity=="NA"){
    specimen_quantity=0
  }
  if(specimen_quantity==0){
    specimen_quantity = config$specimen_quantity
    if(is.null(specimen_quantity)){
      specimen_quantity=0
    }
    if(is.na(specimen_quantity)){
      specimen_quantity=0
    }
    if(specimen_quantity=="NA"){
      specimen_quantity=0
    }
    if(grepl(":",specimen_quantity,fixed=T)){
      specimen_quantity = gsub("\\:.*","",specimen_quantity)
      ###CANNOT HANDLE MULTIPLE QUANTITIES
    }
    specimen_quantity = as.numeric(gsub("([0-9]+).*$", "\\1", specimen_quantity))
  }

  if(specimen_quantity==0){
    quantity=FALSE
  }
  if(specimen_quantity!=0){
    quantity=TRUE
  }

  if(specimen_status==""){
    specimen_status="Available"
  }
  if(grepl("[",specimen_status,fixed=T)&grepl("]",specimen_status,fixed=T)){
    specimen_status1 = specimen_status
    specimen_status1 = gsub("[","",specimen_status1,fixed = T)
    specimen_status1 = gsub("\\,.*","",specimen_status1)
    specimen_status2 = gsub("]","",specimen_status,fixed = T)
    specimen_status2 = gsub(".*\\,","",specimen_status2)
    specimen_status = c(specimen_status1,specimen_status2)
  }

  # if(is.null(query)&!protocol%in%c("MMGE-CTSI-IB","MMGE-ALL")){
  #   #WAITING FOR FASTER QUERYING FOR SPECIFIED PROTOCOLS
  #   #query = mmgeDistributions::pullsheet_query(pullsheet = filter_pullsheet,extra_fields=extra_fields,extra_annotations = extra_annotations,protocol=protocol)
  #
  #
  #    #query = mmgeDistributions::pullsheet_query(pullsheet = filter_pullsheet,extra_fields=extra_fields,extra_annotations = extra_annotations)
  #     query = mmgeMongo::moncore_query()
  #   }
  #
  #
  # if(is.null(query)&protocol%in%c("MMGE-CTSI-IB","MMGE-ALL")){
  #   #query = mmgeDistributions::pullsheet_query(pullsheet = filter_pullsheet,extra_fields=extra_fields,extra_annotations = extra_annotations)
  #   query = mmgeMongo::moncore_query()
  #
  #  }

  datalist = list()
  if(balance_vars==""){
    balance_vars = c()
  }
  if(!is.null(subject_sheet)){

    if(any(class(subject_sheet)!="list")){
      subject_sheet = list(subject_sheet)
    }

    for(i in 1:length(subject_sheet)){
      #subject_sheet[[i]] = subject_sheet[[i]][!is.na(subject_sheet[[i]]),]
      subject_sheet[[i]] = subject_sheet[[i]][!duplicated(subject_sheet[[i]]),]
      subject_sheet[[i]] = as.data.frame(subject_sheet[[i]])
    }

    for(i in 1:length(subject_sheet)){
      namelist = c()
      k=1
      z=1
      extra_bv = c()
      for(j in 1:ncol(subject_sheet[[i]])){
        subject_sheet[[i]][,j] = as.character(subject_sheet[[i]][,j])
        if(!any(is.na(subject_sheet[[i]][,j]))){
          if(!grepl("CLINICAL_BALANCE_VARIABLE",names(subject_sheet[[i]])[j])){
            namelist[k] = names(subject_sheet[[i]])[j]
            if(namelist[k]=="SUBJECT_LAST_NAME"){
              subject_sheet[[i]]$SUBJECT_LAST_NAME=toupper(subject_sheet[[i]]$SUBJECT_LAST_NAME)
              # query$SUBJECT_LAST_NAME = toupper(query$SUBJECT_LAST_NAME)
            }
            if(namelist[k]=="SPECIMEN_BAR_CODE"){
              barcode = TRUE
            }
          } else{
            box=TRUE
            extra_bv[z] = names(subject_sheet[[i]])[j]
            z=z+1
          }
          k = k+1
        }
      }
      verb = paste0(namelist,"=","subject_sheet[[1]][,",'"',namelist,'"',"]",collapse=",")
      query = eval(parse(text = paste0("moncore_query(",verb,")")))
      datalist[[i]] = query%>%
        dplyr::inner_join(subject_sheet[[i]]%>%select(!!namelist,!!extra_bv),by=c(namelist))
      if(i==length(subject_sheet)){
        for(l in 1:length(datalist)){
          if(l==1){
            all = datalist[[1]]
          } else{
            all = dplyr::bind_rows(all,datalist[[l]])
          }
        }
      }
    }
  }
  if(is.null(subject_sheet)){
    all = query%>%
      filter(PROTOCOL_NO%in%!!protocol)
    extra_bv = c()
  }
  if(extra_f){
    if(!is.null(config$extra_fields)){
      config$extra_fields = c(extra_fields,config$extra_fields)
    }
    else{
      config$extra_fields =config$extra_fields
    }
  }
  if(extra_a){
    if(!is.null(config$extra_fields)){
      config$extra_fields = c(names(query)[grepl(gsub(" ","_",extra_annotations,fixed=T),names(query),ignore.case=T)],config$extra_fields)
    }
    else{
      config$extra_annotations = names(query)[grepl(gsub(" ","_",extra_annotations,fixed=T),names(query),ignore.case=T)]
    }
  }
  all = all%>%distinct()
  balance_vars = c(balance_vars,extra_bv)
  config$balance_vars = balance_vars
  writeLines(yaml::as.yaml(config), file.path(getwd(),"config.yaml"))
  if(any(collection_group=="")){
    warning("missing collection group")
  }
  if(!barcode){
    if(all(specimen_type=="")){
      all = all%>%
        dplyr::filter(COLLECTION_GROUP%in% !! collection_group&SPECIMEN_STATUS%in% !! specimen_status)

    }
    if(any(specimen_type!="")){
      all = all%>%
        dplyr::filter(COLLECTION_GROUP%in% !! collection_group&SPECIMEN_STATUS%in% !! specimen_status&SPECIMEN_TYPE%in%!!specimen_type)

    }


    if(any(grepl("iPSC",collection_group))){
      all = all%>%
        dplyr::filter(CELL_TYPE=="iPSC"&COLLECTION_GROUP=="PBMC")
    }
    if(!include_residuals){
      if(quantity&aliquot_quantity!=0&!dna){
        all = all%>%
          dplyr::filter((SPECIMEN_QUANTITY==!!specimen_quantity&grepl(".",SPECIMEN_NO,fixed=T))|
                          (SPECIMEN_QUANTITY>= !!aliquot_quantity &!grepl(".",SPECIMEN_NO,fixed=T)))
      }

      if(aliquot_quantity==0&quantity&!dna){
        all = all%>%
          dplyr::filter((SPECIMEN_QUANTITY==!!specimen_quantity&grepl(".",SPECIMEN_NO,fixed=T))|
                          (SPECIMEN_QUANTITY>= 500 &!grepl(".",SPECIMEN_NO,fixed=T)))
      }

      if(!quantity&aliquot_quantity==0&!dna){
        all = all%>%
          dplyr::filter((SPECIMEN_QUANTITY>=200&SPECIMEN_QUANTITY<500&grepl(".",SPECIMEN_NO,fixed=T))|
                          (SPECIMEN_QUANTITY>= 500 &!grepl(".",SPECIMEN_NO,fixed=T)))
      }

      if(!quantity&aliquot_quantity!=0&!dna){
        all = all%>%
          dplyr::filter((SPECIMEN_QUANTITY>=200&SPECIMEN_QUANTITY<!!aliquot_quantity&grepl(".",SPECIMEN_NO,fixed=T))|
                          (SPECIMEN_QUANTITY>= !!aliquot_quantity &!grepl(".",SPECIMEN_NO,fixed=T)))
      }
    }



    all$SPECIMEN_COMMENTS = ifelse(is.na(all$SPECIMEN_COMMENTS),"",all$SPECIMEN_COMMENTS)
    if(storage_spec==""){
      pull = all%>%dplyr::filter(grepl(".",SPECIMEN_NO,fixed=TRUE)|SPECIMEN_TYPE%in%c("Nucleic Acids"))
      aliquot = all%>%dplyr::filter(!grepl(".",SPECIMEN_NO,fixed=TRUE)|SPECIMEN_TYPE%in%c("Buffy Coat"))
    }
    if(storage_spec!=""){
      pull = all%>%dplyr::filter(grepl(".",SPECIMEN_NO,fixed=TRUE)&grepl(storage_spec,SPECIMEN_STORAGE_LOCATION)|SPECIMEN_TYPE%in%c("Nucleic Acids"))
      aliquot = all%>%dplyr::filter(!grepl(".",SPECIMEN_NO,fixed=TRUE)&grepl(storage_spec,SPECIMEN_STORAGE_LOCATION)|SPECIMEN_TYPE%in%c("Buffy Coat"))
    }

    if(one_per_subject&!one_per_group){
      pull = pull%>%
        dplyr::group_by(CASE_NO)%>%
        mmgeDistributions::final_check()%>%
        dplyr::arrange(SPECIMEN_QUANTITY)%>%
        dplyr::filter(row_number()==1)

      aliquot = aliquot%>%
        dplyr::group_by(CASE_NO)%>%
        mmgeDistributions::final_check()%>%
        dplyr::arrange(desc(SPECIMEN_STORAGE_LOCATION),SPECIMEN_COMMENTS,desc(SPECIMEN_QUANTITY))%>%
        dplyr::filter(row_number()==1)%>%
        dplyr::anti_join(pull,by="CASE_NO")
    }
    if(one_per_subject&one_per_group){
      pull = pull%>%
        dplyr::group_by(CASE_NO,COLLECTION_GROUP)%>%
        mmgeDistributions::final_check()%>%
        dplyr::arrange(SPECIMEN_QUANTITY)%>%
        dplyr::filter(row_number()==1)

      aliquot = aliquot%>%
        dplyr::group_by(CASE_NO,COLLECTION_GROUP)%>%
        mmgeDistributions::final_check()%>%
        dplyr::arrange(desc(SPECIMEN_STORAGE_LOCATION),SPECIMEN_COMMENTS,desc(SPECIMEN_QUANTITY))%>%
        dplyr::filter(row_number()==1)%>%
        dplyr::anti_join(pull,by="CASE_NO")
    }

  }
  if(barcode){
    pull = all%>%dplyr::filter(grepl(".",SPECIMEN_NO,fixed=TRUE)|SPECIMEN_TYPE%in%c("Nucleic Acids"))%>%distinct()
    aliquot = all%>%dplyr::filter(!grepl(".",SPECIMEN_NO,fixed=TRUE)|SPECIMEN_TYPE%in%c("Buffy Coat"))%>%distinct()
    pull = pull%>%anti_join(aliquot)
  }

  if(dna){
    box_size = 96
  }
  if(box&run_size==0){
    warning("Run Size not specified")
  }
  if(box&nrow(aliquot)>0&nrow(pull)>0){
    box_design = mmgeDistributions::design_box.1(pull = pull,aliquot = aliquot,box_size = run_size,balance_vars = balance_vars,number_of_children = number_of_children)
  }
  if(box&nrow(aliquot)<1&nrow(pull)>0){
    box_design = mmgeDistributions::design_box.1(pull = pull,box_size = run_size,balance_vars = balance_vars)
  }
  if(box&nrow(aliquot)>0&nrow(pull)<1){
    box_design = mmgeDistributions::design_box.1(aliquot = aliquot,box_size = run_size,balance_vars = balance_vars,number_of_children = number_of_children)
  }
  if(all_pull){
    pull = bind_rows(pull,aliquot)
    aliquot = data.frame()
  }
  if(ref_pools!=""){
    pool = mmgeDistributions::get_reference_pools()
    pools = pool%>%filter(grepl(ref_pools,CASE_NO)&SPECIMEN_STATUS=="Available")%>%
      group_by(CASE_NO)%>%
      filter(row_number()<=num_ref_pools)
    if(nrow(pull)>0){
      pull = pull%>%full_join(pools)
    } else{
      pull = pools
    }
  }
  if(A_or_E=="aliquot"&box&nrow(aliquot)>0&nrow(pull)>0){
    wb = mmgeDistributions::build_pullsheet_wb_test(pull = pull,aliquot = aliquot,box_design = box_design
                                                    ,split_design = split_design,box_size = box_size,query = query,
                                                    number_of_children = number_of_children,multiple_per_visit = multiple_per_visit,
                                                    check_depletion_levels = depletion)
    mmgeDistributions::save_pullsheet_workbook(wb)
    ran=TRUE

  }
  if(A_or_E=="aliquot"&!box&nrow(aliquot)>0&nrow(pull)>0){
    wb = mmgeDistributions::build_pullsheet_wb_test(pull = pull,aliquot = aliquot,box_size = box_size,query = query,
                                                    number_of_children = number_of_children,multiple_per_visit = multiple_per_visit,
                                                    check_depletion_levels = depletion)
    mmgeDistributions::save_pullsheet_workbook(wb)
    ran=TRUE

  }
  if(A_or_E=="extract"&box&nrow(aliquot)>0&nrow(pull)>0){
    wb = mmgeDistributions::build_pullsheet_wb_test(pull = pull,extract = aliquot,box_design = box_design,
                                                    split_design = split_design,box_size = box_size,query = query,
                                                    number_of_children = number_of_children,multiple_per_visit = multiple_per_visit,
                                                    check_depletion_levels = depletion)
    mmgeDistributions::save_pullsheet_workbook(wb)
    ran=TRUE

  }
  if(A_or_E=="extract"&!box&nrow(aliquot)>0&nrow(pull)>0){
    wb = mmgeDistributions::build_pullsheet_wb_test(pull = pull,extract = aliquot,box_size = box_size,query = query,
                                                    number_of_children = number_of_children,multiple_per_visit = multiple_per_visit,
                                                    check_depletion_levels = depletion)
    mmgeDistributions::save_pullsheet_workbook(wb)
    ran=TRUE

  }
  if(nrow(aliquot)<1&box&nrow(pull)>0){
    wb = mmgeDistributions::build_pullsheet_wb_test(pull = pull,box_design = box_design,
                                                    split_design = split_design,box_size = box_size,query = query,
                                                    number_of_children = number_of_children,multiple_per_visit = multiple_per_visit,
                                                    check_depletion_levels = depletion)
    mmgeDistributions::save_pullsheet_workbook(wb)
    ran=TRUE

  }
  if(nrow(aliquot)<1&!box&nrow(pull)>0){
    wb = mmgeDistributions::build_pullsheet_wb_test(pull = pull,box_size = box_size,query = query,
                                                    number_of_children = number_of_children,multiple_per_visit = multiple_per_visit,
                                                    check_depletion_levels = depletion)
    mmgeDistributions::save_pullsheet_workbook(wb)
    ran=TRUE

  }
  if(A_or_E=="aliquot"&box&nrow(aliquot)>0&nrow(pull)<1){
    wb = mmgeDistributions::build_pullsheet_wb_test(aliquot = aliquot,box_design = box_design,
                                                    split_design = split_design,box_size = box_size,query = query,
                                                    number_of_children = number_of_children,multiple_per_visit = multiple_per_visit,
                                                    check_depletion_levels = depletion)
    mmgeDistributions::save_pullsheet_workbook(wb)
    ran=TRUE

  }
  if(A_or_E=="aliquot"&!box&nrow(aliquot)>0&nrow(pull)<1){
    wb = mmgeDistributions::build_pullsheet_wb_test(aliquot = aliquot,box_size = box_size,query = query,
                                                    number_of_children = number_of_children,multiple_per_visit = multiple_per_visit,
                                                    check_depletion_levels = depletion)
    mmgeDistributions::save_pullsheet_workbook(wb)
    ran=TRUE

  }
  if(A_or_E=="extract"&box&nrow(aliquot)>0&nrow(pull)<1){
    wb = mmgeDistributions::build_pullsheet_wb_test(extract = aliquot,box_design = box_design,
                                                    split_design = split_design,box_size = box_size,query = query,
                                                    number_of_children = number_of_children,multiple_per_visit = multiple_per_visit,
                                                    check_depletion_levels = depletion)
    mmgeDistributions::save_pullsheet_workbook(wb)
    ran=TRUE

  }
  if(A_or_E=="extract"&!box&nrow(aliquot)>0&nrow(pull)<1){
    wb = mmgeDistributions::build_pullsheet_wb_test(extract = aliquot,box_size = box_size,query = query,
                                                    number_of_children = number_of_children,multiple_per_visit = multiple_per_visit,
                                                    check_depletion_levels = depletion)
    mmgeDistributions::save_pullsheet_workbook(wb)
    ran=TRUE
  }
  if(!ran){
    message("error")
  }
  if(ran){
    message("Pullsheet Complete")
  }

  df1 <- file.info(list.files(file.path("/media/distributions",protocol,paste0(oncore_request_id,"_",name),"Pullsheet"), full.names = T))
  df2 = rownames(df1)[which.max(df1$mtime)]
  return(df2)
}
