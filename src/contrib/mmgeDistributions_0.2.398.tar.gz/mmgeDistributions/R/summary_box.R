#'@export

tidy_box = function(pull,aliquot,extract,combine,box_design,subject = config$subject_ids$blinded,visit_type = visit_type,
                    position=position,multiple_per_visit = multiple_per_visit,ref_pool_exclude,box_size = box_size,
                    split_design = split_design,arrange_box_vars){

  #####HANDLE ALIQUOT DOTS SPECIFICALLY INSTEAD OF FUZZYJOINING

  summary_box <- dplyr::bind_rows(pull,aliquot,extract,combine)%>%
    left_join(box_design %>% dplyr::select(-VISITS))

  # for(i in 1:length(colnames(summary_box))){
  #   if(grepl(".y",colnames(summary_box)[i],fixed = T)){
  #     colnames(summary_box)[i] = gsub(".y","",colnames(summary_box)[i],fixed=T)
  #   }
  # }
  summary_box = summary_box%>%
    ungroup()%>%
    mutate(NEW_ID = gsub("\\..*","",summary_box[[subject]]))
#
#   if(any(is.na(summary_box$FINAL_RUN_NO[summary_box$VISIT!="POOL"]))){
#     summary_box <- dplyr::bind_rows(pull,aliquot,extract,combine)%>%
#       left_join(box_design %>% dplyr::select(-VISITS))
#   }
  if(any(is.na(summary_box$FINAL_RUN_NO[summary_box$VISIT!="POOL"]))){
    stop("Box didn't match up")
  }
  if(!is.null(split_design)){
    alpha = c("A","B","C","D","E","F","G","H")
    summary_box1 = summary_box[1,]%>%mutate(FINAL_RUN = "1A")
    summary_list= list()
    t = c(0)
    for (i in 1:split_design){
      summary_list[[i]] = summary_box%>%
        dplyr::filter(VISIT!="POOL")%>%
        dplyr::ungroup()%>%
        dplyr::group_by_(.dots=c(subject,visit_type))%>%
        dplyr::filter(row_number()==i)%>%
        dplyr::mutate(FINAL_RUN = paste0(FINAL_RUN_NO,alpha[i]))%>%
        dplyr::mutate(FINAL_RUN_NO = ifelse(i>1,FINAL_RUN_NO+max(summary_list[[i-1]]["FINAL_RUN_NO"]),FINAL_RUN_NO))
      t[i+1] = t[i]+nrow(summary_list[[i]])
      summary_box1[(t[i]+1):t[i+1],] = summary_list[[i]]
    }
    summary_box = summary_box1%>%
      full_join(summary_box%>%filter(VISIT=="POOL"))
  } else{
    summary_box1 = summary_box%>%
      filter(VISIT!="POOL")
  }
  summary_box = summary_box%>%
    dplyr::arrange_(.dots = c(subject, visit_type)) %>%
    dplyr::group_by_(.dots = c(visit_type, subject)) %>%
    dplyr::mutate(FINAL_RUN_NO = ifelse(VISIT == "POOL", seq(min(summary_box1$FINAL_RUN_NO),max(summary_box1$FINAL_RUN_NO))[-ref_pool_exclude], FINAL_RUN_NO)) %>%
    dplyr::mutate(FINAL_BOX_NO = ifelse(VISIT == "POOL", 0, FINAL_BOX_NO)) %>%
    dplyr::mutate(is_pool = ifelse(VISIT == "POOL", 1, 0))%>%
    dplyr::arrange(FINAL_RUN_NO,is_pool,SPECIMEN_NO)
  for(i in 1:nrow(summary_box)){
    if(summary_box$FINAL_BOX_NO[i]==0&(i>2)){
      if(summary_box$FINAL_BOX_NO[i-1]!=0){
        summary_box$FINAL_BOX_NO[i]=summary_box$FINAL_BOX_NO[i-1]
      }
      else{
        summary_box$FINAL_BOX_NO[i]=summary_box$FINAL_BOX_NO[i-3]
      }
    }
    if(summary_box$FINAL_BOX_NO[i]==0&(i<=2)){
      warning('POOL at beginning of box')
    }
  }


  #Specify box position. Add a FINAL_RUN_POSITION column to the box design
  if(position == T){
    summary_box = summary_box%>%
      dplyr::ungroup()%>%
      dplyr::arrange(FINAL_RUN_NO,FINAL_RUN_POSITION)
    if(!is.null(box_size)){
      j=1
      k=1
      for (i in 1:nrow(summary_box)){
        if(j>box_size){
          j=1
          k=k+1
        }
        summary_box$FINAL_BOX_POSITION[i] = j
        summary_box$FINAL_BOX_NO[i] = k
        j=j+1
      }
    }
    if(any(duplicated(summary_box[,c("FINAL_RUN_POSITION","FINAL_RUN_NO")]))&multiple_per_visit==F){
      for (i in 2:nrow(summary_box)){
        if(summary_box$FINAL_RUN_POSITION[i]==summary_box$FINAL_RUN_POSITION[i-1]){
          summary_box$FINAL_RUN_POSITION[i] = summary_box$FINAL_RUN_POSITION[i]+1
        }
      }
    }
  }

  if(position == F){
    if(is.null(summary_box$COMB)){
      summary_box$COMB = NA
    }

    summary_box = summary_box%>%
      dplyr::mutate(LOCATION = ifelse(grepl("IU",STORAGE_LOCATION),"IU",
                                      ifelse(grepl("BioRep",STORAGE_LOCATION),"BioRep",
                                             ifelse(grepl("Tel-Aviv",STORAGE_LOCATION),"Tel-Aviv",NA))))%>%
      dplyr::ungroup()%>%
      dplyr::group_by(FINAL_RUN_NO)%>%
      dplyr::arrange(desc(LOCATION))%>%
      dplyr::arrange_(.dots=c("NEW_ID","SPECIMEN_NO",visit_type))%>%
      dplyr::arrange_(.dots = c("FINAL_RUN_NO","is_pool",arrange_box_vars))%>%
      dplyr::mutate(FINAL_RUN_POSITION = NA,FINAL_BOX_POSITION = NA)%>%
      dplyr::ungroup()
    j=1
    summary_box$FINAL_RUN_POSITION[1] = 1
    for (i in 2:nrow(summary_box)){
      if(!is.na(summary_box$COMB[i])&summary_box[[subject]][i] == summary_box[[subject]][i-1]){
        summary_box$FINAL_RUN_POSITION[i]=summary_box$FINAL_RUN_POSITION[i-1]
      }
      else{
        if(summary_box[i,"FINAL_RUN_NO"]==summary_box[i-1,"FINAL_RUN_NO"]){
          summary_box$FINAL_RUN_POSITION[i]=summary_box$FINAL_RUN_POSITION[i-1]+1
        }
        else{
          summary_box$FINAL_RUN_POSITION[i]=1
        }
      }
    }

    summary_box = summary_box%>%
      dplyr::arrange(FINAL_RUN_NO,FINAL_RUN_POSITION)%>%
      dplyr::ungroup()

    if(!is.null(box_size)){
      j=1
      k=1
      for (i in 1:nrow(summary_box)){
        if(j>box_size){
          j=1
          k=k+1
        }
        summary_box$FINAL_BOX_POSITION[i] = j
        summary_box$FINAL_BOX_NO[i] = k
        if(i<nrow(summary_box)){
          if(summary_box$FINAL_RUN_POSITION[i]!=summary_box$FINAL_RUN_POSITION[i+1]){
            j=j+1
          }
        }
      }
    }

    if(multiple_per_visit==T){
      summary_box = dplyr::arrange_(summary_box,.dots = c("FINAL_RUN_NO"))
      summary_box$FINAL_RUN_POSITION[1]=1
      for (i in 2:nrow(summary_box)){
        if(summary_box[i,"CASE_NO"]==summary_box[i-1,"CASE_NO"]|
           (!is.na(summary_box$COMB[i])&summary_box[[subject]][i] == summary_box[[subject]][i-1])){
          summary_box$FINAL_RUN_POSITION[i]=summary_box$FINAL_RUN_POSITION[i-1]
        }
        else{
          if(summary_box[i,"FINAL_RUN_NO"]==summary_box[i-1,"FINAL_RUN_NO"]){
            summary_box$FINAL_RUN_POSITION[i]=summary_box$FINAL_RUN_POSITION[i-1]+1
          }
          else{
            summary_box$FINAL_RUN_POSITION[i]=1
          }
        }
      }
      summary_box = summary_box%>%
        ungroup()%>%
        group_by(FINAL_BOX_NO)%>%
        arrange(FINAL_RUN_NO,FINAL_RUN_POSITION)%>%
        mutate(FINAL_BOX_POSITION=row_number())%>%
        ungroup()
    }
    if(any(duplicated(summary_box[,c("FINAL_RUN_POSITION","FINAL_RUN_NO")]))&multiple_per_visit==F&is.null(combine)){
      for (i in 2:nrow(summary_box)){
        if(summary_box$FINAL_RUN_POSITION[i]==summary_box$FINAL_RUN_POSITION[i-1]){
          summary_box$FINAL_RUN_POSITION[i] = summary_box$FINAL_RUN_POSITION[i]+1
        }
      }
    }
  }
  return(summary_box)
}

create_box_sheet = function(pull,aliquot,extract,combine,subject_id = config$subject_ids$blinded,box_size){
  if(is.null(box_size)){
    box_size = 81
  }
  balance_vars = c("VISIT")
  box_design <- dplyr::bind_rows(pull,aliquot,extract,combine) %>%
    dplyr::distinct_(.dots = c(subject_id, "VISIT"), .keep_all = TRUE) %>%
    dplyr::select_(.dots = c(subject_id, "VISIT", balance_vars)) %>%
    dplyr::group_by_(.dots = c(subject_id, balance_vars)) %>%
    dplyr::summarise(VISITS = n()) %>%
    dplyr::arrange_(.dots = balance_vars) %>%
    dplyr::mutate(FINAL_RUN_NO = 1,FINAL_BOX_NO=1)
  summary_box <- dplyr::bind_rows(pull, aliquot, extract, combine) %>%
    dplyr::left_join(box_design %>% dplyr::select(-VISITS)) %>%
    dplyr::ungroup()%>%
    #dplyr::group_by(FINAL_RUN_NO) %>%
    dplyr::mutate(FINAL_RUN_POSITION = row_number()) %>%
    #dplyr::ungroup()%>%
    #dplyr::group_by(FINAL_BOX_NO)%>%
    #dplyr::mutate(FINAL_BOX_POSITION = row_number())%>%
    dplyr::mutate(FINAL_BOX_NO = ((FINAL_RUN_POSITION-1)%/%box_size)+1)%>%
    dplyr::group_by(FINAL_BOX_NO)%>%
    dplyr::mutate(FINAL_BOX_POSITION =row_number())%>%
    dplyr::ungroup()%>%
    dplyr::arrange(FINAL_BOX_NO, FINAL_BOX_POSITION)
  return(summary_box)
}
