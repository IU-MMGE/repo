dna_manifest <- function(request_id) {

  request_id <- 25244
  base_dir <- "/media/Cell_Lab/6. Distributions/1)  Pending/"

  orders <- list.dirs(base_dir, full.names = FALSE, recursive = FALSE)

  matched_orders <- orders[grepl(pattern = paste0("^", request_id, "[[:blank:]]"), orders)]

  if(length(matched_orders) == 1) {
    message("Using ", matched_orders, " for manifest creation.")
    dir <- file.path(base_dir, matched_orders, "QC")



  } else {
    if(length(matched_orders) == 0) {
      stop("Directory for Request ID #", request_id, " not found.")
    } else {
      stop("Multiple directories found for Request ID #", request_id, ".")
    }
  }


  dir.exists(dir)

}