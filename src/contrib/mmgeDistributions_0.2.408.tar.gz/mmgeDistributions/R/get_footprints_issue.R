#'Return all information from footprints based on
get_footprints_issue <- function(fp_id, ask = TRUE) {

  request_data <- query_footprints(number = fp_id)
  request_data <- sapply(request_data, unlist)
  request_data <- sapply(request_data, unname)

  desc <- get_footprints_desc(fp_id)
  desc <- gsub(" ", "", desc)
  desc <- strsplit(desc, split = "\n")[[1]]
  for(i in seq(length(desc))) {
    if(nchar(desc[i]) > 80) {
      starts <- seq(1, nchar(desc[i]), 80)
      stops <- unique(c(seq(80, nchar(desc[i]), 80), nchar(desc[i])))
      desc[i] <- paste(substring(desc[i], starts, stops), collapse = "\n")
    }
  }
  while(desc[1] == "") {
    desc <- desc[c(FALSE, rep(TRUE, times = length(desc) - 1))]
  }
  desc <- trimws(desc, "both")
  desc <- paste(desc, collapse = "\n")

  request_data$descriptions <- desc

  request_data$oncore_request_id <- get_oncore_id(request_data, ask)
  request_data$protocol <- get_oncore_protocol(request_data, ask)
  request_data$project_name <- get_project_name(request_data, ask)
  request_data$collection_group <- get_collection_groups(request_data)

  request_data$order_name <- sprintf("%s_%s_%s", request_data$project_name, request_data$oncore_request_id, request_data$number)

  request_data$directory <- get_order_dir(request_data)

  return(request_data)

}
