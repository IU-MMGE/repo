# devtools::load_all()
#
# catalog <- mmgeCatalogs::mmgeCatalog$new("MMGE-NINDS-BIOSEND-CFI")$build()$catalog
#
# #debug(postCatalog)
# postCatalog(catalog, colnames = TRUE, api_name = "rti_dev")
#
# y <- getCatalog(api_name = "rti_dev")
# colnames(catalog)[!colnames(catalog) %in% colnames(y)]
#
# loadAPI("rti_dev")
