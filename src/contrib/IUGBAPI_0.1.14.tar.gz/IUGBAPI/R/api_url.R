api_url <- function(endpoint, query, api_name = NULL, url = NULL) {

  if(is.null(api_name)) {
    if(is.null(url)) {
      url <- getAPIvalue("url")
    }
  }
  if(is.null(url)) {
    if(!is.null(api_name)) {
      url <- local({
        load("~/.IUGBAPI")
        if(api_name %in% names(iugbapiOptions)) {
          return(iugbapiOptions[[api_name]]$url)
        } else {
          return(NULL)
        }

      })
    }
  }
  if(is.null(url)) {
    stop("Unable to locate a usable url for this call")
  }

  if(substr(endpoint, 1, 1) != "/") endpoint <- paste0("/", endpoint)

  if(!missing(query)) {
    query <- paste(names(query), query, sep = "=", collapse = "&")
    endpoint <- paste(endpoint, query, sep = "?")
  }

  paste0(url, endpoint)

}

