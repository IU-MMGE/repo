#' Load API
#'
#' Loads connection parameters for a specific API
#'
#'@export
loadAPI <- function(name) {

  if(file.exists(dotfile)) {

    apiOptions <- loadAPIOptions()

    opts <- apiOptions[[name]]

    if(is.null(opts)) {

      stop("You haven't set connection parameters for this API. Please initialize it with IUGBAPIsetParameters()")

    }

    options(iugbapi = opts)

    message(name, " API activated.")

  } else {

    stop("No IUGBAPI parameters file found. Please create one with IUGBAPIsetToken()")

  }

}

#'@export
setToken <- function(token) {

  if(missing(token)) {
    stop("You must provide an API token.")
  }

  token_values <- readToken(token)

  if(!(token_values$aud %in% names(iugbapis))) {
   stop("This token does not appear to be valid for any available IUGB APIs.")
  }

  if(toupper(readline(paste0("You are about to set an API token for the ", token_values$aud,
                     " API. \nThis token has ", token_values$scope$role, " access with \n",
                     paste(token_values$scope$actions, collapse = ", "),
                     " privileges. \n\nDo you want to proceed? y/N"))) %in% c("Y", "YES")) {

      opts <- loadAPIOptions()
      api_opts <- iugbapis[[token_values$aud]]
      api_opts$token <- token
      opts[[token_values$aud]] <- api_opts
      saveAPIOptions(opts)
      message("API token set. Activate it with loadAPI('", token_values$aud, "')")

  } else {
    stop("Operation canceled by user.")
  }

}
