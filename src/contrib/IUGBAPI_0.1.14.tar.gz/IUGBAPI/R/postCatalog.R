#'@export
postCatalog <- function(catalog, colnames = FALSE, api_name = NULL, envvar_name = NULL, url = NULL) {

  tf <- tempfile()

  write.table(catalog, file = tf, row.names = FALSE, col.names = colnames, sep = ",")

  body <- list(catalog = httr::upload_file(tf))

  endpoint <- api_url("catalogs/", api_name = api_name, url = url)

  postRequest(endpoint, body, encode = "multipart", api_name = api_name, envvar_name = envvar_name)

}
