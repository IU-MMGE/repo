#' Helper Functions
#'
#' The functions in this file are not meant to be exported. They
#' are internal only.

iugbapis <- list(
  dmr_dev = list(
    url = "https://api.biosend.org/dmr/dev/v2"
  ),
  dmr_prd = list(
    url = "https://api.biosend.org/dmr/v2"
  ),
  rti_dev = list(
    url = "https://api.biosend.org/rti/dev/v1"
  ),
  rti_prd = list(
    url = "https://api.biosend.org/rti/v1"
  ),
  letbi_dev = list(
    url = "https://api.biosend.org/letbi/dev/v2"
  ),
  letbi_prd = list(
    url = "https://api.biosend.org/letbi/v2"
  )
)

.onLoad <- function(libname, pkgname) {
  #httr::set_config( httr::config( ssl_verifypeer = 0L ) )
}

dotfile <- "~/.IUGBAPI"

readToken <- function(token) {
  payload <- strsplit(token, ".", fixed = TRUE)[[1]][2]
  jsonlite::fromJSON(rawToChar(base64enc::base64decode(payload)))
}

getAPIvalue <- function(name) {
  getOption("iugbapi")[[name]]
}

loadAPIOptions <- function() {
  if(file.exists(dotfile)) {
    load(dotfile)
  } else {
    iugbapiOptions <- list()
  }
  return(iugbapiOptions)
}

saveAPIOptions <- function(iugbapiOptions) {
  save(iugbapiOptions, file = dotfile)
}
