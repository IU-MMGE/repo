#'@export
getOrders <- function(status = "received", api_name = NULL, envvar_name = NULL, url = NULL) {

  if(!is.null(status)) {
    endpoint <- api_url("orders", list(status=status), api_name = api_name, url = url)
  } else {
    endpoint <- api_url("orders", api_name = api_name, url = url)
  }
  getRequest(endpoint, as = "parsed", api_name = api_name, envvar_name = envvar_name)$message$orders

}
