#'@export
putOrder <- function(orderID, type = "update", api_name = NULL, envvar_name = NULL, url = NULL, ...) {

  body <- list(...)
  body$updateType = type

  if("order" %in% names(body)) {
    stop("Order Uploads not yet supported")
  }

  endpoint <- api_url(paste0("orders/", orderID))

  return(putRequest(endpoint, body, api_name = api_name, envvar_name = envvar_name))

}
