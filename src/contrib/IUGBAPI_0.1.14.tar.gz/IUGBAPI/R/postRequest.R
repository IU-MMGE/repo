postRequest <- function(endpoint, body, encode = "form", api_name = NULL, envvar_name = NULL) {

  x <- httr::POST(endpoint, api_auth(api_name, envvar_name), body = body, encode = encode)

  if(httr::status_code(x) %in% c(200, 201, 202)) {
    return(httr::content(x)$message)
  } else {
    stop("Server Responded: ", httr::http_status(x), " - ", httr::content(x)$message)
  }

}
