getRequest <- function(endpoint, expected_status = 200, as = "text", proxy,
                       api_name = NULL, envvar_name = NULL) {

  if(!missing(proxy)) {
    url <- strsplit(proxy, ":")[[1]]
    proxy <- httr::use_proxy(url[1], as.numeric(url[2]))
  } else {
    proxy <- NULL
  }

  x <- httr::GET(endpoint, api_auth(api_name, envvar_name))

  if(httr::status_code(x) == expected_status) {
    return(httr::content(x, as= as))
  } else {
    warning("Server Responded: ", httr::http_status(x), " - ", httr::content(x)$message)
    return(x)
  }

}
