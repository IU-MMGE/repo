#' View the package on github
#'
#' Opens a new web browser tab and loads the remote repository's URL
#'
#'@param pkg The directory containing the R package
#'
#'@export
viewRemote <- function(pkg = ".") {

  desc_path <- file.path(pkg, "DESCRIPTION")

  d <- readLines(desc_path)
  n <- gsub("Package", "", d[grep("^Package", d)])
  n <- trimws(gsub(":", "", n))

  browseURL(paste0(getOption("mmgeRepo.pkg_base_url"), n))

}
