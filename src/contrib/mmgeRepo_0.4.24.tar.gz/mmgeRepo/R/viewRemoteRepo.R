#' View the drat repo on github
#'
#' Opens a new web browser tab and loads the drat repository's URL
#'
#'@param dev Open the dev repo instead of the prod repo?
#'
#'@export
viewRemoteRepo <- function(dev = FALSE) {

  if(dev) {
    n <- "dev-repo"
  } else {
    n <- "repo"
  }

  browseURL(paste0(getOption("mmgeRepo.repo_base_url"), n))

}