confirmUpdate <- function(pkg, increment, merge_with) {

  desc_path <- file.path(pkg, "DESCRIPTION")

  d <- readLines(desc_path)
  vl <- grep("^Version", d)
  v <- as.numeric(unlist(strsplit(regmatches(d[vl], regexec("[0-9]+\\.[0-9]+\\.[0-9]+", d[vl]))[[1]], "\\.")))
  ov <- paste(v, collapse = ".")

  if(increment == "patch") {
    v[3] <- v[3] + 1
  } else if(increment == "minor") {
    v[3] <- 0
    v[2] <- v[2] + 1
  } else if(increment == "major") {
    v[3] <- 0
    v[2] <- 0
    v[1] <- v[1] + 1
  }
  nv <- paste(v, collapse = ".")

  n <- gsub("Package", "", d[grep("^Package", d)])
  n <- trimws(gsub(":", "", n))

  b <- system(glue::glue("git -C {pkg} rev-parse --abbrev-ref HEAD"), intern = TRUE)

  msg <- paste0("Update the `", b, "` branch of ", n, " from v", ov, " to ", nv)

  if(is.null(merge_with)) {
    msg <- paste0(msg,"? (y/N)")
  } else {
    msg <- paste0(msg, ", then merge with `", merge_with, "` branch? (y/N)")
  }
  r <- readline(msg)
  if(tolower(r) %in% c("y", "yes", "true")) {
    return(TRUE)
  } else {
    message("Update Aborted")
    return(FALSE)
  }

}