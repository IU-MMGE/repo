update_package_date <- function(pkg_dir, date = Sys.Date()) {

  desc_path <- file.path(pkg_dir, "DESCRIPTION")

  d <- readLines(desc_path)
  dl <- grep("^Date", d)

  if(length(dl) == 0) {
    vl <- grep("^Version", d)
    d <- c(d[1:vl], "Date: 1900-01-01", d[(vl+1):length(d)])
    dl <- vl+1
  }

  d[dl] = glue::glue("Date: {date}")

  f <- file(desc_path)
  writeLines(d, f)
  close(f)

}