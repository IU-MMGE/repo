testForPackage <- function(pkg) {
  if(dir.exists(pkg)) {
    if(!dir.exists(file.path(pkg, "R"))) {
      stop("`", pkg, "` does not appear to contain an R package")
    }
    if(!file.exists(file.path(pkg, "DESCRIPTION"))) {
      stop("`", pkg, "` does not appear to contain an R package")
    }
    return(TRUE)
  } else {
    stop("`pkg` should be a directory with an R package structure.")
  }
}