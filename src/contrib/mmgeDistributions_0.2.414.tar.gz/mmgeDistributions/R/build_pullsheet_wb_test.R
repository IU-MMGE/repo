#'@export
build_pullsheet_wb_test <- function(..., pull, aliquot, extract,combine, box_design,
                               check_depletion_levels=T, summary_sheet = T,
                               dir = "." , box_sheet=T, position=F,
                               ref_pool_exclude = c(9999999) ,multiple_per_visit=F,box_size=81,number_of_children = 1,number_of_children2 = 0,
                               visit_type = "VISIT",query,split_design=NULL,arrange_box_vars="FINAL_RUN_NO") {
  extra_sheets <- list(...)

  if(number_of_children2==0){
    number_of_children2=number_of_children
  }

  if(missing(box_size)){
    box_size = 81
  }

  if(!missing(pull)) {
    pull <- dplyr::ungroup(pull)
  }
  if(!missing(aliquot)) {
    aliquot <- dplyr::ungroup(aliquot)
  }
  if(!missing(extract)) {
    extract <- dplyr::ungroup(extract)
  }
  if(!missing(combine)) {
    combine <- dplyr::ungroup(combine)
  }

  config = mmgeDistributions:::get_pullsheet_config(dir)

  if(missing(check_depletion_levels)) {
    check_depletion_levels = TRUE
  }

  extra_fields <- unique(c(config$extra_fields,"SPECIMEN_COMMENTS","STORAGE_CONTAINER"))
  if(!missing(box_design)) {
    extra_fields <- unique(c(extra_fields, config$balance_vars))
  }

  if(!missing(pull)) {
    if(nrow(pull) > 0) {
      pull <- pull %>%
        select_pullsheet_fields(.dots = unique(extra_fields,"CELL_LINE_NAME"), dir = dir, box_name = "Pull",box_size = box_size)
    } else {
      pull <- NULL
    }
  } else {
    pull <- NULL
  }

  if(!missing(aliquot)) {
    aliquot_test = split_aliquots(aliquot,number_of_children)
    aliquot_test = create_aliquot_cols(aliquot_test,number_of_children,"Aliquot",box_size = box_size,extra_fields = extra_fields,dir = dir)
    aliquot = create_aliquot_cols(aliquot,number_of_children,"Aliquot",box_size = box_size,extra_fields = extra_fields,dir = dir)

  }
  else {
    aliquot <- NULL
    aliquot_test = NULL
  }

  if(!missing(extract)) {
    extract_test = split_aliquots(extract,number_of_children2)
    extract_test = create_aliquot_cols(extract_test,number_of_children2,"Extract",box_size = box_size,extra_fields = extra_fields,dir = dir)
    extract = create_aliquot_cols(extract,number_of_children2,"Extract",box_size = box_size,extra_fields = extra_fields,dir = dir)
  } else {
    extract <- NULL
    extract_test = NULL
  }

  if(!missing(combine)){
    if(nrow(combine) > 0) {
      combine <- combine %>%
        dplyr::mutate(COMB = 1,COMBINE_BAR_CODE = "")%>%
        dplyr::arrange_(.dots=c(config$subject_ids$blinded))%>%
        select_pullsheet_fields(.dots = c(extra_fields,"COMBINE_BAR_CODE","COMB"), dir = dir, box_name = "Combine",box_size = box_size)
      rearranged_colnames <- c("SPECIMEN_NO", "SPECIMEN_BAR_CODE", "COMBINE_BAR_CODE")
      cn <- colnames(combine)
      cn <- c(rearranged_colnames, cn[!cn %in% rearranged_colnames])
      combine <- dplyr::select_(combine, .dots = cn)
    } else {
      combine <- NULL
    }
  } else{
    combine = NULL
  }

  if(!missing(box_design)|box_sheet==T) {
    if(missing(box_design)){
      summary_box = mmgeDistributions:::create_box_sheet(pull,aliquot_test,extract_test,combine,subject = config$subject_ids$blinded,box_size = box_size)
    } else{
      summary_box <- tidy_box(pull,aliquot = aliquot_test,extract = extract_test,combine = combine,box_design,subject = config$subject_ids$blinded,
                              visit_type,position,multiple_per_visit,ref_pool_exclude,box_size = box_size,split_design = split_design,arrange_box_vars = arrange_box_vars)
    }


    summary_cols <- unique(c("SPECIMEN_BAR_CODE", "PATIENT_ID","ALTERNATE_MRN","SUBJECT_LAST_NAME","CASE_NO",config$subject_ids$blinded, "VISIT",
                      "COLLECTION_GROUP", "SPECIMEN_QUANTITY", "TEMP_BOX_NO", "TEMP_BOX_POSITION","LOCATION",
                      "FINAL_RUN_NO","FINAL_RUN", "FINAL_RUN_POSITION", "HEMOGLOBIN_ASSAY","FINAL_BOX_NO","FINAL_BOX_POSITION",arrange_box_vars))

    summary_cols <- summary_cols[summary_cols %in% colnames(summary_box)]

    box <- summary_box %>%
      dplyr::select_(.dots = summary_cols) %>%
      dplyr::mutate(SCANNED_BAR_CODE = NA)

    bingo <- box %>%
      arrange(TEMP_BOX_NO,TEMP_BOX_POSITION)

    from_children_box <- which(grepl("^[Aliquot|Extract]", box$TEMP_BOX_NO))
    from_children_bingo <- which(grepl("^[Aliquot|Extract]", bingo$TEMP_BOX_NO))
    from_children_style <- openxlsx::createStyle(border = "TopBottomLeftRight", borderColour = "#f1da2c", borderStyle = "medium")
    from_combine_box <- which(grepl("^[Combine]", box$TEMP_BOX_NO))
    from_combine_bingo <- which(grepl("^[Combine]", bingo$TEMP_BOX_NO))
    pull <- add_final_box_positions(pull, summary_box)
  }

  wb <- openxlsx::createWorkbook()
  if(!is.null(pull)){
    pull = pull%>%ungroup()%>%select(-TEMP_BOX_NO,-TEMP_BOX_POSITION)
  }
  if(!is.null(aliquot)){
    aliquot = aliquot%>%ungroup()%>%select(-TEMP_BOX_NO,-TEMP_BOX_POSITION)
  }
  if(!is.null(extract)){
    extract = extract%>%ungroup()%>%select(-TEMP_BOX_NO,-TEMP_BOX_POSITION)
  }
  if(!is.null(combine)){
    combine = combine%>%ungroup()%>%select(-TEMP_BOX_NO,-TEMP_BOX_POSITION)
  }
  mmgeDistributions:::addWorksheet(wb, "Pull", pull, tabColour = "#33cc33", pullsheet = TRUE)
  mmgeDistributions:::addWorksheet(wb, "Aliquot", aliquot, tabColour = "#f1da2c", pullsheet = TRUE)
  mmgeDistributions:::addWorksheet(wb, "Extract", extract, tabColour = "#FF9900", pullsheet = TRUE)
  mmgeDistributions:::addWorksheet(wb, "Combine", combine, tabColour = "#FF9900", pullsheet = TRUE)




  if(!missing(box_design)|box_sheet==T) {
    mmgeDistributions:::addWorksheet(wb, "Bingo", bingo%>%select(-TEMP_BOX_NO,-TEMP_BOX_POSITION), tabColour = "#6600cc")
    mmgeDistributions:::addWorksheet(wb, "Box", box%>%select(-TEMP_BOX_NO,-TEMP_BOX_POSITION), tabColour = "#0066cc")
    openxlsx::addStyle(wb, "Box", rows = c(from_combine_box+1,from_children_box+1), cols = 1, style = from_children_style, stack = TRUE)
    openxlsx::addStyle(wb, "Bingo", rows = c(from_combine_bingo+1,from_children_bingo+1), cols = 1, style = from_children_style, stack = TRUE)
    row_track = c()
    letter_track=3
    p=1
    y=1
    testchild =cbind(from_children_box,box[from_children_box,"SPECIMEN_BAR_CODE"])%>%
      arrange(SPECIMEN_BAR_CODE)
    from_children_box = testchild$from_children_box

    for(r in c(from_children_box,from_combine_box)) {
      if(grepl("^Combine", box$TEMP_BOX_NO[r])){
        s = combine
        sn = "Combine"
        box_row <- which(s$SPECIMEN_BAR_CODE == box$SPECIMEN_BAR_CODE[r])+1
        q = which(bingo$SPECIMEN_BAR_CODE==box$SPECIMEN_BAR_CODE[r])
        openxlsx::writeFormula(wb, "Box", startCol = 1, startRow = r+1, x = paste0("Combine!$C$", box_row))
        openxlsx::writeFormula(wb, "Bingo", startCol = 1, startRow = q[p]+1, x = paste0("Combine!$C$", box_row))

      } else{
        if(grepl("^Aliquot", box$TEMP_BOX_NO[r])) {
          s = aliquot
          sn = "Aliquot"
          number_of_children1 = number_of_children
        }
        if(grepl("^Extract", box$TEMP_BOX_NO[r])){
          s = extract
          sn = "Extract"
          number_of_children1 = number_of_children2
        }
        box_row <- which(s$SPECIMEN_BAR_CODE == box$SPECIMEN_BAR_CODE[r])+1
        row_track[y]=box_row
        if(y>1){
          if(box_row==row_track[y-1]){
            letter_track=letter_track+1
          }
        }
        if(letter_track>(number_of_children1+2)){
          letter_track = 3
        }
        letter = chartr("123456789","ABCDEFGHI",letter_track)

        q = which(bingo$SPECIMEN_BAR_CODE==box$SPECIMEN_BAR_CODE[r])

        openxlsx::writeFormula(wb, "Box", startCol = 1, startRow = r+1, x = paste0(sn,"!$",letter,"$", box_row))
        openxlsx::writeFormula(wb, "Bingo", startCol = 1, startRow = q[p]+1, x = paste0(sn,"!$",letter,"$", box_row))
        p = p+1
        if(p>number_of_children1){
          p=1
          letter_track = 3
        }
      }
      y=y+1
    }
    if(!missing(box_design)){
      mmgeDistributions:::addWorksheet(wb, "Box_Design", box_design)
      build_summary_sheets(wb, summary_box, dir = dir,multiple_per_visit=multiple_per_visit)
    }
    mmgeDistributions:::add_scanned_barcode(wb,"Box",box,box=T)
    mmgeDistributions:::add_scanned_barcode(wb,"Bingo",bingo,box=T)
    if(missing(box_design)){
      openxlsx::removeWorksheet(wb,"Bingo")
    }
  }

  if(check_depletion_levels) {
    dc = depletion_table(pull = pull,aliquot = aliquot,extract = extract,combine = combine,query = query)
    mmgeDistributions:::addWorksheet(wb, "Depletion_Check", data = dc)
  }

  if(length(extra_sheets) > 0) {
    for(i in seq(length(extra_sheets))) {
      mmgeDistributions:::addWorksheet(wb, names(extra_sheets)[i], extra_sheets[[i]])
    }
  }

  if(summary_sheet == T){
    mmgeDistributions:::addWorksheet(wb,"Summary",mmgeDistributions:::summarysheet(pull=pull,aliquot=aliquot,extract=extract,combine = combine,dir=dir,number_of_children = number_of_children,
                                                                                   number_of_children2 = number_of_children2))
  }

  wb = inventory_sheet(wb,pull,aliquot,extract,combine)

  return(invisible(wb))

}