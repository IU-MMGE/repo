#'@export

inventory_sheet = function(wb,pull,aliquot,extract,combine){
  if(!is.null(pull)){
    datax = dplyr::select(dplyr::ungroup(pull),SPECIMEN_BAR_CODE,STORAGE_CONTAINER,
                          if("STORAGE_LOCATION"%in%colnames(pull)){
                            "STORAGE_LOCATION"
                          },if("FREEZER"%in%colnames(pull)){
                            "FREEZER"
                          },if("TOWER"%in%colnames(pull)){
                            "TOWER"
                          },if("LEVEL"%in%colnames(pull)){
                            "LEVEL"
                          },if("SHELF"%in%colnames(pull)){
                            "SHELF"
                          },if("RACK"%in%colnames(pull)){
                            "RACK"
                          },if("RACKSHELF"%in%colnames(pull)){
                            "RACKSHELF"
                          },if("BOX"%in%colnames(pull)){
                            "BOX"
                          },if("POSITION"%in%colnames(pull)){
                            "POSITION"
                          },
                          COLLECTION_GROUP)%>%
      #dplyr::left_join(select(ungroup(box),SPECIMEN_BAR_CODE),by="SPECIMEN_BAR_CODE")%>%
      dplyr::mutate(SCANNED_BAR_CODE="",QC="",DATE="",INITALS="")
    mmgeDistributions:::addWorksheet(wb,"Pull Inventory",datax)
    add_scanned_barcode(wb,"Pull Inventory",datax,box=F)
  }
  if(!is.null(aliquot)){
    datay = dplyr::select(dplyr::ungroup(aliquot),SPECIMEN_BAR_CODE,STORAGE_CONTAINER,
                          if("STORAGE_LOCATION"%in%colnames(aliquot)){
                            "STORAGE_LOCATION"
                          },if("FREEZER"%in%colnames(aliquot)){
                            "FREEZER"
                          },if("TOWER"%in%colnames(aliquot)){
                            "TOWER"
                          },if("LEVEL"%in%colnames(aliquot)){
                            "LEVEL"
                          },if("SHELF"%in%colnames(aliquot)){
                            "SHELF"
                          },if("RACK"%in%colnames(aliquot)){
                            "RACK"
                          },if("RACKSHELF"%in%colnames(aliquot)){
                            "RACKSHELF"
                          },if("BOX"%in%colnames(aliquot)){
                            "BOX"
                          },if("POSITION"%in%colnames(aliquot)){
                            "POSITION"
                          },
                          COLLECTION_GROUP)%>%
      #dplyr::left_join(select(ungroup(box),SPECIMEN_BAR_CODE),by="SPECIMEN_BAR_CODE")%>%
      dplyr::mutate(SCANNED_BAR_CODE="",QC="",DATE="",INITALS="")
    mmgeDistributions:::addWorksheet(wb,"Aliquot Inventory",datay)
    add_scanned_barcode(wb,"Aliquot Inventory",datay,box=F)
  }
  if(!is.null(extract)){
    dataz = dplyr::select(dplyr::ungroup(extract),SPECIMEN_BAR_CODE,STORAGE_CONTAINER,
                          if("STORAGE_LOCATION"%in%colnames(extract)){
                            "STORAGE_LOCATION"
                          },if("FREEZER"%in%colnames(extract)){
                            "FREEZER"
                          },if("TOWER"%in%colnames(extract)){
                            "TOWER"
                          },if("LEVEL"%in%colnames(extract)){
                            "LEVEL"
                          },if("SHELF"%in%colnames(extract)){
                            "SHELF"
                          },if("RACK"%in%colnames(extract)){
                            "RACK"
                          },if("RACKSHELF"%in%colnames(extract)){
                            "RACKSHELF"
                          },if("BOX"%in%colnames(extract)){
                            "BOX"
                          },if("POSITION"%in%colnames(extract)){
                            "POSITION"
                          },
                          COLLECTION_GROUP)%>%
      #dplyr::left_join(select(ungroup(box),SPECIMEN_BAR_CODE),by="SPECIMEN_BAR_CODE")%>%
      dplyr::mutate(SCANNED_BAR_CODE="",QC="",DATE="",INITALS="")
    mmgeDistributions:::addWorksheet(wb,"Extract Inventory",dataz)
    add_scanned_barcode(wb,"Extract Inventory",dataz,box=F)
  }
  if(!is.null(combine)){
    dataz = dplyr::select(dplyr::ungroup(combine),SPECIMEN_BAR_CODE,STORAGE_CONTAINER,
                          if("STORAGE_LOCATION"%in%colnames(combine)){
                            "STORAGE_LOCATION"
                          },if("FREEZER"%in%colnames(combine)){
                            "FREEZER"
                          },if("TOWER"%in%colnames(combine)){
                            "TOWER"
                          },if("LEVEL"%in%colnames(combine)){
                            "LEVEL"
                          },if("SHELF"%in%colnames(combine)){
                            "SHELF"
                          },if("RACK"%in%colnames(combine)){
                            "RACK"
                          },if("RACKSHELF"%in%colnames(combine)){
                            "RACKSHELF"
                          },if("BOX"%in%colnames(combine)){
                            "BOX"
                          },if("POSITION"%in%colnames(combine)){
                            "POSITION"
                          },
                          COLLECTION_GROUP)%>%
      #dplyr::left_join(select(ungroup(box),SPECIMEN_BAR_CODE),by="SPECIMEN_BAR_CODE")%>%
      dplyr::mutate(SCANNED_BAR_CODE="",QC="",DATE="",INITALS="")
    mmgeDistributions:::addWorksheet(wb,"Combine Inventory",dataz)
    add_scanned_barcode(wb,"Combine Inventory",dataz,box=F)
  }
  return(wb)
}