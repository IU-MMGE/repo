#MISC

#'@export
better_left_join = function(x,y,key){
  require(data.table)
  x1 = data.table(x,key = key)
  y1 = data.table(y,key = key)
  return(as.data.frame(x1[x2]))
}

#'@export
allfac = function(data){
  for(i in names(data)){
    eval(parse(text = paste0("data$`",i,"` = as.factor(data$`",i,"`)")))
  }
  return(data)
}

#'@export
allchar = function(data){
  for(i in names(data)){
    eval(parse(text = paste0("data$`",i,"` = as.character(data$`",i,"`)")))
  }
  return(data)
}

