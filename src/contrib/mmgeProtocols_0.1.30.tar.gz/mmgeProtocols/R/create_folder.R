create_folder <- function(protocol_name, folder_name, parent_dir, readme) {

  if(missing(readme)) {
    readme <- glue::glue(
"################################################################################
##
##  This is the {folder_name} folder for the {protocol_name} protocol. It contains
##  configuration files that affect how various automated processes interact
##  with this protocol. These files can be modified if you are comfortable doing
##  so but it is recommended that you contact someone from IT for help the first
##  time.
##
##  Thanks!
##
################################################################################")
  }

  readme <- yaml::yaml.load_file("/var/miniCRAN/mmgeverse/mmgeProtocols/inst/templates/master.yaml")$Catalogs$readme
  readme <- paste(strsplit(readme, "\n")[[1]], collapse = " ")

  dir <- protocol_path(protocol_name)
  if(!missing(parent_dir)) {
    dir <- file.path(dir, parent_dir)
  }
  dir <- file.path(dir, folder_name)

}