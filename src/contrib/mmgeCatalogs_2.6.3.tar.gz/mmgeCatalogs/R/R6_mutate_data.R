R6_mutate_data <- function() {

  db <- debugR::debug("mutate_data")

  if(private$config_obj$build$convert_buffy_coat) {
    private$catalog_obj[[private$config_obj$build$attribute_definitions$specimen_type]][private$catalog_obj[[private$config_obj$build$attribute_definitions$specimen_type]] == "BUFFY COAT"] <- "DNA"
  }

  mutates <- private$dictionary_obj[private$dictionary_obj$source == "mutate", c('catalog_id', 'formula')]
  if('grouping' %in% names(private$config_obj$build)) {
    gb <- private$config_obj$build$grouping
  } else if("grouping" %in% names(private$config_obj)) {
    warning("`grouping` should be moved under `build` in the config.yaml file.", call. = FALSE)
    gb <- private$config_obj$grouping
  } else {
    warning("No grouping section found under build. Grouping by standard groupings", call. = FALSE)
    gb <- unname(unlist(private$config_obj$build$attribute_definitions[c('subject_id', 'visit_id', 'specimen_type')]))
  }

  gb <- unique(c(gb[gb %in% colnames(private$catalog_obj)]))

  calculate_class <- function(x) {

    specimen_type <- x[private$config_obj$build$attribute_definitions$specimen_type]
    units <- x[private$config_obj$build$attribute_definitions$unit_of_measure]
    quantity <- as.numeric(x[private$config_obj$build$attribute_definitions$specimen_quantity])

    distribution_rules <- private$config_obj$build$distribution_rules[[specimen_type]]

    if(length(distribution_rules) < 1) {
      return("excluded type")
    }

    if(!'parents' %in% names(distribution_rules)) {
      distribution_rules$parents <- TRUE
    }

    if(any(is.na(c(specimen_type, units, quantity)))) {
      return("missing data")
    }

    if(any(distribution_rules$size == "any")) {
      if(length(distribution_rules$size) > 1) {
        warning("`size` for ", specimen_type, " in distribution rules has `any` plus other values. `any` overrides other values.")
      }
      if(quantity > 0) {
        if('threshold' %in% names(distribution_rules)) {
          if(quantity >= distribution_rules$threshold) {
            return("distributable")
          } else {
            return("residual")
          }
        } else {
          return("distributable")
        }
      }
    }

    if(!(units %in% distribution_rules$units || units == "any")) {
      if(specimen_type %in% c("DNA", "RNA")) {
        if(quantity >= distribution_rules$size[1] * 2) { # fudge factor
          if(distribution_rules$parent) {
            return("parent")
          } else {
            return("ignored_parent")
          }
        } else {
          return("distributable")
        }
      }
      return("bad_units")
    }

    if(quantity < min(distribution_rules$size)) {
      return("residual")
    }

    if(quantity %in% distribution_rules$size) {
      return('distributable')
    } else {
      if(distribution_rules$count == 'sum') {
        return('distributable')
      } else if(quantity < min(distribution_rules$size) * 2) {
        return('distributable') # If you cant get more than one aliquot from a specimen consider it distributable, rather than a parent
      } else if(distribution_rules$parents) {
        if(distribution_rules$count == 'virtual') {
          return('virtual_parent')
        } else {
          return('parent')
        }
      } else {
        return("ignored_parent")
      }
    }

    return('unknown')

  }

  count_aliquots <- function(x) {

    specimen_type <- x[private$config_obj$build$attribute_definitions$specimen_type]
    units <- x[private$config_obj$build$attribute_definitions$unit_of_measure]
    quantity <- as.numeric(x[private$config_obj$build$attribute_definitions$specimen_quantity])

    distribution_rules <- private$config_obj$build$distribution_rules[[specimen_type]]

    specimen_class <- x['.__specimen_class']

    if(specimen_class == "distributable") {
      if(distribution_rules$count == 'sum') {
        return(max(1, floor(quantity / min(distribution_rules$size)) - 1))
      } else {
        return(1)
      }
    } else if(specimen_class == "virtual_parent") {
      distributable_quantity <- as.numeric(x[".__distributable_quantity"])
      if(units %in% distribution_rules$units) {
        return(max(1, floor(quantity / distributable_quantity) - 1))
      }
    }

    return(0)

  }

  calculate_distributable_quantity <- function(x) {

    specimen_type <- x[[private$config_obj$build$attribute_definitions$specimen_type]]
    units <- x[[private$config_obj$build$attribute_definitions$unit_of_measure]]
    quantity <- as.numeric(x[[private$config_obj$build$attribute_definitions$specimen_quantity]])

    distribution_rules <- private$config_obj$build$distribution_rules[[specimen_type]]

    specimen_class <- x[['.__specimen_class']]

    default_quantity <- distribution_rules$size[1]

    if(any(distribution_rules$size == 'any')) {
      return(quantity)
    } else if(distribution_rules$count == 'sum') {
      return(default_quantity)
    } else if(specimen_class == 'distributable') {
      return(default_quantity)
    } else if(specimen_class %in% c('parent', 'virtual_parent')) {
      return(default_quantity)
    } else {
      return(-1)
    }

  }

  calculate_distribution_potential <- function(x) {
    return(as.numeric(x['.__aliquot_count']) > 0 || grepl("parent", x['.__specimen_class'], fixed = TRUE))
  }

#  base::debug(count_aliquots)
  # SPECIMEN-LEVEL STANDARD MUTATIONS
  df <- private$catalog_obj
  specimen_types <- names(private$config_obj$build$distribution_rules)
  df <- df[df[[private$config_obj$build$attribute_definitions$specimen_type]] %in% specimen_types, ]
  df$`.__specimen_class` <- unname(unlist(apply(df, 1, calculate_class)))
  df$`.__distributable_quantity` <- unname(unlist( apply(df, 1, calculate_distributable_quantity)))
  df$`.__aliquot_count` <- unname(unlist(apply(df, 1, count_aliquots)))
  df$`.__distribution_potential` <- unname(unlist(apply(df, 1, calculate_distribution_potential)))

  # Replace parent units with standard child units
  uom <- private$config_obj$build$attribute_definitions$unit_of_measure
  if(uom %in% colnames(df)) {
    dr <- distribution_rules <- private$config_obj$build$distribution_rules
    st <- private$config_obj$build$attribute_definitions$specimen_type
    df[[uom]] <- sapply(seq(nrow(df)), function(i) {
      if(df$.__specimen_class[i] %in% c("parent", "virtual_parent")) {
        dr[[df[[st]][i]]]$units[1]
      } else {
        df[[uom]][i]
      }
    })
  }

##  df[private$config_obj$build$attribute_definitions$specimen_quantity] <- apply(df, 1, modify_quantity)

#  df <- dplyr::group_by(df, .dots = gb)

  attrs = private$config_obj$build$attribute_definitions

  # decide which fields to group on before calculating mutations
  excluded_sources <- c("mutate", "standard_field", private$dictionary_obj$source[grepl("^_", private$dictionary_obj$source)])
  fields <- unique(c(attrs$subject_id, attrs$visit_id, attrs$specimen_type, private$dictionary_obj$source_id[!private$dictionary_obj$source %in% excluded_sources]))
  fields <- fields[!fields %in% gb]
#  fields <- fields[!fields == attrs$unit_of_measure] # Remove unit_of_measure field to prevent parent problems for things like RNA

  df <- dplyr::group_by(df, .dots = gb)

  myMode <- function(x, class, overwrite = FALSE) {
    #    print(x)

    x[x == "NA"] <- NA

    dist <- sort(x[class == "distributable"], na.last = TRUE)
    not_dist <- sort(x[class != "distributable"], na.last = TRUE)

    udist <- unique(dist[!is.na(dist)])
    undist <- unique(not_dist[!is.na(not_dist)])

    # If there is only 1 non-NA value for distributable records, return that value
    if(length(udist) == 1) {
      if(overwrite) {
        return(rep(udist, times = length(x)))
      } else {
        x[is.na(x)] <- udist
        return(x)
      }
    }

    # If there are no non-NA values for distributable records, but there are non-NA
    # records for non-distributable records assign the most common non-distributable
    # value
    if(length(udist) == 0 && length(undist) > 0) {
      m <- undist[which.max(tabulate(match(not_dist, undist)))]
      x[is.na(x)] <- m
      return(x)
    }
    # If there are multiple non-NA values for distributable records and NAs exist,
    # apply the most common non-NA distributable for NAs
    if(length(udist) > 1) {
      m <- udist[which.max(tabulate(match(dist, udist)))]
      if(overwrite) {
        if(sum(undist %in% udist) < length(udist)) {
          x[class != "distributable"] <- m
        }
      }
      x[is.na(x)] <- m
      return(x)
    }

    return(x)

  }

  for(field in fields) {
    df <- eval(str2expression(glue::glue("dplyr::mutate(df, `{field}` = myMode(`{field}`, .__specimen_class, overwrite = {field == attrs$unit_of_measure}))")))
  }

  # group by before mutations
  df <- eval(str2expression(glue::glue("dplyr::group_by(df, {paste('`', c(gb, fields), '`', sep = '', collapse = ', ')})")))

  # cnt = 0
  # df <- dplyr::mutate(df, .__group_id = {cnt = cnt + 1; cnt})

  # I'm not super happy with this solution but its the only way I have managed
  # to get custom functions to be available for mutations...
  df <- local({
    sample_id <- function(samp) {
      min(as.numeric(gsub("\\..*$", "", samp)))
    }
    if('scripts' %in% list.dirs(self$catalog_dir, full.names = FALSE, recursive = FALSE)) {
      if("mutates.R" %in% list.files(file.path(self$catalog_dir, 'scripts'), full.names = FALSE, recursive = FALSE)) {
        source(file.path(self$catalog_dir, 'scripts', 'mutates.R'))
      }
    }
    x <- df
    if(nrow(mutates) > 0) {
      for(i in seq(nrow(mutates))) {
        cn <- mutates$catalog_id[i]
        expr <- mutates$formula[i]
        x <- eval(str2lang(glue::glue("(function() {{dplyr::mutate(x, `{cn}` = {expr})}})()")))
      }
    }

    return(x)

  })

  # This was moved higher up to increase efficiency (fewer records to mutate over)
  # df <- dplyr::filter(df, `.__distribution_potential` ==  TRUE)

  samp_id <- private$dictionary_obj[private$dictionary_obj$source == "_sample_id", ]
  if(nrow(samp_id) > 0) {
    samp_id <- as.list(samp_id)
    sample_id_formula <- samp_id$formula
    if(is.na(sample_id_formula)) {
      message("Using default sample_id calculation. Add `formula` attribute to the `_sample_id` field in the dictionary to override.")
      sample_id_formula <- glue::glue("sample_id({private$config_obj$build$attribute_definitions$specimen_id})")
    }
    sample_id <- function(samp) {
      min(as.numeric(gsub("\\..*$", "", samp)))
    }
    df <- dplyr::group_by(df, .dots = c(gb, '.__distributable_quantity'))
    df <- eval(str2lang(glue::glue("(function() {{dplyr::mutate(df, `{samp_id$catalog_id}` = {sample_id_formula})}})()")))
    if("_catalog_count" %in% private$dictionary_obj$source) {
      ctlg_cnt <- as.list(private$dictionary_obj[private$dictionary_obj$source == "_catalog_count", ])
      ctlg_cnt_formula <- ctlg_cnt$formula
      if(is.null(ctlg_cnt_formula)) {
        message("Using default specimen count calculation. Add `formula` attribute to the `_catalog_count` field in the dictionary to override.")
        ctlg_cnt_formula = "sum(.__aliquot_count)"
      }
      df <- eval(str2lang(glue::glue("(function() {{dplyr::mutate(df, `{ctlg_cnt$catalog_id}` = {ctlg_cnt_formula})}})()")))
    }
  }

  if(private$config_obj$build$ignore_case == TRUE) {
    colnames(df) <- toupper(colnames(df))
  }

  # Remove non-distributable aliquots
  df <- dplyr::filter(df, `.__distribution_potential` ==  TRUE)

  df <- dplyr::ungroup(df)

  private$catalog_obj <- df

  return(invisible(self))

}