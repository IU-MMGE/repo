#'@export
set_config <- function(key, value, append = TRUE, dir = ".") {

  x <- get_pullsheet_config(dir)

  if(key %in% c("number", "subject", "order_name", "directory")) {
    stop("You may not modify the `", key, "` value.", call. = FALSE)
  }

  y <- eval(parse(text = paste("x", key, sep = "$")))

  if(!is.null(y)) {
    if(append) {
      y <- unique(c(y, value))
    }
  } else {
    y <- value
  }

  eval(parse(text = glue::glue("x${key} <- y")))

  yaml::write_yaml(x, file = file.path(dir, "config.yaml"))

  return(invisible(TRUE))

}