#'@export

create_pullsheet_redcap = function(protocol,oncore_request_id, name,collection_group,number,overwrite=F,record_id,open=F,specimen_quantity,DCR = FALSE){

  if(!missing(record_id)){
    rcon = redcapAPI::redcapConnection(url = "https://redcap.uits.iu.edu/api/",token = "AAAAA96CCB080D300451B4976E75A624")
    table = redcapAPI::exportReports(rcon,34610,labels = F)

    num = which(colnames(table)=="aliquots_dna")
    num2 = which(colnames(table)=="aliquots_buffy")
    x = num:num2%%2 != 0
    x1 = num:num2

    table_data = as.data.frame(matrix(c(x1[x],"DNA","DNA","RNA","RNA","PLASMA","PLASMA PK",
                                        "PLASMA","PLASMA","SERUM","SERUM PK","WBLD","WBLD","CSF",
                                        "URINE","SALIVA","RBCWBC","PBMC","LCL","PBMC",
                                        "FIBROBLAST","BUFFY COAT"),byrow=F,ncol=2))
    colnames(table_data) = c("id","CG")


    protocol = table$oncore_protocol_number[table$record_id==record_id]
    if(grepl("CTSI-IB",protocol)){
      protocol="MMGE-CTSI-IB"
    }
    if(grepl("Protocol not in Oncore",protocol)){
      protocol = "MMGE-ALL"
    }
    if(grepl("NA",protocol)){
      protocol = "MMGE-ALL"
    }
    if(is.na(protocol)){
      protocol = "MMGE-ALL"
    }
    oncore_request_id = table$oncore_request_num1[table$record_id==record_id]
    name = gsub(" ","_",table$researcher[table$record_id==record_id],fixed=T)

    y=c()
    j=1
    for (i in x1[x]){
      if(!is.na(table[table$record_id==record_id,i])){
        y[j] = i
        j = j+1
      }
    }
    if(length(y)==0){
      collection_group = "NA"
      if(!missing(record_id)){
        specimen_quantity = "NA"
      }
      if(!grepl("[[:digit:]]", specimen_quantity)){
        specimen_quantity = "NA"
      }
    }
    if(length(y)==1){
      collection_group = table_data[table_data$id==y,2]
      if(!missing(record_id)){
        specimen_quantity = table[table$record_id==record_id,y+1]
      }
      if(!grepl("[[:digit:]]", specimen_quantity)){
        specimen_quantity = "NA"
      }
    }
    if(length(y)>1){
      collection_group = noquote(paste("[",paste0(table_data[table_data$id%in%y,2],collapse=","),"]",sep=""))
      if(!missing(record_id)){
        specimen_quantity = c()
        m=1
        for(i in y){
          specimen_quantity[m] = table[table$record_id==record_id,i+1]
          m=m+1
        }
        specimen_quantity = paste0(specimen_quantity,collapse=":")
        if(any(!grepl("[[:digit:]]", specimen_quantity))){
          specimen_quantity = "NA"
        }
      }
    }
  }

  if(missing(specimen_quantity)&missing(record_id)){
    specimen_quantity=0
  }

  if(missing(number)){
    number=1
  }
  if(DCR){
    if(!dir.exists(file.path("/media/R/zagoodma/PULLSHEETS/DCR",name))){
      dir.create(file.path("/media/R/zagoodma/PULLSHEETS/DCR",name))
      dir.create(file.path("/media/R/zagoodma/PULLSHEETS/DCR",name,"R"))
      dir.create(file.path("/media/R/zagoodma/PULLSHEETS/DCR",name,"Pullsheet"))
      dir.create(file.path("/media/R/zagoodma/PULLSHEETS/DCR",name,"R","data"))
      dir.create(file.path("/media/R/zagoodma/PULLSHEETS/DCR",name,"R","samples"))
    }
    if(!file.exists(file.path("/media/R/zagoodma/PULLSHEETS?DCR",name,"R",paste(name,".Rproj",sep="")))|overwrite==T){
      write.rproj(protocol="DCR",oncore_request_id = "DCR",name,DCR=TRUE)
      write.pullsheet.dcr.r(name)
    }

    if(!missing(record_id)){
      if(!is.na(table$subj_visit_select_file[table$record_id==record_id])){
        redcapAPI::exportFiles(rcon,record = record_id,field="subj_visit_select_file",dir=file.path("/media/R/zagoodma/PULLSHEETS/DCR",name,"R","samples"))
      }
      if(!is.na(table$clinical_data_file[table$record_id==record_id])){
        redcapAPI::exportFiles(rcon,record = record_id,field="clinical_data_file",dir=file.path("/media/R/zagoodma/PULLSHEETS/DCR",name,"R","data"))
      }
    }

    if(open==T){
      rstudioapi::openProject(file.path("/media/R/zagoodma/PULLSHEETS/DCR",name,"R",paste(name,".Rproj",sep="")))
    }
    if(open==F){
      return(file.path("/media/R/zagoodma/PULLSHEETS/DCR",name,"R",paste(name,".Rproj",sep="")))
    }
  }
  if(!DCR){
    if(!dir.exists(file.path("/media/R/zagoodma/PULLSHEETS",protocol,paste(oncore_request_id,name,sep="_")))){
      dir.create(file.path("/media/R/zagoodma/PULLSHEETS",protocol,paste(oncore_request_id,name,sep="_")))
      dir.create(file.path("/media/R/zagoodma/PULLSHEETS",protocol,paste(oncore_request_id,name,sep="_"),"R"))
      dir.create(file.path("/media/R/zagoodma/PULLSHEETS",protocol,paste(oncore_request_id,name,sep="_"),"Pullsheet"))
      dir.create(file.path("/media/R/zagoodma/PULLSHEETS",protocol,paste(oncore_request_id,name,sep="_"),"R","data"))
      dir.create(file.path("/media/R/zagoodma/PULLSHEETS",protocol,paste(oncore_request_id,name,sep="_"),"R","samples"))
    }

    if(!file.exists(file.path("/media/R/zagoodma/PULLSHEETS",protocol,paste(oncore_request_id,name,sep="_"),"R",paste(paste(oncore_request_id,name,sep="_"),".Rproj",sep="")))|overwrite==T){
      write.rproj(protocol,oncore_request_id,name)
      if(missing(record_id)){
        record_id2 = 0
      }
      if(!missing(record_id)){
        record_id2 = record_id
      }
      write.yaml(protocol,oncore_request_id,name,collection_group,number,specimen_quantity,record_id2)
      write.pullsheet.r(protocol,oncore_request_id,name)
    }

    if(!missing(record_id)){
      if(!is.na(table$subj_visit_select_file[table$record_id==record_id])){
        redcapAPI::exportFiles(rcon,record = record_id,field="subj_visit_select_file",dir=file.path("/media/R/zagoodma/PULLSHEETS",protocol,paste(oncore_request_id,name,sep="_"),"R","samples"))
      }
      if(!is.na(table$clinical_data_file[table$record_id==record_id])){
        redcapAPI::exportFiles(rcon,record = record_id,field="clinical_data_file",dir=file.path("/media/R/zagoodma/PULLSHEETS",protocol,paste(oncore_request_id,name,sep="_"),"R","data"))
      }
    }
    if(open==T){
      rstudioapi::openProject(file.path("/media/R/zagoodma/PULLSHEETS",protocol,paste(oncore_request_id,name,sep="_"),"R",paste(paste(oncore_request_id,name,sep="_"),".Rproj",sep="")))
    }
    if(open==F){
      return(file.path("/media/R/zagoodma/PULLSHEETS",protocol,paste(oncore_request_id,name,sep="_"),"R"))
    }
  }

}


#'@export
create_pullsheet_dcr = function(name,overwrite = FALSE,open=TRUE){
  if(!dir.exists(file.path("/media/R/zagoodma/PULLSHEETS/DCR",name))){
    dir.create(file.path("/media/R/zagoodma/PULLSHEETS/DCR",name))
    dir.create(file.path("/media/R/zagoodma/PULLSHEETS/DCR",name,"R"))
    dir.create(file.path("/media/R/zagoodma/PULLSHEETS/DCR",name,"Pullsheet"))
    dir.create(file.path("/media/R/zagoodma/PULLSHEETS/DCR",name,"R","data"))
    dir.create(file.path("/media/R/zagoodma/PULLSHEETS/DCR",name,"R","samples"))
  }
  if(!file.exists(file.path("/media/R/zagoodma/PULLSHEETS?DCR",name,"R",paste(name,".Rproj",sep="")))|overwrite==T){
    write.rproj(protocol="DCR",oncore_request_id = "DCR",name,DCR=TRUE)
    write.pullsheet.dcr.r(name)
  }
  if(open==T){
    rstudioapi::openProject(file.path("/media/R/zagoodma/PULLSHEETS/DCR",name,"R",paste(name,".Rproj",sep="")))
  }
  if(open==F){
    return(file.path("/media/R/zagoodma/PULLSHEETS/DCR",name,"R",paste(name,".Rproj",sep="")))
  }
}

write.pullsheet.dcr.r <- function(name) {

  required_packages <- c("dplyr", "openxlsx", "mmge", "mmgeDistributions", "mmgeMongo")

  libraries <- paste("library(", required_packages, ")", collapse = "\n", sep = "")

  info <- glue::glue(.sep = "\n",
                     glue::collapse(rep("#", times = 80)),
                     "##",
                     "##            Protocol: DCR",
                     "##        Project Name: {name}",
                     "##       Creation Date: {Sys.Date()}",
                     "##",
                     "##",
                     glue::collapse(rep("#", times = 80))
  )
  file <- file(file.path("/media/R/zagoodma/PULLSHEETS/DCR",name,"R","pullsheet.R"))
  wd = paste0("setwd(",paste0('"/media/R/zagoodma/PULLSHEETS/DCR/',name,'/R")'))
  pullsheet <- glue::glue(.sep = "\n",
                          "rm(list = ls())",
                          wd,
                          "",
                          libraries,
                          "",
                          info,
                          "",
                          "process_data_files('samples')",
                          "",
                          "query = moncore_query(,DCR=TRUE)",
                          "",
                          "pull1 <- query %>%",
                          "  semi_join()%>%",
                          "  group_by()%>%",
                          "  arrange_dcr()%>%",
                          "  filter(row_number()==1)",
                          "",
                          "files = load_from_mongo('DCR','FreezerFiles')",
                          "pull = pull1%>%left_join(files,by=c('DNANumber'='Barcode'))",
                          "build_dcr_pullsheet(pull = pull,subject_sheet = subject_sheet)",
                          "",
                          "brain_tissue = moncore_query(brain_tissue=TRUE)",
                          "brain_pull1 = brain_tissue%>%",
                          "  semi_join(,by=c())%>%",
                          "  anti_join(pull,by=c())%>%",
                          "  group_by()%>%",
                          "  filter(row_number()==1)",
                          "",
                          "brain_pull1$KitNumber = as.character(brain_pull1$KitNumber)",
                          "brain_pull = brain_pull1%>%",
                          "  left_join(files,by=c('KitNumber'='Barcode')",
                          "",
                          "openxlsx::write.xlsx(brain_pull,'brain_samples.xlsx',row.names=F)"
  )

  writeLines(pullsheet, file)

  close(file)

}

write.pullsheet.r <- function(protocol,oncore_request_id,name) {

  required_packages <- c("dplyr", "openxlsx", "mmge", "mmgeDistributions", "mmgeMongo")

  libraries <- paste("library(", required_packages, ")", collapse = "\n", sep = "")

  info <- glue::glue(.sep = "\n",
                     glue::collapse(rep("#", times = 80)),
                     "##",
                     "##            Protocol: {mmge::protocol_match(protocol,only_one = FALSE)}",
                     "##        Project Name: {name}",
                     "##   Oncore Request ID: {oncore_request_id}",
                     "##       Creation Date: {Sys.Date()}",
                     "##",
                     "##",
                     glue::collapse(rep("#", times = 80))
  )
  file <- file(file.path("/media/R/zagoodma/PULLSHEETS",protocol,paste(oncore_request_id,name,sep="_"),"R","pullsheet.R"))
  wd = paste0("setwd(",paste0('"/media/R/zagoodma/PULLSHEETS/',protocol,"/",paste(oncore_request_id,name,sep="_"),'/R")'))

  pullsheet <- glue::glue(.sep = "\n",
                          "rm(list = ls())",
                          wd,
                          "",
                          libraries,
                          "",
                          info,
                          "",
                          "process_data_files('samples')",
                          "",
                          "query = moncore_query()",
                          "",
                          "pull1 <- query %>%",
                          "  filter()%>%",
                          "  group_by()%>%",
                          "  final_check()%>%",
                          "  arrange(SPECIMEN_QUANTITY)%>%",
                          "  filter(row_number()==1)",
                          "",
                          "aliquot <- pull1%>%",
                          "  filter()",
                          "",
                          "pull = pull1%>%",
                          "  filter()",
                          "",
                          "box_design <- design_box.1(pull, aliquot, maximize_fullness = TRUE)",
                          "",
                          "wb <- build_pullsheet_wb_test(pull = pull, aliquot = aliquot, box_design = box_design, query = query)",
                          "file_name <- save_pullsheet_workbook(wb)",
                          ""
  )

  writeLines(pullsheet, file)

  close(file)

}

write.rproj <- function(protocol,oncore_request_id,name,DCR=FALSE) {
  if(DCR){
    file <- file(file.path("/media/R/zagoodma/PULLSHEETS",protocol,name,"R",paste(name,".Rproj",sep="")))

  } else{
    file <- file(file.path("/media/R/zagoodma/PULLSHEETS",protocol,paste(oncore_request_id,name,sep="_"),"R",paste(paste(oncore_request_id,name,sep="_"),".Rproj",sep="")))

  }

  writeLines(glue::glue(.sep = "\n",
                        "Version: 1.0",
                        "",
                        "RestoreWorkspace: Default",
                        "SaveWorkspace: Default",
                        "AlwaysSaveHistory: Default",
                        "",
                        "EnableCodeIndexing: Yes",
                        "UseSpacesForTab: Yes",
                        "NumSpacesForTab: 2",
                        "Encoding: UTF-8",
                        "",
                        "RnwWeave: Sweave",
                        "LaTeX: pdfLaTeX"
  ), file)

  close(file)

}

write.yaml <- function(protocol,oncore_request_id,name,collection_group,number,specimen_quantity,record_id) {

  kept_values <- c("number", "subject", "protocol", "project_name", "oncore_id",
                   "collection_group", "order_name", "directory", "assignees",
                   "submitter", "submitdate", "last_name", "first_name",
                   "username", "email_address", "descriptions")

  config = mmgeProtocols::get_protocol_settings(protocol)
  if(is.null(config$verbose)) {
    config$verbose <- TRUE
  }

  if(is.null(config$oncore_environment)) {
    config$oncore_environment <- "CLN"
  }

  if(is.null(config$only_available_specimens)) {
    config$only_available_specimens <- TRUE
  }
  config$record_id = record_id
  config$specimen_quantity = specimen_quantity
  config$directory = file.path("/media/R/zagoodma/PULLSHEETS",protocol,paste(oncore_request_id,name,sep="_"))
  config$order_name = paste(oncore_request_id,name,sep="_")
  config$project_name = name
  config$collection_group = collection_group
  config$number = noquote(as.character(number))

  if(config$collection_group%in%c("SERUM PK","PLASMA","iPSC","PBMC")|grepl("PK|PLASMA|iPSC|PBMC",collection_group)){
    config$additional_oncore_annotations = c("Collection Container","Cell Type")
    config$extra_fields = c("CELL_TYPE","COLLECTION_CONTAINER")
  }

  if(any(grepl("SEQUENCE_N",config$subject_ids))){
    config$additional_oncore_fields = c("SEQUENCE_NUMBER")
    config$extra_fields = c("SEQUENCE_NUMBER")
  }

  if(config$collection_group%in%c("DNA","BUFFY COAT","RNA")){
    config$extra_fields = c("INSTRUMENT_FOR_QC","CONCENTRATION","CONCENTRATION_UOM","VOLUME","VOLUME_UOM","DNA_SOURCE","GENOTYPED","LAST_DATE_GENOTYPED")
    config$additional_oncore_annotations = c("Instrument for QC","Concentration","Concentration UOM","Volume","Volume UOM","DNA Source","Genotyped","Last Date Genotyped")
  }
  if(length(config$extra_fields)>0){
    config$extra_fields = c(config$extra_fields,"STORAGE_CONTAINER")

  } else{
    config$extra_fields = "STORAGE_CONTAINER"
  }


  file <- file(file.path("/media/R/zagoodma/PULLSHEETS",protocol,paste(oncore_request_id,name,sep="_"), "R", "config.yaml"))

  writeLines(yaml::as.yaml(config), file)

  close(file)

}

write_rproj_user <- function(request_data) {

  dir.create(file.path(request_data$directory, ".Rproj.user"))
  dir.create(file.path(request_data$directory, "shared"))

}

#'@export
redcap_table = function(record_id){
  rcon = redcapAPI::redcapConnection(url = "https://redcap.uits.iu.edu/api/",token = "AAAAA96CCB080D300451B4976E75A624")
  table = redcapAPI::exportReports(rcon,34610)
  if(!missing(record_id)){
    table = table[table$record_id==record_id,]
  }
  return(table)
}
