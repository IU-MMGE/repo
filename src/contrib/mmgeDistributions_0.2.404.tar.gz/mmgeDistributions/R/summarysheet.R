summarysheet = function(pull,aliquot,extract,combine,dir="."){
  config = mmgeDistributions:::get_pullsheet_config(dir)
  subject_id = config$subject_ids$blinded
  record_id = config$record_id
  skip = FALSE
  if(is.null(record_id)){
    skip = TRUE
    record_id = 0
  }
  if(record_id == 0){
    skip = TRUE
  }


  all = bind_rows(pull,aliquot,extract,combine)
  allinfo = data.frame(
    `PULLSHEET_SUMMARY` = c(
      "# of Samples",
      "# of Subjects"
    ),
    `VALUE` = c(
      nrow(all%>%select(SPECIMEN_BAR_CODE)%>%distinct()),
      nrow(all%>%select(!!subject_id)%>%distinct())
    )
  )

  count = all%>%
    ungroup()%>%
    group_by(SPECIMEN_TYPE)%>%
    count()%>%
    mutate(PULLSHEET_SUMMARY = paste0("Number of ",SPECIMEN_TYPE," sample(s)"),VALUE = n)%>%
    ungroup()%>%
    select(PULLSHEET_SUMMARY,VALUE)%>%
    distinct()
  volume = all%>%
    ungroup()%>%
    group_by(SPECIMEN_TYPE)%>%
    mutate(sum = sum(SPECIMEN_QUANTITY,na.rm=TRUE))%>%
    mutate(PULLSHEET_SUMMARY = paste0("Volume of ",SPECIMEN_TYPE," sample(s)"),VALUE = sum)%>%
    ungroup()%>%
    select(PULLSHEET_SUMMARY,VALUE)%>%
    distinct()

  if(!skip){
    rcon = redcapAPI::redcapConnection(url = "https://redcap.uits.iu.edu/api/",token = "AAAAA96CCB080D300451B4976E75A624")
    table = redcapAPI::exportRecords(rcon,records = record_id)
    redcap = data.frame(matrix(c(
      "Study",table$study,
      "OnCore Protocol No.",table$oncore_protocol_number,
      "Study Arms",table$arms,
      "Visits",table$visits,
      "Visits other",table$visits_other,
      "Timepoints",table$timepoints,
      "Box Design Details",table$box_design_details,
      "Is it okay to deplete samples for this request?",as.character(table$deplete_okay_yn),
      "Is a specific box design required?",as.character(table$box_design_required_yn),
      "Is relabeling needed?",as.character(table$relabeling_needed),
      "Relabeling Details",table$relabeling_details
    )
    ,ncol = 2,byrow=TRUE)
    )
    names(redcap) = c("PULLSHEET_SUMMARY","VALUE")

    if(config$collection_group%in%c("DNA","CELL LINE","BUFFY COAT","RNA")){
      ex = data.frame(matrix(c(
        "DNA Concentration",table$dna_concentration,
        "DNA specifications",table$dna_specifications,
        "Cell Line / PBMC dropdown",table$cell_line_pbmc,
        "Cell type",table$cell_type,
        "Multiple aliquots",as.character(table$multiple_aliquots),
        "DNA quantity to retain",table$retain_qnty,
        "Minimum Concentration or Range:",table$dna_conc_range,
        "DNA Buffer",table$dna_buffer,
        "Is there a 260/280 requirement?",as.character(table$is_there_a_260_280_require),
        "260/280:",table$qc,
        "# of samples per DNA plate",table$plate_dna_num
      )
      ,ncol = 2,byrow=TRUE)
      )
      names(ex) = c("PULLSHEET_SUMMARY","VALUE")

    } else{
      ex = data.frame(matrix(c(
        "Study Samples per Run",table$samples_per_run,
        "Reference Pools per Run",table$ref_pools_per_run,
        "Reference Pools",table$reference_pools,
        "Additional Reference Pools (to be placed at the end of the final box)",table$addtl_ref_pools,
        "Include all longitudinal visits in one box?",as.character(table$include_long_visits),
        "What is the minimum quantity to retain?",table$minimum_retain_qnty
      )
      ,ncol = 2,byrow=TRUE)
      )
      names(ex) = c("PULLSHEET_SUMMARY","VALUE")
    }
    red = redcap%>%bind_rows(ex)

  } else{
    red = NULL
  }

  summary = bind_rows(allinfo,count,volume,red)

  return(summary)
}
