#' #' Create an MMGE specimen distribution project
#' #'
#' #' This is the starting point for any MMGE Distribution project. It reads from the
#' #' Footprints API and creates a standard project directory which should be used
#' #' by all parties involved in the distribution process.
#' #'
#' #' @param fp_id The Footprints Issue ID for the project
#' #' @param overwrite If the project already exists, should it be overwritten?
#' #' @param open = Should the distribution project be opend in a new window (new),
#' #'   the current window (current), or not at all (FALSE).
#' #'
#' #' @export
#' create_distribution <- function(fp_id, overwrite = FALSE, open = "new") {
#'
#'   request_data <- get_footprints_issue(fp_id)
#'
#'   if(dir.exists(request_data$directory)) {
#'     if(overwrite) {
#'       unlink(request_data$directory, recursive = TRUE)
#'     } else {
#'       stop(request_data$order_name, " already exists. If you want to start over set `overwrite = FALSE`", call. = FALSE)
#'     }
#'   }
#'
#'   dir.create(request_data$directory, recursive = TRUE)
#'
#'   directories <- c("R", "Pullsheet", "Manifest")
#'
#'   for(directory in directories) {
#'     dir.create(file.path(request_data$directory, directory), recursive = TRUE)
#'   }
#'
#'   create_r_project(request_data)
#'
#'   if(open == "new") {
#'     rstudioapi::openProject(file.path(request_data$directory, "R"), newSession = TRUE)
#'   } else if(open == "current") {
#'     rstudioapi::openProject(file.path(request_data$directory, "R"), newSession = FALSE)
#'   }
#'
#' }
