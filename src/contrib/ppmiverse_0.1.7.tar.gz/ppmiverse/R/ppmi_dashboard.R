#'@export
ppmi_dashboard <- function() {

  ui <- dashboardPage(title = "PPMI Dashboard",
    dashboardHeader(title = "PPMI Dashboard"),
    dashboardSidebar(
      sidebarMenu(id = 'sidebar_menu',
#        menuItem("Compliance Dashboard", tabName = "dashboard", icon = icon('dashboard')),
#        menuItem("Compliance Report", tabName = "report", icon = icon('book')),
        menuItem("LONI Data", tabName = "loni", icon = icon('table')),
        menuItem("Kit Scheduling", tabName = 'kits', icon = icon('calendar-alt'))
#        menuItem("Catalogs", tabName = 'catalogs', icon = icon('table')),
#        menuItem("Inventory", tabName = 'inventory', icon = icon('table'))
      )
    ),
    dashboardBody(
      tags$head(tags$link(rel='stylesheet', type='text/css', href = 'ppmiverse/style.css')),
      tags$head(tags$script(src = "https://mathjax.rstudio.com/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML")),
      tags$head(tags$script(src = 'ppmiverse/script.js')),
      tabItems(
        dashboard_ui('dashboard'),
        report_ui('report'),
        loni_data_ui('loni'),
        kit_schedule_ui('kits')
      )
    )
  )

  server <- function(input, output, session) {

    callModule(dashboard_server, 'dashboard')
    callModule(report_server, 'report')
    callModule(loni_data_server, 'loni')
    callModule(kit_schedule_server, 'kits')

  }

  shinyApp(ui, server)

}