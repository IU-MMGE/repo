#'Publish the PPMI dashboard to RStudio Connect
#'
#'A convenient way to publish the dashboard to RStudio Connect DEV or PRD
#'
#'@param where where to publish the dashboard
#'
#'\code{where} should be a server name that is returned when you run \code{rsconnect::servers(local = TRUE)}.
#'
#'@export
publish_dashboard <- function(where = 'connect_dev') {

  servers <- as.character(as.data.frame(rsconnect::servers(local = TRUE))$name)

  if(!where %in% servers) {

    stop("`where` must be one of:\n\n", paste("    ", servers, sep = "", collapse = "\n"), "\n\nand you must have registered your account on that server. \n\nSee `addServer` and `connectUser` in the rsconnect package for details.\n\n")

  }

  td <- file.path(tempdir(), "ppmi_dashboard")
  dir.create(td, recursive = TRUE)

  app <- "
library(shiny)
library(ppmiverse)

ppmi_dashboard()

"

  writeLines(app, con = file.path(td, "app.R"))

  rsconnect::deployApp(td, appName = "PPMI_Dashboard", server = where, account = Sys.info()['user'])


}