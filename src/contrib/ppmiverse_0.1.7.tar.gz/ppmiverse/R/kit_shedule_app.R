kit_schedule_ui <- function(id) {

  ns <- NS(id)

  months <- local({
    months <- as.Date(format(Sys.Date(), "%Y-%m-01"))
    lubridate::month(months) <- lubridate::month(months) + 1
    return(format(months, "%m-%Y"))
  })

  months <- as.Date(paste0("01-", months), format = "%d-%m-%Y")
  start_date <- min(months)
  end_date <- max(months)
  lubridate::day(end_date) <- lubridate::days_in_month(end_date)

  tabItem(id,

    fluidRow(
      column(width = 2,
        dateRangeInput(ns('dates'), NULL, start = start_date, end = end_date, max = as.Date("2030-12-31"), min = as.Date("2010-01-01"))
      ),
      column(width = 2,
        selectInput(ns('fields'), NULL, choices = c(), selected = c(), multiple = TRUE)
      ),
      # column(width = 3,
      #   sliderInput(ns('window'), "Window (days)", min = 0, max = 90, value = 30, step = 1)
      # ),
      column(width = 2,
        downloadButton(ns('download'))
      ),
      column(width=2, offset=4, style = "text-align: right;",
        textOutput(ns("update_date"))
      )
    ),
    DT::DTOutput(ns('report'))
  )

}

kit_schedule_server <- function(input, output, session) {

  schedule <- reactive({

    sd <- input$dates[1] + 30
    ed <- input$dates[2] + 30

    date_range_start <- glue::glue('{{"TARGET_DATE": {{"$gte": "{as.Date(sd)}"}}}}')
    date_range_end <- glue::glue('{{"TARGET_DATE": {{"$lte": "{as.Date(ed)}"}}}}')
    filter <- glue::glue('{{"$and": [{date_range_start}, {date_range_end}]}}')

    x <- mmgeMongo::load_from_mongo(settings$database, "kit_schedule_data", query = filter)

  })

  selected_schedule <- reactive({
    schedule()[, fields(), drop = FALSE]
  })

  output$update_date <- renderText({
    d <- mmgeMongo::load_from_mongo(settings$database, "kit_schedule_meta")
    return(paste0("Last Updated: ", d$updated))
  })

  fields <- reactive({
    if(is.null(input$fields)) {
      return(colnames(schedule()))
    } else {
      return(input$fields)
    }
  })

  observe({
    updateSelectInput(session, 'fields', choices = colnames(schedule()))
  })

  output$report <- DT::renderDT({

    dt <- selected_schedule()

    DT::datatable(dt, extensions = 'Scroller', rownames = FALSE, options = list(
      deferRender = TRUE,
      scrollY = 500,
      scroller = TRUE
    ))

  })

  output$download <- downloadHandler(
    filename = function() {
      glue::glue("ppmi_kit_schedule_{input$dates[1]}-{input$dates[2]}({Sys.Date()}).csv")
    },
    content = function(file) {
      write.csv(schedule(), file, row.names = FALSE)
    }
  )

}