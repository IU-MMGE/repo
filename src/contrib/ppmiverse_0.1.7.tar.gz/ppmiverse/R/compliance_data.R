#'@export
compliance_data <- function() {

  visits <- mmgeMongo::load_from_mongo(settings$database, 'visit_schedule')
  ppmi_sites <- mmgeMongo::load_from_mongo(settings$database, 'ppmi_sites')
  kit_samples <- local({
    kit_samples <- unlist(mmgeMongo::load_from_mongo(settings$database, "kit_sample_types", verbose = FALSE), recursive = FALSE)
    kit <- data.frame("KIT" = names(kit_samples), stringsAsFactors = FALSE)
    for(k in names(kit_samples)) {
      for(t in kit_samples[[k]]) {
        kit[kit$KIT == k, t] <- TRUE
      }
    }
    kit[is.na(kit)] <- FALSE
    return(kit)
  })

  build_date <- as.Date(Sys.time())
  end_date <- seq(as.Date(format(as.Date(build_date), "%Y-%m-01")), length.out = 2, by = "-1 months")[2] - 1
  loni_data <- mmgeMongo::load_from_mongo(settings$database, "compliance_data")

  kits_data <- tidyr::pivot_longer(visits, c(-when, -visit), names_to = "APPRDX", values_to = "KIT") %>%
    dplyr::filter(!is.na(KIT)) %>%
    dplyr::left_join(kit_samples, by = "KIT") %>%
    dplyr::mutate(APPRDX = dplyr::recode(APPRDX, !!!settings$arm_code_recode)) %>%
    dplyr::select(EVENT_ID = visit, MONTH = when, APPRDX, DNA_SCHEDULED = dna,
                  BIOMIC_SCHEDULED = biomic, URINE_SCHEDULED = urine,
                  CSF_SCHEDULED = csf, PBMC_SCHEDULED = pbmc)

  subject_data <- loni_data %>%
    dplyr::distinct(PATNO, CNO, BIRTHDT, ENROLLDT, APPRDX) %>%
    dplyr::group_by(PATNO) %>%
    dplyr::summarize(
      CNO = get_one(CNO),
      BIRTHDT = get_one(BIRTHDT),
      ENROLLDT = get_one(ENROLLDT),
      APPRDX = get_one(APPRDX)
    ) %>%
    dplyr::filter(!is.na(CNO))

  scheduled_visits <- subject_data %>%
    dplyr::filter(!is.na(ENROLLDT)) %>%
    dplyr::left_join(kits_data, by = "APPRDX") %>%
    dplyr::mutate(ENROLLDT = as.Date(ENROLLDT)) %>%
    dplyr::mutate(TARGET_DATE = (function(ed, when) {
      dt <- ed
      lubridate::month(dt) <- lubridate::month(dt) + when
      return(dt)
    })(ENROLLDT, MONTH)) %>%
    dplyr::filter(!is.na(EVENT_ID)) %>%
    dplyr::mutate(CNO = as.character(CNO)) %>%
    dplyr::select(CNO, PATNO, APPRDX, EVENT_ID, MONTH, TARGET_DATE, DNA_SCHEDULED,
                  BIOMIC_SCHEDULED, URINE_SCHEDULED, CSF_SCHEDULED,
                  PBMC_SCHEDULED)

  event_recode <- local({
    x <- names(settings$event_id_recode)
    names(x) <- unname(unlist(settings$event_id_recode))
    return(x)
  })

  completed_visits <- local({
    x <- loni_data %>%
      dplyr::filter(!is.na(EVENTDT)) %>%
      dplyr::filter(EVENT_ID %in% names(event_recode)) %>%
      dplyr::mutate(EVENT_ID = dplyr::recode(EVENT_ID, !!!event_recode)) %>%
      dplyr::select(CNO, PATNO, EVENT_ID, APPRDX, EVENTDT, URINE_COLLECTED = UASPEC,
                    RNA_COLLECTED = BLDRNA, PLASMA_COLLECTED = BLDPLAS,
                    SERUM_COLLECTED = BLDSER, DNA_COLLECTED = BLDDNA,
                    CSF_COLLECTED = CSFCOLL, LP_COMMENT = LUMCOMM, PDMEDYN)

    x[is.na(x)] <- "Not Collected"
    x$CSF_COLLECTED[x$CSF_COLLECTED == "Not Collected"] <- "Not Done"
    x$LP_COMMENT[x$LP_COMMENT == "Not Collected"] <- NA
    x$LP_COMMENT[x$LP_COMMENT == ""] <- NA
    x$PDMEDYN[x$PDMEDYN == "Not Collected"] <- "No"

    return(x)

  })

  all_visits <- dplyr::full_join(scheduled_visits, completed_visits, by = c("CNO", "PATNO", "EVENT_ID", "APPRDX")) %>%
    dplyr::filter(!is.na(TARGET_DATE)) %>%
    dplyr::left_join(ppmi_sites %>%
                       dplyr::mutate(Site = as.character(Site)) %>%
                       dplyr::select(CNO = Site, SITE = NickName), by = "CNO") %>%
    dplyr::filter(!is.na(SITE)) %>%
    dplyr::distinct(PATNO, EVENT_ID, .keep_all = TRUE) %>%
    dplyr::mutate(EVENTDT = as.Date(EVENTDT)) %>%
    dplyr::mutate(VISIT_DELTA = ifelse(is.na(EVENTDT), NA, EVENTDT - TARGET_DATE)) %>%
    dplyr::select(CNO, SITE, PATNO, APPRDX, EVENT_ID, TARGET_DATE, EVENTDT, VISIT_DELTA,
                  BIOMIC_SCHEDULED, RNA_COLLECTED, PLASMA_COLLECTED, SERUM_COLLECTED,
                  CSF_SCHEDULED, CSF_COLLECTED, LP_COMMENT, URINE_SCHEDULED,
                  URINE_COLLECTED, PDMEDYN)

  mmgeMongo::save_to_mongo(all_visits, settings$database, 'compliance_visits', indices = list("CNO", "PATNO", "TARGET_DATE", c("CNO", "TARGET_DATE")))

}
