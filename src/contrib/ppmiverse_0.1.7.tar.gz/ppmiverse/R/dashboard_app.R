dashboard_ui <- function(id) {

  ns <- NS(id)
  sites <- local({
    x <- mmgeMongo::load_from_mongo(settings$database, 'ppmi_sites')
    y <- x$Site
    names(y) <- paste0(x$NickName, " (", x$Site, ")")
    return(y)
  })

  tabItem(id,
    tags$script(paste0('$(document).ready(function() {initialize_options("', ns("") ,'")})')),
    tags$span(class = 'print-hidden',
      tags$h3(id = ns('screen_site_name'), class = 'shiny-text-output', style = 'display: inline-block; margin: 5px;'),

      tags$span(class = 'right-button-container',
        dateRangeInput(ns('window_select'), NULL, start = as.Date("2019-11-01"), end = as.Date("2019-11-30")),
        selectInput(ns('cno_select'), NULL, choices = sites, selected = 1, multiple = FALSE),
        tags$div(class = 'btn-group', role = 'group', style = 'margin-bottom: 10px;',
          tags$button(type = "button", class = 'btn btn-primary', id = ns('table-print'), icon('print'), "Print Table", onclick = 'window.print()'),
          tags$button(type = 'button', class = 'btn btn-primary', id = ns('table-legend'), icon('question-circle'), "Legend", title = "Table Legend", `data-container`='body', `data-trigger` = 'focus', `data-toggle` = 'popover', `data-placement` = 'left', `data-content` = legend(), `data-html` = TRUE),
          options_dropdown(ns)
        ),
        tags$script(glue::glue("$('#{ns('show_less')}').on('click', function() {{$('#{ns('comp_table')}').toggleClass('show_less', $('#{ns('show_less')}').is(':checked'))}})"))
      ),
      tags$script(glue::glue("$('#{ns('table-options')}').on('shown.bs.popover', function() {{Shiny.bindAll()}})"))
    ),
    tags$script(paste0("$('#", ns('table-legend'), "').popover();")),
    tags$script(paste0("$('#", ns('table-options'), "').popover();")),
    tags$div(class = 'shiny-input-container',
             tags$input(id = 'test', type = 'hidden', class = 'shiny-text-input', value = "")
    ),
    uiOutput(ns('site_visit_table'))
  )

}

dashboard_server <- function(input, output, session) {

  values <- reactiveValues(start_time = "")

  window_visits <- reactive({

    req(input$cno_select)

    values$start_time <- Sys.time()
    print(values$start_time)
    cno_filter <- glue::glue('{{"CNO": "{input$cno_select}"}}')
    date_range_start <- glue::glue('{{"TARGET_DATE": {{"$gte": "{as.Date(input$window_select[1])}"}}}}')
    date_range_end <- glue::glue('{{"TARGET_DATE": {{"$lte": "{as.Date(input$window_select[2])}"}}}}')
    filter <- glue::glue('{{"$and": [{cno_filter}, {date_range_start}, {date_range_end}]}}')

    x <- mmgeMongo::load_from_mongo(settings$database, "compliance_visits", query = filter)
    print("window_visits")
    return(x)
  })

  visit_data <- reactive({


    req(window_visits())

    subjects <- unique(window_visits()$PATNO)
    patno_filter <- glue::glue('{{"PATNO": {{"$in": [{paste("\\"", subjects, "\\"", sep = "", collapse = ",")}]}}}}')

    x <- mmgeMongo::load_from_mongo(settings$database, "compliance_visits", query = patno_filter)
    print('visit_data')
    return(x)

  })

  table_data <- reactive({

    req(visit_data())

    visit_data <- visit_data()
    visit_window <- c(-30, 30)
    report_window <- c(as.Date("2019-11-01"), as.Date("2019-11-30"))

    visit_data$WINDOW_CLASS <- apply(visit_data, 1, function(x) {
      vd <- as.numeric(x['VISIT_DELTA'])
      if(is.na(vd)) {
        if(x['TARGET_DATE'] < (Sys.Date() + visit_window[1])) {
          return('missed')
        } else {
          return('na')
        }
      } else if(vd >= visit_window[1] && vd <= visit_window[2]) {
        return("success")
      } else if(vd >= visit_window[1]*2 && vd <= visit_window[2]*2) {
        return("warning")
      } else if(vd < visit_window[1]*2 || vd > visit_window[2]*2) {
        return("error")
      } else {
        stop("Unhandled window situation")
      }
    })

    visit_data$CSF_CLASS <- apply(visit_data, 1, function(x) {

      scheduled <- x['CSF_SCHEDULED']
      collected <- x['CSF_COLLECTED']
      window <- x['WINDOW_CLASS']

      if(scheduled == FALSE) {
        return('na')
      } else if(window == 'missed') {
        return('missed')
      } else if(window == 'na') {
        return('na')
      } else if(collected == 'Not Done') {
        return("error")
      } else if(collected == 'Attempted, no collection') {
        return("warning")
      } else if(collected == 'Collected') {
        return("success")
      } else {
        stop("Unhandled csf situation")
      }

    })

    visit_data$MEDUSE_CLASS <- apply(visit_data, 1, function(x) {

      arm <- x['APPRDX']
      meduse <- x['PDMEDYN']

      if(arm %in% c("SWEDD", "Parkinson's disease", "Genetic Cohort - PD")) {
        if(is.na(meduse)) {
          return('unknown')
        } else if(meduse == "Yes") {
          return('success')
        } else if(meduse == "No") {
          return('error')
        } else {
          return('unknown')
        }
      } else {
        return("na")
      }

    })

    visit_data$CELL_CLASS <- apply(visit_data, 1, function(x) {

      window = x['WINDOW_CLASS']
      targetdt = as.Date(x['TARGET_DATE'])
      targetmin = targetdt + visit_window[1]
      targetmax = targetdt + visit_window[2]

      if(window == "missed") {
        return('missed')
      } else if(targetmin >= report_window[1] && targetmax <= report_window[2]) {
        return('window')
      } else if(window == 'na') {
        return('future')
      } else {
        return('past')
      }

    })

    print('table_data')
    return(visit_data)

  })

  output$site_visit_table <- renderUI({

    x <-

    return(glue::glue("{round(as.numeric(z), 1)}{attributes(z)$units}"))

  })

}