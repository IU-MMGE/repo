# mmgeMongo
base functions for connecting to MMGE's mongodb instance
