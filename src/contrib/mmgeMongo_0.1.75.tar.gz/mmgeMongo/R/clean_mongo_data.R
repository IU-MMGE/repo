clean_mongo_data = function(save_or_load, data) {
  if (save_or_load == "save") {
    names(data) = gsub(".", "@", names(data), fixed = TRUE)
  }
  if (save_or_load == "load") {
    names(data) = gsub("@", ".", names(data), fixed = TRUE)
  }
  return(data)
}
