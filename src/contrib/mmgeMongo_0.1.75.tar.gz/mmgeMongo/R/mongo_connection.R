#'Create a connection to the default mongo server
#'
#'Create a connection to a selected database/collection on the default
#'mongo server
#'
#'@param database The name of the database to connect to
#'@param collection The name of the collection within the database
#'@param verbose Flag to indicate whether mongolite should be verbose in its console output
#'
#'@return A mongolite connection object that can be used to interact with the
#'  selected database/collection
#'
#'@export
mongo_connection <- function(database, collection, verbose = interactive()) {

  mongolite::mongo(
    collection = collection,
    db = database,
    url = getOption("mongo.url"),
    verbose = verbose,
    options = mongolite::ssl_options(
      cert = getOption("mongo.cert"),
      key = getOption("mongo.key"),
      ca = getOption("mongo.ca")
    )
  )

}