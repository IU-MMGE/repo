#'@export

save_to_pullsheet_app = function(data,name,data_or_custom,overwrite=FALSE){
  if(data_or_custom=="data"){
    data_names = load_from_mongo("PullsheetApp","data_list")
    if(!name%in%data_names$DATA|overwrite==TRUE){
      save_to_mongo(data,"PullsheetApp",paste0(name,"_data"))
      save_to_mongo(data.frame(DATA = name),"PullsheetApp","data_list",drop=FALSE)
      data_list = load_from_mongo("PullsheetApp","data_list",verbose = FALSE)
      data_list = distinct(data_list)
      save_to_mongo(data_list,"PullsheetApp","data_list",drop=TRUE,verbose=FALSE)
    } else{
      warning("Data name already exists. Change 'overwrite' to TRUE if you want to overwrite.")
    }
  }
  if(data_or_custom=="custom"){
    custom_names = load_from_mongo("PullsheetApp","custom_list")
    if(!name%in%custom_names$CUSTOM|overwrite==TRUE){
      save_to_mongo(data,"PullsheetApp",paste0(name,"_custom"))
      save_to_mongo(data.frame(CUSTOM = name),"PullsheetApp","custom_list",drop=TRUE)
      custom_list = load_from_mongo("PullsheetApp","custom_list",verbose = FALSE)
      custom_list = distinct(custom_list)
      save_to_mongo(custom_list,"PullsheetApp","custom_list",drop=TRUE,verbose=FALSE)
    } else{
      warning("Custom name already exists. Change 'overwrite' to TRUE if you want to overwrite.")
    }
  }
}
