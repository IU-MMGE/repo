#'Load data from mongodb
#'
#'Load data from the given database/collection on the default mongo server, with
#'the option to pass additional filters, etc. to the find method. All data loaded
#'from mongodb should ultimately come through this function because it
#'performs extra steps such as decoding the data and field names to allow for
#'better backwards compatibility with OnCore and the oncore2 package.
#'
#'@param database The name of the database to connect to
#'@param collection The name of the collection within the database
#'@param query A string containing valid JSON to be passed to the query argument of the mongolite find() (or iterate()) method
#'@param fields A string containing valid JSON to be passed to the fields argument of the mongolite find() (or iterate()) method
#'@param sort A string containing valid JSON to be passed to the sort argument of the mongolite find() (or iterate()) method
#'@param skip A number representing the number of records to skip before returning data
#'@param limit A number representing the maximum number of records to return
#'@param handler I'm not sure yet...
#'@param pagesize The page size I guess... I haven't used it and it isn't well documented
#'@param return_data.frame Should the function return the result as a data.frame?
#'@param verbose Flag to indicate whether mongolite should be verbose in its console output
#'
#'@return A dataframe containing the requested data
#'
#'@export
load_from_mongo <- function(database, collection, query = "{}",
                            fields = '{"_id" : 0}', sort = "{}",
                            skip = 0, limit = 0, handler = NULL,
                            pagesize = 1000, return_data.frame = TRUE,
                            verbose = interactive(), include_id = FALSE,clean_data=TRUE) {

  m <- mongo_connection(database, collection, verbose)

  if(return_data.frame) {
    data <- m$find(query = query, fields = fields, sort = sort, skip = skip,
                   limit = limit, handler = handler, pagesize = pagesize)
    if(clean_data){
      data = clean_mongo_data("load",data)
    }
  } else {
    data <- try(jsonlite::fromJSON(m$iterate(find)$json()), silent = TRUE)
    if(inherits(data, 'try-error')) {
      warning("Error when loading as list. Trying as data.frame instead")
      data <- m$find(query = query, fields = fields, sort = sort, skip = skip,
                     limit = limit, handler = handler, pagesize = pagesize)
    }
  }

  return(data)

}



