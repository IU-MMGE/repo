#'@export
get_fields = function(type){
  oncore = unique(c("PROTOCOL_NO","SPECIMEN_NO","SPECIMEN_STORAGE_LOCATION","PARENT_SPECIMEN_ID",
                       "ALTERNATE_MRN","PATIENT_ID","SUBJECT_LAST_NAME","COLLECTION_GROUP","SPECIMEN_TYPE",
                       "VISIT","CASE_NO","SPECIMEN_QUANTITY","SPECIMEN_BAR_CODE","SPECIMEN_STATUS",
                       "PCS_SPECIMEN_ID","SPECIMEN_COMMENTS","SEQUENCE_NUMBER","SPECIMEN_REQUEST_ID",
                       "GENDER","UNIT_OF_MEASURE","ACCESSION_DATE","STUDY_SITE","EMAIL","SUBJECT_FIRST_NAME",
                       "SUBJECT_MIDDLE_NAME","COLLECTION_DATE_TIME","REASON_DESTROYED","ARM_CODE","TIMEPOINT_LABEL",
                       "KIT_NUMBER","COLLECTION_SITE","CASE_OR_CONTROL","NON.CONFORMANCE_DETAIL_.SPECIMEN.",
                       "CONCENTRATION_UOM","NUCLEIC_ACID_DERIVATIVE","NON.CONFORMANCE_REASON_.SPECIMEN.","LAST_DATE_GENOTYPED",
                       "COLLECTION_CONTAINER","HEMOGLOBIN_ASSAY","X260.230_RATIO","GENOTYPED","INSTRUMENT_FOR_QC",
                       "X260.280_RATIO","GENOTYPING_INSTRUMENT","VOLUME_UOM","INITIAL_QUANTITY","FREEZE_._THAW_CYCLE",
                       "CONCENTRATION","RESEARCHER_RESERVED_FOR","INITIAL_QUANTITY_UOM","RIN_VALUE","DNA_SOURCE",
                       "HEMOLYSIS_GRADE","VOLUME","STORAGE_CONTAINER","TURBIDITY_GRADE","CELL_TYPE",
                       "NON.CONFORMANCE_REASON_.SPECI","NON.CONFORMANCE_DETAIL_.SPECI","ACCESSION_DATE","PROCEDURE_DATE",
                       "STUDY_SITE","EMAIL","SUBJECT_FIRST_NAME",
                       "SUBJECT_MIDDLE_NAME","COLLECTION_DATE_TIME","REASON_DESTROYED","ARM_CODE",
                       "TIMEPOINT_LABEL","STUDY_SITE",
                       "RECRUITED_BY_LAST","RECRUITED_BY_FIRST","COLLECTION_SITE","INITIAL_QUANTITY","INITIAL_QUANTITY_UOM",
                       "DATE_FROZEN","HOSPITAL_SITE","COLLECTION_CONTAINER","STORAGE_CONTAINER","RESEARCHER_RESERVED_FOR","VENDOR",
                    "NON.CONFORMANCE_ISSUE.S."))


  discrep = unique(c("SPECIMEN_BAR_CODE","PROTOCOL_NO",
                     "SPECIMEN_NO","SPECIMEN_STORAGE_LOCATION",
                     "PARENT_SPECIMEN_ID","ALTERNATE_MRN",
                     "KIT_NUMBER","CONCENTRATION_UOM",
                     "INSTRUMENT_FOR_QC","FREEZE_._THAW_CYCLE",
                     "CONCENTRATION","PATIENT_ID",
                     "SUBJECT_LAST_NAME","COLLECTION_GROUP",
                     "SPECIMEN_TYPE","VISIT","GENOTYPED",
                     "VOLUME_UOM","GENOTYPING_INSTRUMENT",
                     "DNA_SOURCE","VOLUME","CASE_NO",
                     "SPECIMEN_QUANTITY","SPECIMEN_STATUS",
                     "PCS_SPECIMEN_ID","NUCLEIC_ACID_DERIVATIVE",
                     "LAST_DATE_GENOTYPED","COLLECTION_CONTAINER",
                     "STORAGE_CONTAINER","CELL_TYPE",
                     "SPECIMEN_COMMENTS","SEQUENCE_NUMBER",
                     "SPECIMEN_REQUEST_ID","GENDER",
                     "UNIT_OF_MEASURE","HEMOGLOBIN_ASSAY",
                     "X260.230_RATIO","RESEARCHER_RESERVED_FOR",
                     "HEMOLYSIS_GRADE","TURBIDITY_GRADE",
                     "ACCESSION_DATE","COLLECTION_DATE",
                     "SUBJECT_FIRST_NAME",
                     "ALIQUOT_CREATION_DATE_TIME",
                     "COLLECTION_DATE_TIME","CASE_OR_CONTROL",
                     "NON.CONFORMANCE_DETAIL_.SPECIMEN.",
                     "NON.CONFORMANCE_REASON_.SPECIMEN.",
                     "X260.280_RATIO","RIN_VALUE","REASON_DESTROYED",
                     "SUBJECT_MRN","ALIQUOT_CREATION_DATE",
                     "PROCEDURE_DATE","BIRTH_DATE",
                     "DURATION_OF_CENTRIFUGATION",
                     "TEMPERATURE_OF_CENTRIFUGATION",
                     "INITIAL_QUANTITY","RNA_QC_INSTRUMENT",
                     "INITIAL_QUANTITY_UOM","STUDY_SITE",
                     "RACE","ETHNICITY","ARM_CODE","SPECIMEN_UOM",
                     "STORAGE_TEMPERATURE","FREEZING_MEDIA",
                     "DATE_FROZEN","RATE_OF_CENTRIFUGATION_.XG.",
                     "VIABILITY_...","PREPARATION_DATE",
                     "TIMEPOINT_LABEL",
                     "EMAIL","SUBJECT_MIDDLE_NAME",
                     "RECRUITED_BY_LAST","RECRUITED_BY_FIRST",
                     "FASTING","COLLECTION_SITE","CSF_COLLECTED",
                     "HOSPITAL_SITE","SITE_ALIQUOT_TIME",
                     "TIME_FROZEN","SITE_CENTRIFUGATION_TIME",
                     "VENDOR","NON.CONFORMANCE_ISSUE.S."))

  DCR = c("DNANumber","SUBJECT_ID","ReferencedTable","DNASource","Available","Ratio260_280",
                "Yieldug","Concentration","DNAVolume","Notes.x","KitNumber","Disease","Study","SiteID",
                "FamNo","IndNo","NeedsRedraw","RedrawProgress","IsBackup","DCRFreezer","DCRSection","DCRShelf",
                "DCRRack","DCRRackShelf","DCRBox","DCRPosition","DCRNotes","DCRDateRemoved","DNAStatus","DateUpdated.x","DateEntered.x","DateDrawn","DateReceived")

  DCRrequest = c("DNANumber","SUBJECT_ID","RequestID","RequestNo","DateRequested","ReferencedTable","DNASource","Available","Ratio260_280",
                 "Yieldug","Concentration","DNAVolume","Notes.x","KitNumber","Disease","Study","SiteID",
                 "FamNo","IndNo","NeedsRedraw","RedrawProgress","IsBackup","DCRFreezer","DCRSection","DCRShelf",
                 "DCRRack","DCRRackShelf","DCRBox","DCRPosition","DCRNotes","DCRDateRemoved","DNAStatus","DateUpdated.x","DateEntered.x","DateDrawn","DateReceived")

  freezerfiles = c("Room","Freezer","Shelf","Rack","RackShelf","Box","Position",
                "Barcode","Notes","Date.Removed","Source_File","Original_Barcode")
  if(type%in%c("oncore","DCR","DCRrequest","freezerfiles","discrep")){
    eval(parse(text = paste0("return(",type,")")))
  }else{
    warning("invalid type")
  }

}
