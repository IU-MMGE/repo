#'Query OnCore data (updated once per day)
#'
#'Query OnCore, filter on selected fields, or select fields from a list of custom defaults
#'
#'@param ... uses argument as OnCore filter, takes any predetermined field and its original vector-type
#' (e.g. SPECIMEN_QUANTITY as numerical vector, SPECIMEN_BAR_CODE as character vector, ...)
#'@param fields select OnCore fields to be returned (takes character vector)
#'@param limit select how many records to return
#'@param keep_all_fields if the query has fields that are all NA, this argument will create the empty missing fields to retain naming
#'(all fields returned will be "", not NA)
#'
#'@return A dataframe with the selected fields and filters from an updated OnCore clone
#'
#'@export


moncore_query = function(...,fields,limit,keep_all_fields = TRUE,pullsheet=TRUE,DCR = FALSE,brain_tissue = FALSE,pull_freezer_files=FALSE,
                         include_freezer_files = FALSE,include_request_data = FALSE,discrep=FALSE,clean_discrep = TRUE){
  require(mongolite)
  require(dplyr)

  if(!DCR&!brain_tissue&!pull_freezer_files&discrep){
    allfields = get_fields("discrep")
    list = list(...)
    df = c()

    for(i in 1:length(list)){
      if(length(list)>0){
        if(names(list)[i]%in%c("SPECIMEN_QUANTITY")){
          quote = ""
        } else{
          quote = "\""
        }
        df[i] = paste0("\"$or\":[", paste0("{\"",names(list)[i],"\":",quote,
                                           unlist(list[[i]]), quote,"}", collapse = ","), "]")
      }

    }

    if (!missing(fields)) {
      allfields = fields
      f = paste0("{\"_id\":0,\"", paste0(allfields, "\":", 1,
                                         collapse = ",\""), "}")
    }
    else {
      f = paste0("{\"_id\":0,\"", paste0(allfields, "\":",
                                         1, collapse = ",\""), "}")
    }

    all = paste0("{",paste0(df,collapse = ","),"}")
    f = gsub(".","@",f,fixed = TRUE)
    if(!missing(limit)){
      df = load_from_mongo(database = "oncore",collection = "master_query",query = all, fields = f,limit = limit)

    }else{
      df = load_from_mongo(database = "oncore",collection = "master_query",query = all, fields = f)
    }
    if(keep_all_fields&length(allfields[!allfields%in%names(df)])>0){
      missing = allfields[!allfields%in%names(df)]
      for(i in 1:length(missing)){
        df = df%>%
          mutate(!!missing[i]:="")
      }
    }
    if(clean_discrep == TRUE){
      if("COLLECTION_DATE_TIME"%in%allfields){
        df$COLLECTION_TIME = gsub(".*\\ ", "", df$COLLECTION_DATE_TIME)
        df$COLLECTION_TIME = ifelse(nchar(df$COLLECTION_TIME) == 4, df$COLLECTION_TIME, NA)
        df$COLLECTION_TIME = format(strptime(df$COLLECTION_TIME, format = "%H%M"), "%H:%M")
        df$COLLECTION_DATE_TIME = as.Date(df$COLLECTION_DATE_TIME, format = "%m/%d/%Y")

      }
      if("ACCESSION_DATE"%in%allfields){
        df$ACCESSION_DATE = as.Date(df$ACCESSION_DATE, format = "%m/%d/%Y")

      }
      if("COLLECTION_DATE"%in%allfields){
        df$COLLECTION_DATE = as.Date(df$COLLECTION_DATE, format = "%m/%d/%Y")

      }
      if("TEMPERATURE_OF_CENTRIFUGATION"%in%allfields){
        #df = oncore2::recode_field(df, "TEMPERATURE_OF_CENTRIFUGATION")

      }
      if("STUDY_SITE"%in%allfields){
        df$STUDY_SITE = ifelse(
          df$STUDY_SITE == "Arizona Alzheimer's Research Consortium (ADRC)",
          "Arizona Alzheimers Research Consortium (ADRC)",
          df$STUDY_SITE
        )
      }
      if("INITIAL_QUANTITY_UOM"%in%allfields){
        #df = oncore2::recode_field(df, "INITIAL_QUANTITY_UOM")

      }
      if("ALIQUOT_CREATION_DATE_TIME"%in%allfields){
        df$ALIQUOT_CREATION_DATE = as.Date(df$ALIQUOT_CREATION_DATE_TIME, format = "%m/%d/%Y")

      }
      if("PROCEDURE_DATE"%in%allfields){
        df$PROCEDURE_DATE = as.Date(df$PROCEDURE_DATE, format = "%m/%d/%Y")

      }
      if("DATE_FROZEN"%in%allfields){
        df$DATE_FROZEN = as.Date(df$DATE_FROZEN, format = "%m/%d/%Y")

      }
      if("BIRTH_DATE"%in%allfields){
        df$BIRTH_DATE = as.Date(df$BIRTH_DATE, format = "%m/%d/%Y")

      }
      if("STORAGE_CONTAINER"%in%allfields){
        #df = oncore2::recode_field(df, "STORAGE_CONTAINER", category = "STORAGE_CONTAINER")

      }
      if("REASON_DESTROYED"%in%allfields){
        #df = oncore2::recode_field(df, "REASON_DESTROYED", category = "REASON_DESTROYED")

      }
      if("CONCENTRATION_UOM"%in%allfields){
        #df = oncore2::recode_field(df, "CONCENTRATION_UOM", category = "CONCENTRATION_UOM")

      }
      if("INSTRUMENT_FOR_QC"%in%allfields){
        #df = oncore2::recode_field(df, "INSTRUMENT_FOR_QC", category = "DNA_QC_ANALYSIS_METHOD")

      }
      if("VOLUME_UOM"%in%allfields){
        #df = oncore2::recode_field(df, "VOLUME_UOM")

      }
      if("DNA_SOURCE"%in%allfields){
        #df = oncore2::recode_field(df, "DNA_SOURCE")

      }
      if("GENOTYPED"%in%allfields){
        #df = oncore2::recode_field(df, "GENOTYPED")

      }
      if("COLLECTION_CONTAINER"%in%allfields){
        #df = oncore2::recode_field(df, "COLLECTION_CONTAINER", category = "COLLECTION_CONTAINER")
        df$COLLECTION_CONTAINER = as.character(df$COLLECTION_CONTAINER)

      }
      if("CELL_TYPE"%in%allfields){
        #df = oncore2::recode_field(df, "CELL_TYPE")

      }
      if("NUCLEIC_ACID_DERIVATIVE"%in%allfields){
        #df = oncore2::recode_field(df, "NUCLEIC_ACID_DERIVATIVE")

      }
      if("CSF_COLLECTED"%in%allfields){
        #df = oncore2::recode_field(df, "CSF_COLLECTED")

      }
      if("FASTING"%in%allfields){
        #df = oncore2::recode_field(df, "FASTING")

      }

    }
    return(df)
  }

  if(!DCR&!brain_tissue&!pull_freezer_files&!discrep){
    allfields = get_fields("oncore")
    list = list(...)
    df = c()

    for(i in 1:length(list)){
      if(length(list)>0){
        if(names(list)[i]%in%c("SPECIMEN_QUANTITY")){
          quote = ""
        } else{
          quote = "\""
        }
        df[i] = paste0("\"$or\":[", paste0("{\"",names(list)[i],"\":",quote,
                                           unlist(list[[i]]), quote,"}", collapse = ","), "]")
      }

    }

    if (!missing(fields)) {
      allfields = fields
      f = paste0("{\"_id\":0,\"", paste0(allfields, "\":", 1,
                                         collapse = ",\""), "}")
    }
    else {
      f = paste0("{\"_id\":0,\"", paste0(allfields, "\":",
                                         1, collapse = ",\""), "}")
    }

    all = paste0("{",paste0(df,collapse = ","),"}")
    f = gsub(".","@",f,fixed = TRUE)
    if(pullsheet){
      if(!missing(limit)){
        df = load_from_mongo(database = "oncore",collection = "pullsheet_query",query = all, fields = f,limit = limit)

      }else{
        df = load_from_mongo(database = "oncore",collection = "pullsheet_query",query = all, fields = f)
      }
    } else{
      if(!missing(limit)){
        df = load_from_mongo(database = "oncore",collection = "master_query",query = all, fields = f,limit = limit)

      }else{
        df = load_from_mongo(database = "oncore",collection = "master_query",query = all, fields = f)
      }
    }

    if(keep_all_fields&length(allfields[!allfields%in%names(df)])>0){
      missing = allfields[!allfields%in%names(df)]
      for(i in 1:length(missing)){
        df = df%>%
          mutate(!!missing[i]:="")
      }
    }
    if(pullsheet){
      if(missing(fields)){
        fields = allfields
      }
      if("GENOTYPED"%in%fields){
        df = df %>% dplyr::filter(!GENOTYPED %in% c("FAIL",
                                                    "GENOERR") | is.na(GENOTYPED))
      }
      if("RESEARCHER_RESERVED_FOR"%in%fields){
        df = df %>% dplyr::filter(is.na(RESEARCHER_RESERVED_FOR) |
                                    !RESEARCHER_RESERVED_FOR %in% c("Reference Pools"))
      }
      if(all(c("COLLECTION_GROUP","CELL_TYPE","SPECIMEN_STORAGE_LOCATION","SPECIMEN_COMMENTS")%in%fields)){
        df = df %>% dplyr::filter(ifelse(COLLECTION_GROUP %in%
                                           c("PBMC", "CELL LINE") | CELL_TYPE %in% c("EBV LCL",
                                                                                     "Fibroblast", "iPSC"), grepl("R3", SPECIMEN_STORAGE_LOCATION,
                                                                                                                  fixed = T), is.na(SPECIMEN_COMMENTS) | !is.na(SPECIMEN_COMMENTS)))
      }
      if("SPECIMEN_NO"%in%fields){
        df = df[!duplicated(df$SPECIMEN_NO, fromLast = TRUE),
                ]
      }
      if("SPECIMEN_COMMENTS"%in%fields){
        df$SPECIMEN_COMMENTS = ifelse(is.na(df$SPECIMEN_COMMENTS),
                                      "", df$SPECIMEN_COMMENTS)
        df = df %>% dplyr::arrange(SPECIMEN_COMMENTS)
      }

    }
    return(df)
  }
  if(DCR&!brain_tissue&!include_request_data&!pull_freezer_files){
    allfields = get_fields("DCR")
    list = list(...)
    df = c()

    for(i in 1:length(list)){
      if(length(list)>0){
        # if(names(list)[i]%in%c("SPECIMEN_QUANTITY")){
        #   quote = ""
        # } else{
          quote = "\""
        # }
        df[i] = paste0("\"$or\":[", paste0("{\"",names(list)[i],"\":",quote,
                                           unlist(list[[i]]), quote,"}", collapse = ","), "]")
      }

    }

    if (!missing(fields)) {
      allfields = fields
      f = paste0("{\"_id\":0,\"", paste0(allfields, "\":", 1,
                                         collapse = ",\""), "}")
    }
    else {
      f = paste0("{\"_id\":0,\"", paste0(allfields, "\":",
                                         1, collapse = ",\""), "}")
    }

    all = paste0("{",paste0(df,collapse = ","),"}")
    f = gsub(".","@",f,fixed = TRUE)
    if(!missing(limit)){
      df = load_from_mongo(database = "DCR",collection = "DNA",query = all, fields = f,limit = limit)

    }else{
      df = load_from_mongo(database = "DCR",collection = "DNA",query = all, fields = f)
    }
    if(keep_all_fields&length(allfields[!allfields%in%names(df)])>0){
      missing = allfields[!allfields%in%names(df)]
      for(i in 1:length(missing)){
        df = df%>%
          mutate(!!missing[i]:="")
      }
    }
    if(include_freezer_files){
      if(missing(fields)){
        fields = allfields
      }
      if("DNANumber"%in%fields){
        if(length(unique(df$DNANumber))<150){
          list2 = paste0("\"$or\":[", paste0("{\"", "Barcode",
                                             "\":", "\"", df$DNANumber, "\"", "}",
                                             collapse = ","), "]")
          all2 = paste0("{", paste0(list2, collapse = ","), "}")
          files = load_from_mongo("DCR","FreezerFiles",query = all2)
        } else{
          files = load_from_mongo("DCR","FreezerFiles")
        }
        if(nrow(files)==0){
          freezerfields = get_fields("freezerfiles")
          for(i in freezerfields[!freezerfields%in%names(df)]){
            df = df%>%
              mutate(!!i:="")
          }
        } else{
          df = df%>%
            left_join(files,by=c("DNANumber"="Barcode"))
        }

      }

    }
    return(df)
  }
  if(!DCR&brain_tissue&!pull_freezer_files){
    return(load_from_mongo("DCR","brain_tissue"))
  }


  if(DCR&!brain_tissue&include_request_data&!pull_freezer_files){
    allfields = get_fields("DCRrequest")
    list = list(...)
    df = c()

    for(i in 1:length(list)){
      if(length(list)>0){
        # if(names(list)[i]%in%c("SPECIMEN_QUANTITY")){
        #   quote = ""
        # } else{
        quote = "\""
        # }
        df[i] = paste0("\"$or\":[", paste0("{\"",names(list)[i],"\":",quote,
                                           unlist(list[[i]]), quote,"}", collapse = ","), "]")
      }

    }

    if (!missing(fields)) {
      allfields = fields
      f = paste0("{\"_id\":0,\"", paste0(allfields, "\":", 1,
                                         collapse = ",\""), "}")
    }
    else {
      f = paste0("{\"_id\":0,\"", paste0(allfields, "\":",
                                         1, collapse = ",\""), "}")
    }

    all = paste0("{",paste0(df,collapse = ","),"}")
    f = gsub(".","@",f,fixed = TRUE)
    if(!missing(limit)){
      df = load_from_mongo(database = "DCR",collection = "RequestData",query = all, fields = f,limit = limit)

    }else{
      df = load_from_mongo(database = "DCR",collection = "RequestData",query = all, fields = f)
    }
    if(keep_all_fields&length(allfields[!allfields%in%names(df)])>0){
      missing = allfields[!allfields%in%names(df)]
      for(i in 1:length(missing)){
        df = df%>%
          mutate(!!missing[i]:="")
      }
    }
    if(include_freezer_files){
      if(missing(fields)){
        fields = allfields
      }
      if("DNANumber"%in%fields){
        if(length(unique(df$DNANumber))<150){
          list2 = paste0("\"$or\":[", paste0("{\"", "Barcode",
                                             "\":", "\"", df$DNANumber, "\"", "}",
                                             collapse = ","), "]")
          all2 = paste0("{", paste0(list2, collapse = ","), "}")
          files = load_from_mongo("DCR","FreezerFiles",query = all2)
        } else{
          files = load_from_mongo("DCR","FreezerFiles")
        }

        if(nrow(files)==0){
          freezerfields = get_fields("freezerfiles")
          for(i in freezerfields[!freezerfields%in%names(df)]){
            df = df%>%
              mutate(!!i:="")
          }
        } else{
          df = df%>%
            left_join(files,by=c("DNANumber"="Barcode"))
        }
      }
    }
    return(df)
  }

  if(pull_freezer_files&!DCR&!brain_tissue&!include_request_data){
    allfields = get_fields("freezerfiles")
    list = list(...)
    df = c()

    for(i in 1:length(list)){
      if(length(list)>0){
        # if(names(list)[i]%in%c("SPECIMEN_QUANTITY")){
        #   quote = ""
        # } else{
        quote = "\""
        # }
        df[i] = paste0("\"$or\":[", paste0("{\"",names(list)[i],"\":",quote,
                                           unlist(list[[i]]), quote,"}", collapse = ","), "]")
      }

    }

    if (!missing(fields)) {
      allfields = fields
      f = paste0("{\"_id\":0,\"", paste0(allfields, "\":", 1,
                                         collapse = ",\""), "}")
    }
    else {
      f = paste0("{\"_id\":0,\"", paste0(allfields, "\":",
                                         1, collapse = ",\""), "}")
    }

    all = paste0("{",paste0(df,collapse = ","),"}")
    f = gsub(".","@",f,fixed = TRUE)
    if(!missing(limit)){
      df = load_from_mongo(database = "DCR",collection = "FreezerFiles",query = all, fields = f,limit = limit)

    }else{
      df = load_from_mongo(database = "DCR",collection = "FreezerFiles",query = all, fields = f)
    }
    if(keep_all_fields&length(allfields[!allfields%in%names(df)])>0){
      missing = allfields[!allfields%in%names(df)]
      for(i in 1:length(missing)){
        df = df%>%
          mutate(!!missing[i]:="")
      }
    }
    if(Sys.Date()!=load_from_mongo("oncore","date_updated")$DATE){
      message(paste0("Last Updated: ",load_from_mongo("oncore","date_updated")$DATE))
    }
    return(df)
  }

}





