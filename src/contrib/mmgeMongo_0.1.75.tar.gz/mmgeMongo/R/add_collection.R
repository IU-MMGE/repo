#'@export
add_collection = function(name,database, collection, query = "{}",
                          fields = '{"_id" : 0}', sort = "{}",
                          skip = 0, limit = 0, return_data.frame = TRUE,
                          verbose = interactive(), include_id = FALSE,
                          unique_barcodes=FALSE,build_collection_now = FALSE,overwrite = FALSE){
  require(dplyr)
  config = list()
  config$name = name
  config$database = database
  config$collection = collection
  config$query = query
  config$fields = paste0('c("',paste0(fields,collapse = '","'),'")')
  config$sort = sort
  config$skip = skip
  config$limit = limit
  config$return_data.frame = return_data.frame
  config$include_id = include_id
  config$unique_barcodes = unique_barcodes
  truefields = eval(parse(text = paste0(config$fields)))
  df = as.data.frame(config)


  mmgeMongo::save_to_mongo(df,"collection_build","build",clean_data = FALSE,drop = FALSE)

  df2 = load_from_mongo("collection_build","build",verbose = FALSE)
  df2 = df2%>%ungroup()%>%distinct()
  if(overwrite){
    df2 = df2%>%group_by(name)%>%
      filter(row_number()==max(row_number()))
  }
  invisible(mmgeMongo::save_to_mongo(df2,"collection_build","build",clean_data = FALSE,drop = TRUE,verbose = FALSE))

  if(build_collection_now){
    x = mmgeMongo::mongo_query("oncore","master_query",query = config$query,fields=truefields,sort = config$sort,skip = config$skip,limit = config$limit,return_data.frame = config$return_data.frame,
                               include_id = config$include_id)
    if(config$unique_barcodes&"SPECIMEN_BAR_CODE"%in%colnames(x)){
      x = x%>%filter(!is.na(SPECIMEN_BAR_CODE))%>%
        group_by(SPECIMEN_BAR_CODE)%>%
        arrange()%>%
        filter(row_number()==1)
    }
    if(!all(truefields%in%colnames(x))){
      tf2 = truefields[!truefields%in%colnames(x)]
      for(i in 1:length(tf2)){
        x = x%>%mutate(`:=`(!!tf2[i],""))
      }
    }
    save_to_mongo(x,config$database,config$collection)
  }
}



#'@export
remove_collection = function(name){
  require(dplyr)
  x = load_from_mongo("collection_build","build")
  name2 = name
  y = mongo_connection(database = x$database[x$name==name2],collection = x$collection[x$name==name2])
  y$drop()
  x = x%>%filter(name!=!!name2)
  save_to_mongo(x,"collection_build","build",drop = TRUE,clean_data = FALSE)
}

