u_operator <- function(name) {

  n <- name

  function(x) {
    y <- list(x)
    names(y) <- n
    y <- jsonlite::toJSON(y, auto_unbox = TRUE)
    class(y) <- c("mongo_json", class(y))
    return(y)
  }

}

desc <- function(x) {
  class(x) <- c(class(x), "mongo-desc-sort")
  return(x)
}

as.mongo_json <- function(x) {
  class(x) <- c("mongo_json", class(x))
  return(x)
}

l_operator <- function(name) {

  n <- name

  function(...) {
    x <- sapply(list(...), function(o) {

      if(inherits(o, 'mongo_json')) {
        return(o)
      } else {
        return(as.mongo_json(jsonlite::toJSON(o, auto_unbox = TRUE)))
      }

    })
    y <- glue::glue("{{\"{n}\": { paste0('[', paste(x, collapse = ', '), ']') }}}")
    class(y) <- c("mongo_json", class(y))
    return(y)
  }

}

f <- function(field, filter) {

  if(inherits(filter, 'mongo_json')) {
    x <- glue::glue("{{\"{field}\": {filter}}}")
  } else {
    x <- list(filter)
    names(x) <- field
    x <- jsonlite::toJSON(x, auto_unbox = TRUE)
  }
  class(x) <- c('mongo_json', class(x))
  return(x)

}

u_operators <- c('eq', 'gt', 'gte', 'lt', 'lte', 'ne', 'nin', 'exists', 'type')
l_operators <- c('and', 'not', 'nor', 'or')

for(o in u_operators) {

  assign(o, value = u_operator(paste0("$", o)))

}

for(l in l_operators) {

  assign(l, value = l_operator(paste0("$", l)))

}

inn <- function(..., .x) {

  if(missing(.x)) {
    .x <- unlist(list(...), recursive = TRUE)
  }

  if(length(.x) == 1) {
    return(as.mongo_json(glue::glue("\"{.x}\"")))
  } else {
    y <- as.mongo_json(glue::glue("{{\"$in\": {jsonlite::toJSON(unlist(.x, recursive = TRUE), auto_unbox = TRUE)}}}"))
    return(y)
  }

}