.onLoad <- function(...) {
  #Shamelessly stolen from dplyr's onLoad hook
  op <- options()
  op.mongo <- list(
    mongo.url = "mongodb://nformmgo.medgen.iupui.edu/?ssl=true",
    mongo.cert = openssl::read_cert(system.file("ssl/baileye.pem", package = "mmgeMongo")),
    mongo.key = openssl::read_key(system.file("ssl/baileye.key", package = "mmgeMongo")),
    mongo.ca = system.file("ssl/mmgeCA.pem", package = "mmgeMongo")
  )
  toset <- !(names(op.mongo) %in% names(op))
  if (any(toset)) options(op.mongo[toset])
}
