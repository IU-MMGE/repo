#'Load data from mongodb
#'
#'Load data from the given database/collection on the default mongo server, with
#'the option to pass additional filters, etc. More abstracted than load_from_mongo,
#'converts R-type objects to the appropriate json objects needed by mongolite.
#'
#'@param database The name of the database to connect to
#'@param collection The name of the collection within the database
#'@param query A string containing valid JSON (or an R object that will convert to valid JSON) to be passed to the query argument of the mongolite find() (or iterate()) method
#'@param fields A vector or list of field names to be converted and passed to the fields argument of the mongolite find() (or iterate()) method
#'@param sort A vector or list of field names to be converted and passed to the sort argument of the mongolite find() (or iterate()) method
#'@param skip A number representing the number of records to skip before returning data
#'@param limit A number representing the maximum number of records to return
#'@param return_data.frame Should the function return the result as a data.frame?
#'@param verbose Flag to indicate whether mongolite should be verbose in its console output
#'
#'@return A dataframe )or list) containing the requested data
#'
#'@export
mongo_query <- function(database, collection, query = "{}",
                        fields = '{"_id" : 0}', sort = "{}",
                        skip = 0, limit = 0, return_data.frame = TRUE,
                        verbose = interactive(), include_id = FALSE) {

  if(!is.character(query)) {
    query <- jsonlite::toJSON(query, auto_unbox = TRUE)
  }

  if((is.character(fields) && length(fields) > 0) || is.list(fields)) {
    f <- as.list(rep(1, times = length(fields)))
    names(f) <- fields
    if(!include_id) {
      f$`_id` <- 0 # Prevent the _id field from being returned
    }
    fields <- jsonlite::toJSON(f, auto_unbox = TRUE)
  } else if(is.character(fields)) {
    f <- list(1)
    names(f) <- fields
    fields <- jsonlite::toJSON(f, auto_unbox = TRUE)
  } else {
    stop("Invalid fields argument. Should be list or vector of field names.")
  }

  if((is.character(sort) && length(sort) > 0) || is.list(sort)) {
    if(sort != "{}") {
      s <- lapply(sort, function(x) {
        if(inherits(x, "mongo-desc-sort")) {
          return(-1)
        } else {
          return(1)
        }
      })
      names(s) <- sort
      sort <- jsonlite::toJSON(s, auto_unbox = TRUE)
    }
  } else if(is.character(sort)) {
    if(inherits(s, "mongo-desc-sort")) {
      s <- list(-1)
    } else {
      s <- list(1)
    }
    names(s) <- sort
    sort <- jsonlite::toJSON(sort, auto_unbox = TRUE)
  } else {
    stop("Invalid sort argument. Should be list or vector of field names.")
  }

  load_from_mongo(database = database, collection = collection, query = query,
                  fields = fields, sort = sort, skip = skip, limit = limit,
                  return_data.frame = return_data.frame, verbose = verbose,
                  include_id = include_id)

}