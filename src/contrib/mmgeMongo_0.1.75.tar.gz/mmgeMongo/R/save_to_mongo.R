#'Save data to mongodb
#'
#'Save the provided data to the given database/collection on the default mongo server.
#'All data saved to mongodb should ultimately go through this function because it
#'performs extra steps such as encoding the data and field names to allow for
#'better backwards compatibility with OnCore and the oncore2 package.
#'
#'@param data the data to save
#'@param database The name of the database to connect to
#'@param collection The name of the collection within the database
#'@param indices A list of indices to add to the collection
#'@param overwrite Should the existing collection be dropped before inserting new data?
#'@param verbose Flag to indicate whether mongolite should be verbose in its console output
#'
#'@return TRUE if successful, FALSE otherwise
#'
#'@export
save_to_mongo <- function(data, database, collection, indices, drop = TRUE, verbose = interactive(),clean_data = TRUE) {
  if(clean_data){
    data = clean_mongo_data("save",data)
  }
  m <- mongo_connection(database, collection, verbose)

  if(drop == TRUE) {
    if(verbose) message("Dropping old data...")
    try(m$drop(), silent = TRUE)
  }

  if(inherits(m$insert(data), 'try-error')) {
    warning("Failed to save to mongodb")
    return(FALSE)
  } else {
    if(!missing(indices)) {
      if(is.list(indices)) {
        sapply(indices, function(ind) {
          index <- as.list(rep(1, times = length(ind)))
          names(index) <- ind
          index <- jsonlite::toJSON(index, auto_unbox = TRUE)
          if(verbose) message("Adding index: ", index)
          m$index(add = index)
        })
      } else {
        index = as.list(rep(1, times = length(indices)))
        names(index) <- indices
        index <- jsonlite::toJSON(index, auto_unbox = TRUE)
        if(verbose) message("Adding index: ", index)
        m$index(add = index)
      }
    }
    return(TRUE)
  }

}
