devtools::load_all()
debug(mmgeCatalog$new)
x <- mmgeCatalog$new("MMGE-MJFF-PPMI-BIO", "PPMI")
x$open("config")
x$open("dictionary")
x$open("preprocess_catalog_data2")
debug(x$build)
x$build()





devtools::load_all()
build_catalog_data_warehouse()
x <- build_catalogs()
