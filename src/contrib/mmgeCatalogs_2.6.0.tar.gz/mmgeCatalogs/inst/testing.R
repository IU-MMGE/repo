devtools::load_all()
x <- mmgeCatalog$new("CTSI-NIH-WARDEN-MSKFIT")
x <- mmgeCatalog$new("MMGE-NIA-NCRAD-LOAD")
x <- mmgeCatalog$new("MMGE-FPN-PNRR")
x <- mmgeCatalog$new("MMGE-NIA-NCRAD-ALLFTD")
x <- mmgeCatalog$new("MMGE-MJFF-ADB-24HR-P1")
x <- mmgeCatalog$new("MMGE-MJFF-LRRK2", "LRRK2_23ME")
base::debug(x$build)
x$build()
base::debug(x$save)
x$save(deploy = TRUE)

x$open('postprocess')

devtools::load_all()
x <- build_catalogs()

x <- get_catalog_directories()
for(dir in x) {
  rstudioapi::navigateToFile(file.path(dir, "dictionary.yaml"))
}

process_catalogs(fn = function(protocol, catalog_name, config, dir) {
  dict <- try(yaml::yaml.load_file(file.path(dir, "dictionary.yaml")))
  if(!inherits(dict, 'try-error')) {
    if(dict$SAMPLE_ID$formula == "first(SPECIMEN_NO)") {
      message("Updating ", protocol, " ", catalog_name)
      dict$SAMPLE_ID$formula <- "sample_id(SPECIMEN_NO)"
      yaml::write_yaml(dict, file = file.path(dir, "dictionary.yaml"))
    }
  }
})

devtools::load_all()
x <- mmgeCatalog$new("MMGE-MJFF-PPMI-BIO", "PPMI")
x$build()
x$save(deploy = TRUE)
