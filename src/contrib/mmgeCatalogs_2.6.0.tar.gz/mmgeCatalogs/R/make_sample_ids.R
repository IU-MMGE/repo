make_sample_ids <- function(n, prefix = "", suffix = "G") {

  return(paste0(prefix, 100000 + sample.int(n = 899999, size = n), suffix))

}
