#'@export
mmgeCatalog <- R6::R6Class("mmgeCatalog",
  inherit = mmgeCatalogsLite::mmgeCatalog,
  public = list(
    entry_point = NULL,
    open = R6_open_file,
    save = R6_save_catalog,
    initialize = R6_initialize_catalog_object,
    build = R6_build_catalog,
    reload = R6_reload_config,
    dev = NULL
  ),
  active = list(
    config = function(value) {
      if(missing(value)) {
        cat(jsonlite::toJSON(private$config_obj, pretty = TRUE, auto_unbox = TRUE))
        return(private$config_obj)
      }
    },
    dictionary = function(value) {
      if(missing(value)) {
        cat(jsonlite::toJSON(private$dictionary_obj, pretty = TRUE, auto_unbox = TRUE))
        return(private$dictionary_obj)
      }
    },
    recodes = function(value) {
      if(missing(value)) {
        cat(jsonlite::toJSON(private$recodes_obj, pretty = TRUE, auto_unbox = TRUE))
        return(private$recodes_obj)
      }
    },
    problems = function(value) {
      if(missing(value)) {
        return(private$problems_obj)
      }
    }
  ),
  private = list(
    recodes_obj = NULL,
    sources = list(),
    primary_source = NULL,
    use_tesla = FALSE,
    build_environment = NULL,
    get_config = R6_get_config,
    get_dictionary = R6_get_dictionary,
    get_recodes = R6_get_recodes,
    initialize_build_environment = R6_initialize_build_environment,
    get_sources = R6_get_sources,
    get_flat_file_sources = R6_get_flat_file_source_data,
    get_redcap_sources = R6_get_redcap_source_data,
    get_oncore_sources = R6_get_oncore_source_data,
    get_tesla_sources = R6_get_tesla_source_data,
    recode_data = R6_recode_data,
    merge_data = R6_merge_data,
    mutate_data = R6_mutate_data,
    finalize_catalog = R6_finalize_catalog,
    open_data_file = R6_open_data_file,
    reserved_source_types = c('redcap', 'oncore', 'mutate', 'standard_field'),
    add_problem = function(sample_id, field_name, description) {
      problem <- c(SAMPLE_ID = sample_id, FIELD = field_name, DESCRIPTION = description)
      private$problems_obj[nrow(private$problems_obj) + 1, ] <- problem
    },
    problems_obj = data.frame(SAMPLE_ID = character(), FIELD = character(), description = character(), stringsAsFactors = FALSE)
  )
)