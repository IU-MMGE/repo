#'@export
debug_catalogs <- function(catalogs) {

  if(interactive()) {

    for(catalog in catalogs) {

      if(inherits(catalog$result, "try-error") || nrow(catalog$result$catalog) == 0) {

        x <- try(mmgeCatalogs::mmgeCatalog$new(protocol = catalog$protocol, catalog_name = catalog$catalog_name), silent = TRUE)
        if(inherits(x, 'try-error')) {
          x <- try(mmgeCatalogs::mmgeCatalog$new(protocol = catalog$protocol), silent = TRUE)
        }
        if(!inherits(x, 'try-error')) {
          message(crayon::bgYellow(crayon::black("DEBUGGING:")), " ", crayon::white(catalog$protocol, " - ", catalog$catalog_name))
          cat("\n")
          if(inherits(catalog$result, "try-error")) {
            cat("\n", catalog$result, "\n\n")
          } else {
            cat("\n", "Zero-length catalog", "\n\n")
          }
          cat("\n")
          p <- readline("Debug catalog? (Y/n/q)")
          if(p %in% c("Y", "y", "Yes", "yes", "YES")) {
            base::debug(x$build)
            x$build()
          } else if(p %in% c("q", "Q", "quit", "QUIT", "Quit")) {
            cat("Ending debug\n")
            break
          } else {
            message("Skipping ", crayon::white(catalog$protocol, " - ", catalog$catalog_name),"...")
          }
        }

      }

    }

  } else {

    stop("Not in an interactive session.", call. = FALSE)

  }

}