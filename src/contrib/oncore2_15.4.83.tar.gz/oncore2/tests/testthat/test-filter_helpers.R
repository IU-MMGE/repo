context("filter specimen_type()")

query_serum <- oncore_connect("nrbyers", "hump15day", verbose = FALSE) %>%
  select_fields(PROTOCOL_NO, SV_BSM_SPECIMEN.SPECIMEN_TYPE,
                SV_BSM_SPECIMEN.SPECIMEN_BAR_CODE) %>%
  filter_oncore(protocol("PPMI"), specimen_type("Serum")) %>%
  execute_query()

query_serum_plasma <- oncore_connect("nrbyers", "hump15day", verbose = FALSE) %>%
  select_fields(PROTOCOL_NO, SV_BSM_SPECIMEN.SPECIMEN_TYPE,
                SV_BSM_SPECIMEN.SPECIMEN_BAR_CODE) %>%
  filter_oncore(protocol("PPMI"), specimen_type("Serum", "Plasma")) %>%
  execute_query()

test_that("filter helper specimen_type() works correctly", {
  expect_equal(unique(query_serum$SPECIMEN_TYPE), "Serum")
  expect_equal(sort(unique(query_serum_plasma$SPECIMEN_TYPE)), c("Plasma", "Serum"))
})

context("filter collection_group()")

query_RNA <- oncore_connect("nrbyers", "hump15day", verbose = FALSE) %>%
  select_fields(PROTOCOL_NO, SV_BSM_SPECIMEN.SPECIMEN_TYPE,
                BSMS_PCS_SPECIMEN.COLLECTION_GROUP,
                SV_BSM_SPECIMEN.SPECIMEN_BAR_CODE) %>%
  filter_oncore(protocol("PPMI"), collection_group("RNA")) %>%
  execute_query() %>% recodeField("COLLECTION_GROUP")

query_RNA_DNA <- oncore_connect("nrbyers", "hump15day", verbose = FALSE) %>%
  select_fields(PROTOCOL_NO, SV_BSM_SPECIMEN.SPECIMEN_TYPE,
                BSMS_PCS_SPECIMEN.COLLECTION_GROUP,
                SV_BSM_SPECIMEN.SPECIMEN_BAR_CODE) %>%
  filter_oncore(protocol("PPMI"), collection_group("RNA", "DNA")) %>%
  execute_query() %>% recodeField("COLLECTION_GROUP")

test_that("collection_group() works correctly", {
  expect_equal(unique(query_RNA$COLLECTION_GROUP), "RNA")
  expect_equal(sort(unique(query_RNA_DNA$COLLECTION_GROUP)), c("DNA", "RNA"))
})
