library(oncore2)
context("helpers")
test_that("checkOncoreObject works", {

  query <- oncore_connect("nrbyers", "hump15day")

  expect_error(select_fields("cow", SPECIMEN_NO))
  expect_silent(select_fields(query, SPECIMEN_NO))

  expect_error(select_annotations("cow", "Clotted"))
  expect_silent(select_annotations(query, "Clotted"))

  expect_error(execute_query("cow"))

})

context("oncore_connect")

test_that("oncore_connect creates oncoreQuery object", {
  expect_equal(class(oncore_connect("nrbyers", "hump15day")), "oncoreQuery")
})

test_that("oncore_connect correctly stores username/password/environement", {
  query <- oncore_connect("username", "password", "DEV")
  expect_equal(query$con$user, "username")
  expect_equal(query$con$pw, "password")
  expect_equal(query$con$env, "DEV")
})

context("select_fields")

test_that("error handling works for select_fields", {

  con <- oncore_connect("nrbyers", "hump15day")
  expect_error(select_fields(con, COW))
  expect_silent(select_fields(con, SPECIMEN_NO))

  con <- oncore_connect("nrbyers", "hump15day", error = "warn")
  expect_warning(select_fields(con, COW))
  expect_silent(select_fields(con, SPECIMEN_NO))

  con <- oncore_connect("nrbyers", "hump15day", error = "silent")
  expect_silent(select_fields(con, COW))
  expect_silent(select_fields(con, SPECIMEN_NO))

})

test_that("select_fields returns an oncoreQueryObject", {

  expect_equal(class(oncore_connect("nrbyers", "hump15day") %>% select_fields(SPECIMEN_NO)), "oncoreQuery")

})

test_that("select_fields stores selects properly", {

  query <- oncore_connect("nrbyers", "hump15day", error = "silent") %>%
    select_fields(SV_BSM_SPECIMEn.SpECIMEN_STORAGE_LOCATION, SPECIMEN_NO, SUBJECT_RACE_ID) %>%
    select_fields(COLLECTION_GROUP, ARM_NO, SV_BSM_PATIENT.SUBJECT_LAST_NAME, SPECIMEN_NO, SV_BSM_SPECIMEN.COW, SHEEP)

  expect_equal(nrow(query$select), 6)
  expect_true("SPECIMEN_STORAGE_LOCATION" %in% query$selects$COLUMN_NAME)
  expect_true("ARM_NO" %in% query$selects$COLUMN_NAME)
  expect_true("SUBJECT_RACE_ID" %in% query$selects$COLUMN_NAME)
  expect_true("COLLECTION_GROUP" %in% query$selects$COLUMN_NAME)
  expect_true("SUBJECT_LAST_NAME" %in% query$selects$COLUMN_NAME)
  expect_false("COW" %in% query$selects$COLUMN_NAME)
  expect_false("SHEEP" %in% query$selects$COLUMN_NAME)

})

context("select_annotations")

test_that("select_annotations returns an oncoreQuery object", {

  expect_equal(class(oncore_connect("nrbyers", "hump15day") %>% select_annotations("Clotted")), "oncoreQuery")

})
