library(testthat)
library(oncore2)

test_check("oncore2")
