async_execute <- function(queryObject, ...) {

  args <- get_args(environment(), c("queryObject"))
  if(length(args) > 0) {
    queryObject <- utils::modifyList(queryObject, args)
  }

  if(is.null(queryObject$query)) {
    future::plan(future::multicore)
    queryObject$start_time <- Sys.time()
    if(!"destination_file" %in% names(queryObject)) {
      queryObject$destination_file <- tempfile(fileext = ".rda")
    }
    queryObject$query <- future::future({
      query <- query_oncore(queryObject$sql, config = queryObject, async = FALSE)
      queryObject$query <- query
      save(query, queryObject, file = queryObject$destination_file)
      return(invisible(TRUE))
    })
  }

  if(!future::resolved(queryObject$query)) {
    later::later(function() {
      async_execute(queryObject)
    }, 5)
    return(invisible(FALSE))
  } else {
    e <- Sys.time() - queryObject$start_time
    rpt("Asynchronous query complete. Elapsed time: ", round(e, 2), " ", attr(e, "units"), "...")
    if(queryObject$load_async == TRUE) {
      tf <- future::value(queryObject$query)
      load(tf)
      queryObject$query <- tf
      queryObject <- clean_query(queryObject)
      if(queryObject$return_df == TRUE) {
        assign(queryObject$async_name, value = queryObject$query, envir = .GlobalEnv)
      } else {
        assign(queryObject$async_name, value = queryObject, envir = .GlobalEnv)
      }
      rpt("query added to global environment as `", queryObject$async_name , "`")
    }
    return(invisible(TRUE))
  }

}

