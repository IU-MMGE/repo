#' @rdname connection
#' @name connection
#' @title Raw connection to oncore
#' Make database connection to a specific environment of OnCore
#'
#' @param driver An object of class \code{OraDriver} or class \code{ExtDriver}.
#' @param username A character string specifying a user name.
#' @param password A character string specifying a password.
#' @param environment An object of class \code{oncore_environment}.
#' @param ... Parameters to pass to the \code{dbConnect()} function.
#' @examples
#' \dontrun{
#' drv <- dbDriver("Oracle")
#' clone <- specifyOnCoreEnvironment("CLN")
#' con <- dbConnectOnCore(drv, username = "myname", password = "secret", environment = clone)
#' dbDisconnect(con)
#' dbUnloadDriver(drv = drv)
#' }
#' @export
dbConnectOnCore <- function(config){
  connection <- config$connection
  if(tolower(config$connection_type) == 'odbc') {
    rpt("Establishing ODBC connection...")
    con <- DBI::dbConnect(odbc::odbc(), connection$schema, UID = connection$username, PWD = connection$password)
  } else {
    rpt("Establishing JDBC connection...")
    options(java.parameters = paste0("-Xmx", jvm_size))
    database_url <- makeConnectionString(host = connection$hostname, port = connection$port, service_name = connection$service)
    drv <- RJDBC::JDBC(driverClass = "oracle.jdbc.driver.OracleDriver", classPath = system.file("java/ojdbc8.jar", package = 'oncore2'))
    con <- DBI::dbConnect(drv, database_url, connection$username, connection$password)
  }
  return(con)
}

makeConnectionString <- function(host, port, service_name, protocol = 'tcps') {
  as.character(glue::glue("jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS=(PROTOCOL={protocol})(HOST={host})(PORT={port}))(CONNECT_DATA=(SERVICE_NAME={service_name})))"))
}

# Old ODBC-based connection string
# makeConnectionString <- function(host, port = 1521, sid){
#   paste(
#     "(DESCRIPTION=",
#     "(ADDRESS=(PROTOCOL=tcps)(HOST=", host, ")(PORT=", port, "))",
#     "(CONNECT_DATA=(SERVICE_NAME=", sid, ")))", sep = "")
# }

# dbConnectOnCore <- function(driver = "oracle", username, password, environment, ...){
#   check_oncore_environment(environment)
#   connection <- oncore2_settings$connections[[environment]]
#   database_name <- makeConnectionString(host = connection$hostname, port = connection$port, sid = connection$sid)
#   DBI::dbConnect(odbc::odbc(), Driver = "oracle", UID = username, PWD = password,
#                  Port = connection$port, Host = connection$hostname, SVC = connection$sid)
# }
