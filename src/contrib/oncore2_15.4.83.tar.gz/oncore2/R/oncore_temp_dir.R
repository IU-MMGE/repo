oncore_temp_dir <- function() {

  tmp <- file.path(gsub("[\\\\|/]R.*$)?", "", tempdir()), Sys.info()['user'], "oncore2")

  if(!dir.exists(tmp)) dir.create(tmp, recursive = TRUE)

  return(tmp)

}
