#'execute_query
#'
#'Excutes a query based on the supplied \code{oncoreQuery} object
#'
#'\code{execute_query} accepts only one arguement, \code{queryObject} which
#'should be an object of class \code{oncoreQuery}. If the \code{queryObject} is
#'an object of the class \code{oncoreQuery} then \code{execute_query} will
#'connect to oncore using the credentials provided to
#'the initial \code{connect_oncore} function, build an sql statement based on
#'the arguments provided to \code{select_fields}, \code{select_annotations}, and
#'\code{filter_oncore}, and execute that query. It will then disconnect from
#'oncore and return the result as a data.frame.
#'
#'The resulting data.frame will have an attribute called \code{queryObject} that
#'contains the original \code{oncoreQuery} object used to produce the data.frame
#'and an attribute \code{sql} that contains the sql statement sent to oncore.
#'
#'@param queryObject Must be a \code{oncoreQuery} object
#'@param execute Should the query be executed--if FALSE then the SQL statement is returned
#'@param mung Should column names be cleaned up
#'@param recode Should all of the coded columns be recoded
#'@param async Should the query be run asynchronously
#'@param output_name If asyn=TRUE, what should the return values name be?
#'@param check_for_duplicates Should oncore2 check for duplicated identifiers in the result?
#'
#'@export
execute_query <- function(queryObject, output_name = "query", execute = NULL,
                          mung = NULL, recode = NULL, reload = NULL, async = NULL,
                          return_df = NULL, check_for_duplicates = TRUE, use_mongo = FALSE,
                          mongo_db = NULL, mongo_collection = NULL, .args) {

  checkOncoreObject(queryObject)

  args <- get_args(environment())
  args <- args[names(args) != "queryObject"]
  if(!missing(.args)) {
    if(is.list(.args)) args <- utils::modifyList(args, .args)
  }

  if(length(args) > 0) {
    queryObject <- utils::modifyList(queryObject, args)
  }

#  if(any(queryObject$joins %in% oncore2_settings$protocol_joins)) {
#    queryObject$joins <- unique(c(queryObject$joins, "SV_BSM_CASE", "SV_PROTOCOL"))
#  }

  if(args$use_mongo) {
    rpt("Attempting to pull data from mongodb...")
    con <- mmgeMongo::mongo_connection(database = args$mongo_db,
                                       collection = args$mongo_collection)
    x <- make_mongo_query(queryObject)
    queryObject$query <- con$find(fields = x$fields, query = x$query)
  # } else if(args$source == "sqlite") {

  #   queryObject <- execute_query_sqlite(queryObject)

    } else {

    if(queryObject$source == "sqlite") {

      selects <- queryObject$selects
      annotations <- queryObject$annotations %>%
        dplyr::select(TABLE_NAME = ANNOTATION_TYPE,
                      COLUMN_NAME = ANNOTATION) %>%
        dplyr::mutate(
          TABLE_NAME = ifelse(TABLE_NAME == "SPECIMEN", "NSSV_BSM_SPECIMEN_ANNOTATIONS", "SV_BSM_CASE_ANNOTATIONS")
        )
      selects <- rbind(selects, annotations)
      queryObject$selects = selects
      queryObject$annotations = NULL
      if(any(grepl("ANNOTATIONS", queryObject$selects$TABLE_NAME))) {
        add_sqlite_annotations(queryObject)
      }

    }

    selects <- writeSelects(queryObject)
    annotations <- writeAnnotations(queryObject)
    queryObject <- writeJoins(queryObject)
    joins <- queryObject$join_statement
    if(!is.null(annotations)) {
      joins <- paste0(joins, annotations)
    }
    filters <- writeFilters(queryObject)
    if(queryObject$source == "sqlite") {
      table_pulls <- unique(c(queryObject$table_pulls,
        sapply(queryObject$filters, function(x) {
          x$joins
        })
      ))
      table_pulls <- table_pulls[!is.na(table_pulls)]
      table_pulls <- table_pulls[!grepl("ANNOTATIONS", table_pulls, fixed = TRUE)]
      for(t in table_pulls) {
        add_sqlite_table(t, queryObject)
      }
    }

    if(queryObject$distinct) {
      sql <- "SELECT DISTINCT"
    } else {
      sql <- "SELECT"
    }

    sql <- paste(sql, selects, "\nFROM", joins)
    # if("RACE" %in% queryObject$selects$COLUMN_NAME) {
    #   sql <- paste(sql, "\nGROUP_BY SV_BSM_SPECIMEN.SPECIMEN_NO\n")
    # }
    if(queryObject$source == "sqlite") {
      if(!is.null(queryObject$sqlite_conditions)) {
        sql <- paste(sql, "\nWHERE\n\t", paste0(queryObject$sqlite_conditions, collapse = " AND\n\t"))
      }
    } else {
      if(!is.null(queryObject$conditions)) {
        sql <- paste(sql, "\nWHERE\n\t", paste0(queryObject$conditions, collapse = " AND\n\t"))
      }
    }

    queryObject$sql <- sql
    queryObject$sha <- openssl::sha224(sql)
    queryObject$date <- format(Sys.Date(), "%Y%m%d")
    queryObject$file <- glue::glue("~/.oncore2/queries/{sha}_{date}.rda", .envir = queryObject)

    if(queryObject$execute == FALSE) {
      queryObject$return_df = FALSE
      rpt("Returning SQL statement...\nAll tasks complete...")
    } else if(!queryObject$async) {
      rpt("SQL statement built, attempting to query OnCore")
      queryObject$query <- try(query_oncore(sql, config = queryObject))
      queryObject <- clean_query(queryObject)
    } else if(queryObject$async) {
      rpt("Initiating asynchronous query...")
      query_oncore(sql, config = queryObject)
    }
  }

  if(queryObject$return_df == TRUE & queryObject$async == FALSE) {
    return(queryObject$query)
  } else {
    return(invisible(queryObject))
  }

}

clean_query <- function(queryObject) {
  if(queryObject$mung) {
    rpt("Munging column names...")
    # Make syntactically valid column names
    colnames(queryObject$query) <- mung_column_names(colnames(queryObject$query))
  } else {
    rpt("Skipping column name munging...")
  }
  if(queryObject$recode) {
    rpt("Recoding encoded columns...")
    queryObject <- recodeAllFields(queryObject)
  } else {
    rpt("Skipping field recode...")
  }
  if(queryObject$check_for_duplicates) {
    rpt("Checking result for duplicated identifiers")
    queryObject <- checkForDuplicates(queryObject)
  } else {
    rpt("Skipping duplicate check...")
  }

  return(invisible(queryObject))

}

writeSelects <- function(queryObject) {

  if(is.null(queryObject$selects)) {
    return(NULL)
  } else {
    # This is ugly hack to get SPECIMEN_STORAGE_LOCATION to work again after the
    # 'upgrade' to oncore 14.0.
    qo <- queryObject$selects
    # qo[qo$COLUMN_NAME == "SPECIMEN_STORAGE_LOCATION", ] <- c("oncore", "GET_STORAGE_LOCATION_TEXT(sv_bsm_specimen.pcs_specimen_id) SPECIMEN_STORAGE_LOCATION")

    # if("RACE" %in% qo$COLUMN_NAME) {
    #   queryObject$group_by = TRUE
    #   rt <- qo$TABLE_NAME[qo$COLUMN_NAME == "RACE"]
    #   qo <- qo[qo$COLUMN_NAME != "RACE", ]
    # } else {
    #   queryObject$group_by = FALSE
    # }

    cn <- qo$COLUMN_NAME
    if(queryObject$source == "sqlite") {
      cn <- paste0("`", qo$COLUMN_NAME, "`")
    }

    selects <- paste(qo$TABLE_NAME,
                     cn,
                     sep = ".")
#
#     if(queryObject$group_by) {
#       selects <- c(selects, paste0("LISTAGG(", rt , ".RACE, ';') WITHIN GROUP (ORDER BY ", rt, ".RACE) \"RACE\""))
#     }

    if(!is.null(queryObject$annotations)) {
      anno_selects <- sapply(seq(length(unique(queryObject$annotations$ANNOTATION_TYPE))),
                                        function(i) {
                                        paste0("A", i, ".*")
      })
      selects <- c(selects, anno_selects)
    }

    paste(selects, collapse = ",\n\t")

  }

}

writeAnnotations <- function(queryObject) {

  if(is.null(queryObject$annotations)) {
    return(NULL)
  } else {

    anno_info <- list(SPECIMEN = c("SV_BSM_SPECIMEN", "NSSV_BSM_SPECIMEN_ANNOTATIONS"),
                          CASE = c("SV_BSM_CASE", "SV_BSM_CASE_ANNOTATIONS"))
    anno_tables <- split(queryObject$annotations, queryObject$annotations$ANNOTATION_TYPE)
    anno_joins <- sapply(seq_along(anno_tables), function(i) {

      at <- anno_tables[[i]]
      tn <- paste0("A", i)
      al <- anno_info[[at$ANNOTATION_TYPE[1]]]
      no <- paste0(at$ANNOTATION_TYPE[1], "_NO")
      annotations <- paste0("'", at$ANNOTATION, "'", collapse = ", ")

      if(queryObject$source == "sqlite") {
        at <- al[2]
        join_type = "LEFT JOIN"
      } else {
        at <- paste0(queryObject$connection$schema, ".", al[2])
        join_type = "FULL OUTER JOIN"
      }

        op <- paste0("\n\t", join_type, " (SELECT DISTINCT * \n\t\tFROM (SELECT ", no, " AS JOIN_", no, ", COLUMN_DISPLAY_NAME, LISTAGG(VALUE, '|') WITHIN GROUP (ORDER BY VALUE) \"ANNOTATIONS\"
               FROM ", at, " WHERE COLUMN_DISPLAY_NAME IN (", annotations,")
               GROUP BY COLUMN_DISPLAY_NAME, ", no, ")",
                     "\n\t\tPIVOT (max(ANNOTATIONS) FOR COLUMN_DISPLAY_NAME IN (", annotations,
                     ")\n\t\t)\n\t\tORDER BY JOIN_", no, ") ", tn, "\n\tON ", tn, ".JOIN_", no, " = ", al[1], ".", no)

        return(op)

    })

    return(paste(anno_joins, collapse = ""))

  }

}

writeFilters <- function(queryObject) {

}

