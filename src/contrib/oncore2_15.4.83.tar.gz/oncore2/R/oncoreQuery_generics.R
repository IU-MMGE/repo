as.data.frame.oncoreQuery <- function(queryObject) {

  if("query" %in% names(queryObject)) {
    return(queryObject$query)
  } else {
    msg("Cannot convert object of type `queryObject` to data.frame until after query has been executed", type = 'error')
  }

}


print.oncoreQuery <- function(queryObject) {

  if("sql" %in% names(queryObject)) {
    sql <- queryObject$sql
    tables <- paste(unique(field_list()$TABLE_NAME), collapse = "|")
    fields <- paste(unique(field_list()$COLUMN_NAME), collapse = "|")
    keywords <- paste(c("SELECT", "SELECT DISTINCT", "FROM", "JOIN", "LEFT JOIN", "WHERE", "ON"), collapse = "|")
    x <- stri_replace_all(sql, crayon::red("$0"), regex = tables)
    fields <- "SPECIMEN_NO|SPECIMEN_TYPE|SPECIMEN_QUANTITY"
    x <- stri_replace_all(x, crayon::green("$0"), regex = fields)

    x <- str_replace_all(sql, tables, crayon::red("\\0"))
    x <- str_replace_all(x, fields, crayon::green("\\0"))
    x <- str_replace_all(x, keywords, crayon::blue("\\0"))

    cat(x)
  } else {
    q <- queryObject
    q$connection$password <- "XXXXXXXXXXXXX"
    class(q) <- "list"
    print(q)
  }

}
