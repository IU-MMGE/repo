#' @importFrom magrittr %>%
#' @export
magrittr::`%>%`

#Sets the size of the Java Virtual Machine for using JDBC driver
jvm_size <- "4096m"
oncore2_settings <- get_config_file("tables", TRUE)

oncore2_config_dir <- "/etc/oncore2"

.onLoad <- function(libname, pkgname) {

  user <- system("whoami", intern = TRUE)
  if(user == 'root') {
    warning("oncore2 is not meant to be run as root user. Unexpected behavior may result.")
  } else {
    if(!'.oncore2' %in% list.dirs("~", recursive = FALSE, full.names = FALSE)) {
      msg("oncore2 does not appear to be configured yet. Please run `initialize_oncore2_user()` before attempting to use oncore2.", type = 'warning')
    } else {
      tryCatch({
        settings <- get_config_file("tables", TRUE)
        user_dir <- "~/.oncore2"
        user_files <- list.files(user_dir, pattern = paste(settings$internal_tables, collapse = "|"), full.names = TRUE)
        if(length(user_files) != length(settings$internal_tables)) {
          msg("Building internal oncore2 data for the first time", type = "info")
          try(build_internal_data(async = FALSE))
        } else if(any(format(file.info(user_files)$mtime, "%Y%m%d") != format(Sys.Date(), "%Y%m%d"))) {
          try(build_internal_data(async = TRUE))
        }
      }, error = function(e) {
        msg("There was a problem loading your configuration files. Please try running `initialize_oncore2_user()` if the problem persists.", type = 'warning')
      })
    }
  }

}

system3 <- function(..., intern = TRUE) {

  x <- paste0(list(...), collapse = "")

  y <- suppressWarnings(system(x, intern = intern))

  if(intern == TRUE) {
    if(!is.null(attr(y, "status"))) {
      return(FALSE)
    } else {
      return(y)
    }
  } else {
    return(y == 0)
  }

}


write_config_file <- function(src_file, dest_file) {

  backup <- ifelse(file.exists(dest_file), tools::md5sum(dest_file) != tools::md5sum(src_file), FALSE)

  if(backup) {
    msg("Backing up old ", f, "...", type = 'info')
    backup_file <- paste0(dest_file, ".", format(Sys.time(), "%Y%m%d%H%M"))
    while(file.exists(backup_file)) {
      if(!grepl("\\.[0-9]{3}$", backup_file)) {
        backup_file <- paste0(backup_file, ".001")
      } else {
        ver <- sprintf("%03i", as.numeric(strsplit(backup_file, "\\.")[[1]][4]) + 1)
        backup_file <- gsub("[0-9]{3}$", ver, backup_file)
      }
    }
    if(system3("sudo mv ", dest_file, " ", backup_file, intern = FALSE)) {
      msg("Success", type = 'success', indent = TRUE)
    } else {
      msg("Failed", type = 'error', indent = TRUE)
    }
  } else {
    msg(dest_file, " hasn't changed or doesn't exist. Skipping backup...", type = 'info')
  }

  msg("Copying `", basename(dest_file), "` to `", dirname(dest_file), "`...", type = 'info')
  if(system3("sudo cp ", src_file, " ", dest_file, intern = FALSE)) {
    msg("Success", type = 'success', indent = TRUE)
  } else {
    msg("Failed", type = 'error', indent = TRUE)
  }

}

#'@export
clear_oncore2_cache <- function(save_days = NULL) {
  if(is.null(save_days)) {
    system("rm ~/.oncore2/queries/*.rda")
  } else {
    cutoff_date <- Sys.Date() - save_days
    queries <- list.files("~/.oncore2/queries", full.names = TRUE)
    if(length(queries) > 0) {
      q_date <- as.Date(sapply(regmatches(queries, regexec("([[:digit:]]+).rda", queries)), function(x) x[2]), format = "%Y%m%d")
      to_remove <- queries[q_date <= cutoff_date]
      if(length(to_remove) > 0) {
        msg("Removing ", length(to_remove), " old queries from the oncore2 cache.", type = 'info')
        file.remove(to_remove)
      }
    }
  }
}

add_filter_class <- function(x) {

  class(x) <- c('oncore_filter', class(x))
  return(x)

}
