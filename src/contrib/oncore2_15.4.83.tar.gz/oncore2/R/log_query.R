log_query <- function(sql, config, start_time, end_time, result) {

  user <- system("whoami", intern = TRUE)

  log_dir <- glue::glue("~/.oncore2/logs")
  if(!dir.exists(log_dir)) dir.create(log_dir)

  log_file <- file.path(log_dir, glue::glue("oncore2_log_{format(Sys.Date(), '%Y_%m')}.json"))
  if(!file.exists(log_file)) file.create(log_file)

  log_entry <- list(
    result = NA,
    env = config$env,
    oncore_user = config$connection$username,
    system_user = user,
    connection_type = config$connection_type,
    sql = sql,
    start_time = start_time,
    end_time = end_time,
    elapsed_time = format(round(end_time - start_time, 2)),
    rows = NA,
    columns = NA,
    error = NA
  )

  if(is.data.frame(result)) {
    d <- dim(result)
    log_entry$result <- "success"
    log_entry$rows <- d[1]
    log_entry$columns <- d[2]
  } else if(inherits(result, 'try-error')) {
    log_entry$result <- "failure"
    log_entry$error <- attr(result, 'condition')$message
  } else {
    log_entry$result <- "unknown_error"
  }

  log_entry <- jsonlite::toJSON(log_entry, auto_unbox = TRUE)

  write(log_entry, log_file, append = TRUE)

}

get_oncore_log <- function(user = whoami(), month = format(Sys.Date(), '%Y_%m')) {

  log_dir <- glue::glue("~/.oncore2/logs")
  log_file <- file.path(log_dir, glue::glue("oncore2_log_{format(Sys.Date(), '%Y_%m')}.json"))
  if(!file.exists(log_file)) {
    msg(glue::glue("No logs exists for {user} in {month}"), type = 'error')
  }

  jsonlite::fromJSON(paste("[", paste(readLines(log_file), collapse = ","), "]"))

}
