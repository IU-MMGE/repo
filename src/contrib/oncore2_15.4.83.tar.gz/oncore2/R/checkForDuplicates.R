checkForDuplicates <- function(queryObject) {

  keys <- unlist(oncore2_settings$primary_views)
  key <- keys[keys %in% colnames(queryObject$query)][1]

  if(is.na(key)) {
    rpt("No keys identified for duplicate check. Skipping...")
    return(queryObject)
  }

  q <- data.table::as.data.table(queryObject$query)

  data.table::setkeyv(q, key)
  data.table::setindexv(q, key)

  dup <- unique(q[[key]][duplicated(q[[key]])])

  collapse <- compiler::cmpfun(function(x) {
    y <- is(x)[1]
    z <- paste(unique(x), collapse = "|")
    w <- suppressWarnings(as(z, Class = y))
    if(is.na(w)) {
      return(z)
    } else {
      return(w)
    }
  })
  unique_count <- function(x) {
    length(unique(x))
  }
  if(length(dup) > 0) {
    if(any(!is.na(dup))) {

      dups <- q[q[[key]] %in% dup, ]
      d <- dups %>%
        dplyr::group_by_(key) %>%
        dplyr::summarize_all(unique_count) %>%
        dplyr::ungroup() %>%
        dplyr::select(-key) %>%
        dplyr::summarize_all(sum) %>%
        unlist()
      d <- names(d[d != length(dup)])
      msg("Duplicate SPECIMEN_NOs found in query. Problem Fields: \n\t", paste0(d, collapse="\n\t"), type = "warning")
      for(col in d) {
        dups <- dplyr::group_by_(dups, key)
        dups <- eval(parse(text = glue::glue("dplyr::mutate(dups, {col} = paste(unique({col}), collapse = '|'))")))
        q[[col]] <- as.character(q[[col]])
      }
      dups <- data.table::as.data.table(dplyr::distinct(dups))
      data.table::setkeyv(dups, key)
      q <- q[!q[[key]] %in% dups[[key]], ]
      q <- data.table:::rbind.data.table(q, dups)

      queryObject$query <- as.data.frame(q)

    }
  }

  return(queryObject)

}
