
make_mongo_query <- function(query) {

  selects <- c("PROTOCOL_NO", query$selects$COLUMN_NAME)
  fields <- as.list(rep(TRUE, times = length(selects)))
  names(fields) <- selects
  fields$`_id` <- FALSE
  fields <- jsonlite::toJSON(fields, auto_unbox = TRUE)
  mquery <- c()

  make_single_filter <- function(value, field, not = FALSE) {
    if(not) {
      v = glue::glue("{{\"{field}\": {{\"$ne\": \"{value}\"}}}}")
    } else {
      v <- glue::glue("{{\"{field}\": \"{value}\"}}")
    }
    return(v)
  }

  for(i in seq(length(query$filters))) {
    oncore_filter = query$filters[[i]]
    field <- attr(oncore_filter, "field")
    value <- attr(oncore_filter, "values")[[1]]
    not = attr(oncore_filter, "not")
    if(is.null(not)) not = FALSE
    if(length(value) == 1) {
      filters <- make_single_filter(value, field, not)
    } else if(length(value) > 1) {
      filters = c()
      for(j in seq(length(value))) {
        filters <- c(filters, make_single_filter(value[j], field, not))
      }
      filters <- glue::glue("{{\"$or\": [{paste(filters, collapse = ',')}]}}")
    }
    mquery <- c(mquery, filters)
  }

  mquery <- glue::glue("{{\"$and\":[{paste(mquery, collapse = ',')}]}}")

  return(list(
    fields = fields,
    query = mquery
  ))

}


