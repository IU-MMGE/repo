#' Initialize the oncoreQuery object
#'
#' Creates an \code{oncoreQuery} object that can be built up by other
#' \code{oncore2} functions.
#'
#' \code{oncore_connect} accepts a username, password, and environment for
#' connecting to the oncore database. The environment defaults to the clone
#' environment and username and password can be set as environmental variables.
#'
#' Set \code{ONCORE_USER} as an environmental variable to avoiding needing to
#' add your username each time. Similarly, set the \code{ONCORE_PW}
#' environmental variable to remove the need for including your password each
#' time.
#'
#' This function returns an \code{oncoreQuery} object which is the required
#' first argument for all the other querying functions.
#'
#' @param env The oncore environment to connect to (See details)
#' @param error How to handle errors (See details)
#' @param verbose Should the query let you know what it is doing?
#' @param distinct Only return distinct results
#' @param query_name save the query with this name for faster retrieval later (Deprecated)
#' @param protocol_filter Limit results to only samples whose filter matches this regex
#' @param connection_type Connect to OnCore through JDBC or ODBC
#' @param source Use oncore or SQLite as data source
#' @param .args Pass a list of arguments for easier programming
#'
#' @export
oncore_connect <- function(env = NULL, error = NULL, verbose = NULL,
                           distinct = NULL, protocol_filter = NULL, use_mongo = FALSE,
                           query_name = NULL, connection_type = NULL, source = "oncore", .args) {

  # Create a list of all the non-null arguments passed to oncore_connect
  if(missing(.args)) {
    .args = get_args(environment())
  }
  config <- get_config(.args)

  config$user <- system("whoami", intern = TRUE)

  # if(config$migration_data) {
  #   msg("`migration_data` == TRUE, `env` set to 'STG'", type = "warning")
  #   config$env <- "STG"
  # }

  if(!"connection" %in% names(config)) {
    msg("Invalid environment: ", config$env, type = "error")
  }

  if(!all(c('username', 'password') %in% names(config$connection))) {
    msg("Missing credentials for environment: ", config$env, type = "error")
  }

  if(!all(c('hostname', 'service', 'port', 'schema') %in% names(config$connection))) {
    msg("Incomplete connection information for environment: ", config$env, type = "error")
  }

  queryObject <- utils::modifyList(config, list(
    selects = NULL,
    joins = NULL,
    annotations = NULL,
    conditions = NULL
  ))

  class(queryObject) <- "oncoreQuery"

  rpt("oncoreQuery object created...\n\tEnvironment: ", config$env)

  return(queryObject)

}
