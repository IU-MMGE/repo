get_data_file <- function(table) {

  fn <- as.character(glue::glue("~/.oncore2/{table}.rda"))
  load(fn)
  return(eval(parse(text = table)))

}

#'@export
field_list <- function() {
  get_data_file('field_list')
}

#'@export
annotation_list <- function() {
  get_data_file('annotation_list')
}

#'@export
lookup_table <- function() {
  get_data_file('lookup_table')
}

check_for_connection <- function(config) {

  if(config$check_connection == TRUE) {
    rpt("Checking for connection to OnCore")
    y <- system2("ping", args = c("-w 2", config$connection$hostname), stdout = FALSE, stderr = FALSE)

    if(y != 0) {
      msg("Cannot reach OnCore. If you are connecting through the VPN please ensure that it is active and try again.", type = 'error')
    }

    return(y == 0)

  }

}

rpt <- function(...) {

  if(as.logical(Sys.getenv('oncore2_verbose')) == TRUE) {
    msg(..., type = 'info')
  }

}

msg <- function(..., type = c('none', 'success', 'warning', 'error', 'info'), indent = FALSE) {

  if(length(type) > 1) {
    type = type[1]
  }

  symbol <- list(
    success = crayon::green(clisymbols::symbol$tick),
    warning = crayon::yellow(clisymbols::symbol$warning),
    error = crayon::red(clisymbols::symbol$cross),
    info = crayon::blue(clisymbols::symbol$info),
    none = ""
  )

  style <- list(
    success = crayon::combine_styles("bold", "green"),
    warning = crayon::combine_styles("bold", "yellow"),
    error = crayon::combine_styles("bold", "red"),
    info = crayon::combine_styles("bold", "blue"),
    none = crayon::strip_style
  )

  i <- paste(rep(x = " ", times = indent * 4), collapse = "")

  op <- paste(i, symbol[[type]], style[[type]](paste(list(...), collapse = "")))

  if(!crayon::has_color()) {
    op <- crayon::strip_style(op)
  }

  switch(type,
         success = message(op),
         warning = warning(op, call. = FALSE),
         error = stop("\n", op, call. = FALSE),
         info = message(op),
         none = cat(op)
  )

  return(invisible(op))

}

