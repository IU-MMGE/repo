#'@export
viewSQL <- function(df) {

  if("sql" %in% names(attributes(df))) {
    cat(attr(df, "sql"))
  } else {
    stop("Object doesn't cantain sql data")
  }

}

#'@export
getQueryObject <- function(df) {

  if("queryObject" %in% names(attributes(df))) {
    return(attr(df, "queryObject"))
  } else {
    stop("Object doesn't contain query data")
  }

}
