#'@export
mung_column_names <- function(column_names) {

  # Make syntactically valid column names
  column_names <- toupper(column_names)
  column_names <- gsub(" ", "_", column_names, fixed = TRUE)
  column_names <- gsub("'", "", column_names, fixed = TRUE)
  column_names <- make.names(column_names)

  return(column_names)

}
