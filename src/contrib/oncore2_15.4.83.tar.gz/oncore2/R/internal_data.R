build_internal_data <- function(..., async = TRUE, verbose = FALSE) {

  # Be sure to add any tables you add to this to the tables.yaml config file

  tables <- get_config_file("tables", TRUE)$internal_tables

  make_tables <- function(config, tables) {

    files <- sapply(tables, function(table) {
      msg("Creating ", table, "...", type = "info")
      x <- eval(parse(text = paste0("make_", table, "(config)")))
      assign(table, value = x)
      file_path <- file.path("~", ".oncore2", paste0(table, ".rda"))
      save(list = c(table), file = file_path)
      return(file_path)
    })

  }

  fp <- file.path("~/.oncore2")
  if(!dir.exists(fp)) {
    msg("You must initialize oncore2 with `initialize_oncore2_user()` first.", type = 'error')
  }

  config <- get_config(args = list(verbose = verbose, async = FALSE))

  if(async) {
    future::plan(future::multicore)
    future::future({make_tables(config, tables)})
  } else {
    make_tables(config, tables)
  }

  return(invisible(TRUE))

}

make_views_df <- function() {

  views <- suppressWarnings(readxl::read_excel(system.file("data/oncore_views.xlsx", package = 'oncore2')))
  colnames(views) <- toupper(colnames(views))
  colnames(views) <- gsub(" ", "_", colnames(views), fixed = TRUE)
  colnames(views) <- gsub("'|\\(|\\)", "", colnames(views))
  colnames(views) <- make.names(colnames(views))
  views$TYPE <- "view"
  views <- views[, c("VIEW_NAME", "VIEW_FIELD_NAME", "TYPE")]
  colnames(views) <- c("VIEW_NAME", "FIELD", "TYPE")

  views$VIEW_NAME <- toupper(views$VIEW_NAME)
  views$FIELD <- toupper(views$FIELD)

  return(views)

}

make_field_list <- function(config, ...) {

  args <- get_args(environment(), c("config"))

  if(missing(config)) {
    config <- get_config(args)
  } else {
    config <- utils::modifyList(config, args)
  }

  oncore2_settings <- get_config_file('tables', TRUE)

  #Get all tables and fields
  field_list <- query_oncore("SELECT table_name, column_name FROM ALL_TAB_COLUMNS", config)

  link_fields <- unlist(oncore2_settings$primary_views)

  links <- unique(field_list$TABLE_NAME[field_list$COLUMN_NAME %in% link_fields])

  field_list <- field_list[field_list$TABLE_NAME %in% links, ]

  field_list$TYPE <- "view"
  field_list$SCORE <- 0

  tables <- unlist(query_oncore("SELECT table_name FROM all_constraints WHERE constraint_type = 'P'"), config)

  field_list$TYPE[field_list$TABLE_NAME %in% tables] <- "table"
  field_list$TYPE[field_list$TABLE_NAME %in% make_views_df()$VIEW_NAME] <- "safe_view"
  field_list$TYPE[field_list$TABLE_NAME %in% names(oncore2_settings$primary_views)] <- "primary_view"

  for(i in seq(length(oncore2_settings$field_score_adjustments))) {
    test <- names(oncore2_settings$field_score_adjustments)[i]
    value <- oncore2_settings$field_score_adjustments[[i]][[1]]
    type <- oncore2_settings$field_score_adjustments[[i]][[2]]
    if(type == "set") {
      eval(parse(text = sprintf("field_list$SCORE[%s] <- %s", test, value)))
    } else if(type == "adjust") {
      eval(parse(text = sprintf("field_list$SCORE[%s] <- field_list$SCORE[%s] + %s", test, test, value)))
    }
  }

  for(i in seq_along(oncore2_settings$primary_views)) {

    # Weight the primary keys for the primary tables high and for non-primary tables low
    field_list$SCORE[field_list$TABLE_NAME == names(oncore2_settings$primary_views)[i] &
                       field_list$COLUMN_NAME %in% oncore2_settings$primary_views[[i]]] <- 10 + i
    field_list$SCORE[field_list$TABLE_NAME != names(oncore2_settings$primary_views)[i] &
                       field_list$COLUMN_NAME %in% oncore2_settings$primary_views[[i]]] <- 999

    # # Find all the linked tables
    # sql <- paste0("select table_name from all_tab_columns where column_name='", oncore2_settings$primary_views[i],"'")
    # x <- unlist(query_oncore(sql, config))
    #
    # # Report all the links
    # field_list[names(oncore2_settings$primary_views)[i]] <- field_list$TABLE_NAME %in% x
    # # Remove the primary_views for scoring purposes
    # x <- x[!x %in% names(oncore2_settings$primary_views)]
    # # Tweak the score a bit to account for specificity
    # twk <- field_list[[names(oncore2_settings$primary_views)[i]]] &
    #   field_list$TABLE_NAME != names(oncore2_settings$primary_views)[i] &
    #   field_list$SCORE %% 200 == 0
    # field_list$SCORE[twk] <- field_list$SCORE[twk] + (i*length(oncore2_settings$primary_views))

  }

  # Order by score so that the package can just pick the first returned result each time.
  field_list <- field_list[order(field_list$SCORE), ]

#  field_list$PROTOCOL_JOIN = field_list$TABLE_NAME %in% oncore2_settings$protocol_joins
#  field_list$SV_BSM_CASE[field_list$TABLE_NAME %in% oncore2_settings$protocol_joins] <- TRUE
#  field_list$SV_BSM_PATIENT[field_list$TABLE_NAME %in% oncore2_settings$protocol_joins] <- FALSE

  return(field_list)

}

make_annotation_list <- function(config, ...) {

  args <- get_args(environment(), c("config"))

  if(missing(config)) {
    config <- get_config(args)
  } else {
    config <- utils::modifyList(config, args)
  }

  specimen <- query_oncore("SELECT DISTINCT COLUMN_DISPLAY_NAME FROM {schema}.SV_BSM_SPECIMEN_ANNOTATIONS", config)
  case <- query_oncore("SELECT DISTINCT COLUMN_DISPLAY_NAME FROM {schema}.SV_BSM_CASE_ANNOTATIONS", config)
  specimen$ANNOTATION_TYPE <- "SPECIMEN"
  case$ANNOTATION_TYPE <- "CASE"

  annotations <- rbind(specimen, case)
  colnames(annotations) <- c("ANNOTATION", "ANNOTATION_TYPE")

  return(annotations)

}

make_lookup_table <- function(config, ...) {

  args <- get_args(environment(), c("config"))

  if(missing(config)) {
    config <- get_config(args)
  } else {
    config <- utils::modifyList(config, args)
  }
  #Get the PF_CODE Table
  pf_code <- query_oncore("SELECT CODE_ID, CATEGORY, CODE, DESCRIPTION FROM {schema}.PF_CODE", config = config)
  #Get the EDC Table
  edc <- query_oncore("SELECT OPTION_LIST_ITEM_ID, TYPE, CODE_ID, DESCRIPTION FROM {schema}.EDC_OPTION_LIST_ITEM", config = config)
  edc <- edc[!is.na(edc$DESCRIPTION), ]
  edc$OPTION_LIST_ITEM_ID <- as.character(edc$OPTION_LIST_ITEM_ID)
  edc$TYPE <- "EDC"
  colnames(edc) <- colnames(pf_code)
  pf_code <- rbind(pf_code, edc)
  return(pf_code)

}
