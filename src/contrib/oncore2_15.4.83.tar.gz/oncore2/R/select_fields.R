#' select_fields
#'
#' Select fields to include in your query
#'
#' As with all oncore2 query functions, you must provide an object of type
#' \code{oncoreQuery} as the first argument. \code{select_fields} will modify
#' this object and return the updated version so that chaining can be performed.
#'
#' \code{select_fields} uses non-standard evalution to flow better with
#' \code{dplyr}. You should provide names of fields in the
#' \code{oncore_field_list} data object that is part of this package. Do not use
#' quotes and seperate each desired column by a comma.
#'
#' \code{select_fields} will make its best guess at which view to take a field
#' from. It you want to specify a specific view, prepend the view name to the
#' field name separated by a period (.) (e.g., \code{VIEW_NAME.FIELD_NAME})
#'
#' @note
#' You can chain multiple \code{select_fields} functions together. Each time the
#' new call will add to the existing object.
#'
#' @export
select_fields <- function(queryObject, ...) {

  # Get Field Names to add
  fields <- nse(...)

  select_fields_(queryObject = queryObject, fields)

}

#' select_fields_
#'
#' As with all oncore2 query functions, you must provide an object of type
#' \code{oncoreQuery} as the first argument. \code{select_fields} will modify
#' this object and return the updated version so that chaining can be performed.
#'
#' \code{select_fields_} uses standard evaluation. You should provide quoted names
#' of fields in the \code{oncore_field_list} data object that is part of this package.
#'
#' \code{select_fields_} will make its best guess at which view to take a field
#' from. It you want to specify a specific view, prepend the view name to the
#' field name separated by a period (.) (e.g., \code{VIEW_NAME.FIELD_NAME})
#'
#' @note
#' You can chain multiple \code{select_fields_} functions together. Each time the
#' new call will add to the existing object.
#'
#' @export
select_fields_ <- function(queryObject, ..., .dots) {

  checkOncoreObject(queryObject)

  # Get Field Names to add
  fields <- list(...)
  if(!missing(.dots)) {
    fields <- unique(c(fields, .dots))
  }
  classes <- sapply(fields, function(x) class(x) != "character")
  if(sum(classes) > 0){
    stop("You must enter character vectors.")
  }
  fields <- unlist(fields)

  fields <- standard_names(fields)

  fields <- as.data.frame(do.call(rbind, lapply(fields, function(f) {

    if(grepl(".", f, fixed = TRUE)) {
      op <- strsplit(f, ".", fixed = TRUE)[[1]]
      if(length(op) > 2) {
        handleError(queryObject,
                    paste("Did not recognize", f, "as a valid table/field combination."))
      }
    } else {
      table <- field_list()$TABLE_NAME[field_list()$COLUMN_NAME == f][1]
      if(is.na(table)) {
        handleError(queryObject,
                    paste("Did not recognize", f, "as a valid field name."))
      }
      op <- c(table, f)
    }

    return(op)

  })), stringsAsFactors = FALSE)

  colnames(fields) <- c("TABLE_NAME", "COLUMN_NAME")

  beginning_length <- nrow(queryObject$selects)
  if(is.null(beginning_length)) beginning_length = 0

  #error checking the selects
  errors <- c()
  to_remove <- c()
  for(i in seq(nrow(fields))) {
    if(nrow(field_list()[field_list()$TABLE_NAME == fields$TABLE_NAME[i] &
                        field_list()$COLUMN_NAME == fields$COLUMN_NAME[i], ]) == 0) {
      to_remove <- c(to_remove, i)
      errors <- c(errors, paste(field_list()$TABLE_NAME, field_list()$COLUMN_NAME, sep = "."))
    }
  }
  if(length(errors) > 0) {
    fields <- fields[-to_remove, ]
    handleError(queryObject, paste0("The following fields could not be matched\n\t",
                                    paste(errors, sep = "\t\n")))
  }

  queryObject$selects <- unique(rbind(queryObject$selects, fields))
  queryObject$joins <- unique(c(queryObject$joins, fields$TABLE_NAME))

  l <- (nrow(queryObject$selects) - beginning_length)
  rpt("Added ", l, " select", ifelse(l != 1,"s", ""), " to query...")

  return(queryObject)

}

