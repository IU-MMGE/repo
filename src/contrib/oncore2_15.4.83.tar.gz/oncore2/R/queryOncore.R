#'@export
query_oncore <- function(sql, config, ...) {

  args <- get_args(environment(), c('sql', 'config'))

  if(missing(config)) {
    config <- get_config(args)
  } else if(length(args) > 0) {
    config <- utils::modifyList(config, args)
  }

  sql <- glue::glue(sql, .envir = config$connection)
  user <- system("whoami", intern = TRUE)
  sha <- openssl::sha224(sql)
  date <- format(Sys.Date(), "%Y%m%d")
  save_file <- glue::glue("~/.oncore2/queries/{sha}_{config$env}_{date}.rda")

  if(config$reload == TRUE & file.exists(save_file)) {
    rpt("Loading saved query")
    load(save_file)
  } else if(!config$async) {
    rpt("Connecting to OnCore...")
    check_for_connection(config)
    con <- dbConnectOnCore(config)
    start_time <- Sys.time()
    rpt("Query Started: ", format(start_time, "%I:%M:%S %p"))
    query <- try(DBI::dbGetQuery(con, sql), silent = TRUE)
    end_time <- Sys.time()
    rpt("Disconnecting from OnCore")
    DBI::dbDisconnect(con)
    log_query(sql, config, start_time, end_time, query)
    if(inherits(query, 'try-error')) {
      rpt("Query Errored: ", format(Sys.time(), "%I:%M:%S %p"))
      message(query)
      rpt("Elapsed time: ", format(round(end_time - start_time, 2)))
      msg(query, type = 'warning')
      return(invisible(FALSE))
    } else {
      rpt("Query Complete: ", format(Sys.time(), "%I:%M:%S %p"))
      rpt("Elapsed time: ", format(round(end_time - start_time, 2)))
      if(config$save_query == TRUE) {
        clear_oncore2_cache(3)
        rpt("Saving query as ", save_file)
        save(query, file = save_file)
      }
    }
  } else {
    rpt("Initiating asynchronous query...")
    async_execute(config)
  }

  return(query)

}

# Alias for query_oncore for backwards compatibility
#'@export
queryOnCore <- query_oncore
