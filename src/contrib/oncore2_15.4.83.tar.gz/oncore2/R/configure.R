check_user_group <- function(user, group) {
  if(missing(group)) {
    group <- user
    user <- system('whoami', intern = TRUE)
  }
  grepl(user, system(paste0("grep '", group, "' /etc/group"), intern = TRUE))
}

configure <- function() {

  if(rstudioapi::isAvailable()) {
    if(check_user_group('rstudio_superusers')) {
      config_files <- list.files(oncore2_config_dir, pattern = "\\.yaml$")
      for(cf in config_files) {
        rstudioapi::navigateToFile(cf)
      }
    } else {
      msg("You do not have sufficient privileges to edit the oncore2 configuration files", type = 'error')
    }
  } else {
    msg("You must use `oncore::configure()` from within RStudio. \n   To edit the oncore2 configuration files outside of RStudio please navigate to `", oncore2_config_dir, "`", type = 'info')
  }

}

#'@export
get_config_file <- function(file_name, use_default = FALSE) {

  if(use_default) {
    file_path <- file.path(system.file("config_files", package = "oncore2"), paste0(file_name, ".yaml"))
    if(file.exists(file_path)) {
      return(yaml::yaml.load_file(file_path))
    }
  } else {
    file_path <- file.path(oncore2_config_dir, paste0(file_name, ".yaml"))
    if(file.exists(file_path)) {
      return(yaml::yaml.load_file(file_path))
    }
    file_path <- file.path("~/.oncore2", paste0(file_name, ".yaml"))
    if(file.exists(file_path)) {
      return(yaml::yaml.load_file(file_path))
    }
  }

  stop("Could not locate config file: ", file_name, call. = FALSE)

}

