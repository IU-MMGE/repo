#' @importFrom magrittr %>%
#' @export
magrittr::`%>%`

#' @importFrom future %<-%
#' @export
future::`%<-%`

whoami <- function() {
  system("whoami", intern = TRUE)
}
