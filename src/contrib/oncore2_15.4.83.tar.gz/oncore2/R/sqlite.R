buildSQLiteOncoreTable <- function(sqlite_con, table_name, oncore_config, limit = 1000000, ...) {

  args <- get_args(environment(), c('sqlite_con', 'table_name', 'oncore_config', 'limit'))

  if(missing(oncore_config)) {
    oncore_config <- get_config(args)
  } else if(length(args) > 0) {
    oncore_config <- utils::modifyList(oncore_config, args)
  }

  oncore_config$source = "oncore"
  offset = 0
  keep_going = TRUE

  index_fields <- c(
    "PCS_SPECIMEN_ID",
    "SPECIMEN_NO",
    "SPECIMEN_BAR_CODE",
    "PCS_CASE_ID",
    "CASE_NO",
    "PROTOCOL_SUBJECT_ID",
    "PATIENT_ID",
    "PROTOCOL_ID",
    "PROTOCOL_NO"
  )

  try(DBI::dbRemoveTable(sqlite_con, table_name), silent = TRUE)
  while(keep_going) {
    df <- oncore2::query_oncore(glue::glue("SELECT * FROM {{schema}}.{table_name} OFFSET {offset} ROWS FETCH NEXT {limit} ROWS ONLY"), reload=FALSE)
    DBI::dbWriteTable(sqlite_con, name = table_name, value = df, append = offset > 0)
    if(nrow(df) < limit) {
      keep_going = FALSE
      message("Added ", prettyNum(offset + nrow(df), big.mark = ",") , " records to ", table_name, "...")
    } else {
      offset = offset + limit
      message("Added ", prettyNum(offset, big.mark = ","), " records to ", table_name, "...")
    }
  }

  table_indexes <- index_fields[index_fields %in% colnames(df)]

  for(table_index in table_indexes) {
    try(DBI::dbSendQuery(sqlite_con, glue::glue("CREATE INDEX {paste0(table_name, '_', table_index)} ON {table_name} ({table_index})")))
  }

}

add_sqlite_table <- function(table, config, overwrite = FALSE, ...) {

  args <- get_args(environment(), c('table', 'config', 'overwrite'))

  if(is.na(table)) {
    return(invisible(FALSE))
  }

  if(missing(config)) {
    config <- get_config(args)
  } else if(length(args) > 0) {
    config <- utils::modifyList(config, args)
  }

  sqlite <- DBI::dbConnect(RSQLite::SQLite(), paste0("~/.oncore2/oncore_", Sys.Date(), ".sqlite"))

  if(overwrite) {
    try(DBI::dbRemoveTable(sqlite, table), silent = TRUE)
  }

  if(!table %in% DBI::dbListTables(sqlite)) {
    start_time = Sys.time()
    rpt("Pulling ", table, " from oncore")
    buildSQLiteOncoreTable(sqlite, table, config)
    d <- Sys.time() - start_time
    rpt("Transfer Complete: ", round(d, 2), attr(d, 'units'))
    # start_time = Sys.time()
    # if(nrow(df) > 0) {
    #   indexes <- index_fields[index_fields %in% colnames(df)]
    #   rpt("Saving ", table, " to sqlite with ", paste(indexes, collapse = ", "), " as indexes.")
    #   dplyr::copy_to(
    #     sqlite,
    #     dplyr::as_tibble(df),
    #     table,
    #     overwrite = overwrite,
    #     temporary = FALSE,
    #     indexes = as.list(indexes)
    #   )
    #   d <- Sys.time() - start_time
    #   rpt("Upload Complete: ", round(d, 2), attr(d, 'units'))
    # }
  } else {
    rpt(table, " already exists in current oncore clone...")
  }

  DBI::dbDisconnect(sqlite)
  return(invisible(TRUE))

}

add_sqlite_annotations <- function(queryObject) {

  spec_ans <- queryObject$selects$COLUMN_NAME[queryObject$selects$TABLE_NAME == "NSSV_BSM_SPECIMEN_ANNOTATIONS"]
  # sqlite <- DBI::dbConnect(odbc::odbc(), Driver = "postgresql", Server = "localhost",
  #                          Port = "5432", Database = "oncore", UID = "eric", PWD = "testing")
  sqlite <- DBI::dbConnect(RSQLite::SQLite(), paste0("~/.oncore2/oncore_", Sys.Date(), ".sqlite"))

  l <- DBI::dbListTables(sqlite)

  if("NSSV_BSM_SPECIMEN_ANNOTATIONS" %in% l) {
    existing_ans <- colnames(DBI::dbGetQuery(sqlite, 'SELECT * FROM "NSSV_BSM_SPECIMEN_ANNOTATIONS" LIMIT 1'))
    spec_ans <- spec_ans[!spec_ans %in% existing_ans]
  }
  if(length(spec_ans) > 0) {
    rpt("Loading ", length(spec_ans) ," specimen annotations into SQLite clone...")
    spec_ans <- paste0("'", paste(spec_ans, collapse = "','"), "'")
    san <- query_oncore(glue::glue("SELECT PCS_SPECIMEN_ID, COLUMN_DISPLAY_NAME, VALUE FROM IUCTSI_ONCORE_PROD.NSSV_BSM_SPECIMEN_ANNOTATIONS WHERE COLUMN_DISPLAY_NAME IN ({ spec_ans })"))
    san <- tidyr::pivot_wider(
      san,
      id_cols = PCS_SPECIMEN_ID,
      names_from = COLUMN_DISPLAY_NAME,
      values_from = VALUE,
      values_fn = function(x) {paste(x, collapse = "|")}
    )

    if(!"NSSV_BSM_SPECIMEN_ANNOTATIONS" %in% DBI::dbListTables(sqlite)) {
      ans <- san
    } else {
      dban <- dplyr::tbl(sqlite, "NSSV_BSM_SPECIMEN_ANNOTATIONS")
      #ans <- dplyr::full_join(dban, san, by = "PCS_SPECIMEN_ID", copy = TRUE)
      ans <- dplyr::as_tibble(dplyr::union(
        dplyr::left_join(dban, san, by = "PCS_SPECIMEN_ID", copy = TRUE),
        dplyr::left_join(san, dban, by = "PCS_SPECIMEN_ID", copy = TRUE),
        copy = TRUE
      ))
    }

    if("NSSV_BSM_SPECIMEN_ANNOTATIONS" %in% l) {
      DBI::dbRemoveTable(sqlite, "NSSV_BSM_SPECIMEN_ANNOTATIONS")
    }

    dplyr::copy_to(
      sqlite,
      ans,
      "NSSV_BSM_SPECIMEN_ANNOTATIONS",
      temporary = FALSE#,
#      indexes = list("PCS_SPECIMEN_ID")
    )
  }

  case_ans <- queryObject$selects$COLUMN_NAME[queryObject$selects$TABLE_NAME == "SV_BSM_CASE_ANNOTATIONS"]

  if("SV_BSM_CASE_ANNOTATIONS" %in% l) {
    existing_ans <- colnames(DBI::dbGetQuery(sqlite, 'SELECT * FROM "SV_BSM_CASE_ANNOTATIONS" LIMIT 1'))
    case_ans <- case_ans[!case_ans %in% existing_ans]
  }
  if(length(case_ans) > 0) {
    rpt("Loading ", length(case_ans) ," case annotations into SQLite clone...")
    case_ans <- paste0("'", paste(case_ans, collapse = "','"), "'")
    can <- query_oncore(glue::glue("SELECT PCS_CASE_ID, COLUMN_DISPLAY_NAME, VALUE FROM IUCTSI_ONCORE_PROD.SV_BSM_CASE_ANNOTATIONS WHERE COLUMN_DISPLAY_NAME IN ({ case_ans })"))
    can <- can[!is.na(can$VALUE), ]
    can <- tidyr::pivot_wider(
      can,
      id_cols = PCS_CASE_ID,
      names_from = COLUMN_DISPLAY_NAME,
      values_from = VALUE,
      values_fn = function(x) {paste(x, collapse = "|")}
    )

    if(!"SV_BSM_CASE_ANNOTATIONS" %in% DBI::dbListTables(sqlite)) {
      ans <- can
    } else {
      dban <- dplyr::tbl(sqlite, "SV_BSM_CASE_ANNOTATIONS")
      # ans <- dplyr::full_join(dban, can, by = "PCS_CASE_ID", copy=TRUE)
      ans <- dplyr::as_tibble(dplyr::union(
        dplyr::left_join(dban, can, by = "PCS_CASE_ID", copy = TRUE),
        dplyr::left_join(can, dban, by = "PCS_CASE_ID", copy = TRUE),
        copy = TRUE
      ))
    }

    if("SV_BSM_CASE_ANNOTATIONS" %in% l) {
      DBI::dbRemoveTable(sqlite, "SV_BSM_CASE_ANNOTATIONS")
    }

    dplyr::copy_to(
      sqlite,
      ans,
      "SV_BSM_CASE_ANNOTATIONS",
      temporary = FALSE,
      indexes = list("PCS_CASE_ID")
    )
  }

  return(TRUE)


}
