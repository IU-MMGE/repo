add_sqlite_table <- function(table, config, overwrite = FALSE) {

  index_fields <- c(
    "PCS_SPECIMEN_ID",
    "SPECIMEN_NO",
    "SPECIMEN_BAR_CODE",
    "PCS_CASE_ID",
    "CASE_NO",
    "PROTOCOL_SUBJECT_ID",
    "PATIENT_ID",
    "PROTOCOL_ID",
    "PROTOCOL_NO"
  )

  # sqlite <- DBI::dbConnect(odbc::odbc(), Driver = "postgresql", Server = "localhost",
  #           Port = "5432", Database = "oncore", UID = "eric", PWD = "testing", MaxVarchar=20000)
  sqlite <- DBI::dbConnect(RSQLite::SQLite(), paste0("~/.oncore2/oncore_", Sys.Date(), ".sqlite"))

  if(!table %in% DBI::dbListTables(sqlite) || overwrite == TRUE) {
    start_time = Sys.time()
    rpt("Pulling ", table, " from oncore")
    conf <- config
    conf$source = "oncore"
    df <- oncore2::query_oncore(glue::glue("SELECT * FROM {{schema}}.{table}"), config = conf)
    d <- Sys.time() - start_time
    rpt("Pull Complete: ", round(d, 2), attr(d, 'units'))
    start_time = Sys.time()
    if(nrow(df) > 0) {
      indexes <- index_fields[index_fields %in% colnames(df)]
      rpt("Saving ", table, " to sqlite with ", paste(indexes, collapse = ", "), " as indexes.")
      dplyr::copy_to(
        sqlite,
        dplyr::as_tibble(df),
        table,
        overwrite = overwrite,
        temporary = FALSE,
        indexes = as.list(indexes)
      )
      d <- Sys.time() - start_time
      rpt("Upload Complete: ", round(d, 2), attr(d, 'units'))
    }
  } else {
    rpt(table, " already exists in current oncore clone...")
  }

  DBI::dbDisconnect(sqlite)

}

add_sqlite_annotations <- function(queryObject) {

  spec_ans <- queryObject$selects$COLUMN_NAME[queryObject$selects$TABLE_NAME == "NSSV_BSM_SPECIMEN_ANNOTATIONS"]
  # sqlite <- DBI::dbConnect(odbc::odbc(), Driver = "postgresql", Server = "localhost",
  #                          Port = "5432", Database = "oncore", UID = "eric", PWD = "testing")
  sqlite <- DBI::dbConnect(RSQLite::SQLite(), paste0("~/.oncore2/oncore_", Sys.Date(), ".sqlite"))

  l <- DBI::dbListTables(sqlite)

  if("NSSV_BSM_SPECIMEN_ANNOTATIONS" %in% l) {
    existing_ans <- colnames(DBI::dbGetQuery(sqlite, 'SELECT * FROM "NSSV_BSM_SPECIMEN_ANNOTATIONS" LIMIT 1'))
    spec_ans <- spec_ans[!spec_ans %in% existing_ans]
  }
  if(length(spec_ans) > 0) {
    spec_ans <- paste0("'", paste(spec_ans, collapse = "','"), "'")
    san <- query_oncore(glue::glue("SELECT PCS_SPECIMEN_ID, COLUMN_DISPLAY_NAME, VALUE FROM IUCTSI_ONCORE_PROD.NSSV_BSM_SPECIMEN_ANNOTATIONS WHERE COLUMN_DISPLAY_NAME IN ({ spec_ans })"))
    san <- tidyr::pivot_wider(
      san,
      id_cols = PCS_SPECIMEN_ID,
      names_from = COLUMN_DISPLAY_NAME,
      values_from = VALUE,
      values_fn = function(x) {paste(x, collapse = "|")}
    )

    if(!"NSSV_BSM_SPECIMEN_ANNOTATIONS" %in% DBI::dbListTables(sqlite)) {
      ans <- san
    } else {
      dban <- dplyr::tbl(sqlite, "NSSV_BSM_SPECIMEN_ANNOTATIONS")
      #ans <- dplyr::full_join(dban, san, by = "PCS_SPECIMEN_ID", copy = TRUE)
      ans <- dplyr::as_tibble(dplyr::union(
        dplyr::left_join(dban, san, by = "PCS_SPECIMEN_ID", copy = TRUE),
        dplyr::left_join(san, dban, by = "PCS_SPECIMEN_ID", copy = TRUE),
        copy = TRUE
      ))
    }

    if("NSSV_BSM_SPECIMEN_ANNOTATIONS" %in% l) {
      DBI::dbRemoveTable(sqlite, "NSSV_BSM_SPECIMEN_ANNOTATIONS")
    }

    dplyr::copy_to(
      sqlite,
      ans,
      "NSSV_BSM_SPECIMEN_ANNOTATIONS",
      temporary = FALSE#,
#      indexes = list("PCS_SPECIMEN_ID")
    )
  }

  case_ans <- queryObject$selects$COLUMN_NAME[queryObject$selects$TABLE_NAME == "SV_BSM_CASE_ANNOTATIONS"]

  if("SV_BSM_CASE_ANNOTATIONS" %in% l) {
    existing_ans <- colnames(DBI::dbGetQuery(sqlite, 'SELECT * FROM "SV_BSM_CASE_ANNOTATIONS" LIMIT 1'))
    case_ans <- case_ans[!case_ans %in% existing_ans]
  }
  if(length(case_ans)) {
    case_ans <- paste0("'", paste(case_ans, collapse = "','"), "'")
    can <- query_oncore(glue::glue("SELECT PCS_CASE_ID, COLUMN_DISPLAY_NAME, VALUE FROM IUCTSI_ONCORE_PROD.SV_BSM_CASE_ANNOTATIONS WHERE COLUMN_DISPLAY_NAME IN ({ case_ans })"))
    can <- can[!is.na(can$VALUE), ]
    can <- tidyr::pivot_wider(
      can,
      id_cols = PCS_CASE_ID,
      names_from = COLUMN_DISPLAY_NAME,
      values_from = VALUE,
      values_fn = function(x) {paste(x, collapse = "|")}
    )

    if(!"SV_BSM_CASE_ANNOTATIONS" %in% DBI::dbListTables(sqlite)) {
      ans <- can
    } else {
      dban <- dplyr::tbl(sqlite, "SV_BSM_CASE_ANNOTATIONS")
      # ans <- dplyr::full_join(dban, can, by = "PCS_CASE_ID", copy=TRUE)
      ans <- dplyr::as_tibble(dplyr::union(
        dplyr::left_join(dban, can, by = "PCS_CASE_ID", copy = TRUE),
        dplyr::left_join(can, dban, by = "PCS_CASE_ID", copy = TRUE),
        copy = TRUE
      ))
    }

    if("SV_BSM_CASE_ANNOTATIONS" %in% l) {
      DBI::dbRemoveTable(sqlite, "SV_BSM_CASE_ANNOTATIONS")
    }

    dplyr::copy_to(
      sqlite,
      ans,
      "SV_BSM_CASE_ANNOTATIONS",
      temporary = FALSE,
      indexes = list("PCS_CASE_ID")
    )
  }

  return(TRUE)


}
