find_tables_by_fields <- function(..., exact = FALSE, ignore.case = TRUE, fixed = TRUE) {

  fields <- list(...)

  tables <- queryOncore("SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, OWNER FROM ALL_TAB_COLUMNS WHERE OWNER = 'ONCORE'")
  tables <- tables[!grepl("CDI", tables$TABLE_NAME), ]

  matched_tables <- lapply(fields, function(x) {

    if(exact == FALSE) {
      y <- suppressWarnings(tables[grepl(x, tables$COLUMN_NAME, ignore.case = ignore.case, fixed = fixed), ])
    } else {
      y <- tables[tables$COLUMN_NAME == x, ]
    }

    return(y)

  })

  z <- matched_tables[[1]]$TABLE_NAME

  for(i in seq(2, length(matched_tables))) {
    z <- intersect(z, matched_tables[[i]]$TABLE_NAME)
  }

  op <- tables[tables$TABLE_NAME %in% z, ]

  return(op)

}


