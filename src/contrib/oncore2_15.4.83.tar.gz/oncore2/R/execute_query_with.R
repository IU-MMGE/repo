#'execute_query
#'
#'Excutes a query based on the supplied \code{oncoreQuery} object
#'
#'\code{execute_query} accepts only one arguement, \code{queryObject} which
#'should be an object of class \code{oncoreQuery}. If the \code{queryObject} is
#'an object of the class \code{oncoreQuery} then \code{execute_query} will
#'connect to oncore using the credentials provided to
#'the initial \code{connect_oncore} function, build an sql statement based on
#'the arguments provided to \code{select_fields}, \code{select_annotations}, and
#'\code{filter_oncore}, and execute that query. It will then disconnect from
#'oncore and return the result as a data.frame.
#'
#'The resulting data.frame will have an attribute called \code{queryObject} that
#'contains the original \code{oncoreQuery} object used to produce the data.frame
#'and an attribute \code{sql} that contains the sql statement sent to oncore.
#'
#'@param queryObject Must be a \code{oncoreQuery} object
#'@param execute Should the query be executed--if FALSE then the SQL statement is returned
#'@param mung Should column names be cleaned up
#'@param recode Should all of the coded columns be recoded
#'@param async Should the query be run asynchronously
#'@param output_name If asyn=TRUE, what should the return values name be?
#'
#'@export
# execute_query_with <- function(queryObject, output_name = "query", execute = NULL,
#                           mung = NULL, recode = NULL, reload = NULL, async = NULL,
#                           return_df = NULL) {
#
#   checkOncoreObject(queryObject)
#
#   args <- get_args(environment())
#   args <- args[names(args) != "queryObject"]
#
#   queryObject <- utils::modifyList(queryObject, args)
#
#   if(any(queryObject$joins %in% oncore2_settings$protocol_joins)) {
#     queryObject$joins <- unique(c(queryObject$joins, "SV_BSM_CASE", "SV_PROTOCOL"))
#   }
#
#   selects <- writeSelects(queryObject)
#   annotations <- writeAnnotations(queryObject)
#   joins <- writeJoins(queryObject)
#   if(!is.null(annotations)) {
#     joins <- paste0(joins, annotations)
#   }
#   filters <- writeFilters(queryObject)
#
#   if(queryObject$distinct) {
#     sql <- "SELECT DISTINCT"
#   } else {
#     sql <- "SELECT"
#   }
#
#   sql <- paste(sql, selects, "\nFROM", joins)
#   if(!is.null(queryObject$conditions)) {
#     sql <- paste(sql, "\nWHERE\n\t", paste0(queryObject$conditions, collapse = " AND\n\t"))
#   }
#
#   queryObject$sql <- sql
#   queryObject$sha <- openssl::sha224(sql)
#   queryObject$date <- format(Sys.Date(), "%Y%m%d")
#   queryObject$file <- glue::glue("~/.oncore2/queries/{sha}_{date}.rda", .envir = queryObject)
#
#   if(queryObject$execute == FALSE) {
#     rpt("Returning SQL statement...\nAll tasks complete...")
#   } else if(!queryObject$async) {
#     rpt("SQL statement built, attempting to query OnCore")
#     queryObject$query <- query_oncore(sql, config = queryObject)
#     queryObject <- clean_query(queryObject)
#   } else if(queryObject$async) {
#     rpt("Initiating asynchronous query...")
#     query_oncore(sql, config = queryObject)
#   }
#
#   if(queryObject$return_df == TRUE & queryObject$async == FALSE) {
#     return(queryObject$query)
#   } else {
#     return(invisible(queryObject))
#   }
#
# }
#
# clean_query <- function(queryObject) {
#   if(queryObject$mung) {
#     rpt("Munging column names...")
#     # Make syntactically valid column names
#     colnames(queryObject$query) <- mung_column_names(colnames(queryObject$query))
#   }
#   if(queryObject$recode) {
#     rpt("Recoding encoded columns...")
#     queryObject <- recodeAllFields(queryObject)
#   }
#   return(invisible(queryObject))
# }
#
# writeSelects <- function(queryObject) {
#
#   if(is.null(queryObject$selects)) {
#     return(NULL)
#   } else {
#
#     # This is ugly hack to get SPECIMEN_STORAGE_LOCATION to work again after the
#     # 'upgrade' to oncore 14.0.
#     qo <- queryObject$selects
#     # qo[qo$COLUMN_NAME == "SPECIMEN_STORAGE_LOCATION", ] <- c("oncore", "GET_STORAGE_LOCATION_TEXT(sv_bsm_specimen.pcs_specimen_id) SPECIMEN_STORAGE_LOCATION")
#
#     selects <- paste(qo$TABLE_NAME,
#                      qo$COLUMN_NAME,
#                      sep = ".")
#
#     if(!is.null(queryObject$annotations)) {
#       anno_selects <- sapply(seq(length(unique(queryObject$annotations$ANNOTATION_TYPE))),
#                                         function(i) {
#                                         paste0("A", i, ".*")
#       })
#       selects <- c(selects, anno_selects)
#     }
#
#     paste(selects, collapse = ",\n\t")
#
#   }
#
# }
#
# writeAnnotations <- function(queryObject) {
#   if(is.null(queryObject$annotations)) {
#     return(NULL)
#   } else {
#
#     anno_info <- list(SPECIMEN = c("SV_BSM_SPECIMEN", "SV_BSM_SPECIMEN_ANNOTATIONS"),
#                             CASE = c("SV_BSM_CASE", "SV_BSM_CASE_ANNOTATIONS"))
#     anno_tables <- split(queryObject$annotations, queryObject$annotations$ANNOTATION_TYPE)
#     anno_joins <- sapply(seq_along(anno_tables), function(i) {
#
#       at <- anno_tables[[i]]
#       tn <- paste0("A", i)
#       al <- anno_info[[at$ANNOTATION_TYPE[1]]]
#       no <- paste0(at$ANNOTATION_TYPE[1], "_NO")
#       annotations <- paste0("'", at$ANNOTATION, "'", collapse = ", ")
#
#       op <- paste0("\n\tFULL OUTER JOIN (SELECT DISTINCT * \n\t\tFROM (SELECT ", no, " AS JOIN_", no, ", COLUMN_DISPLAY_NAME, LISTAGG(VALUE, '|') WITHIN GROUP (ORDER BY VALUE) \"ANNOTATIONS\"
#              FROM ", queryObject$connection$schema, ".", al[2], " WHERE COLUMN_DISPLAY_NAME IN (", annotations,")
#              GROUP BY COLUMN_DISPLAY_NAME, ", no, ")",
#                    "\n\t\tPIVOT (max(ANNOTATIONS) FOR COLUMN_DISPLAY_NAME IN (", annotations,
#                    ")\n\t\t)\n\t\tORDER BY JOIN_", no, ") ", tn, "\n\tON ", tn, ".JOIN_", no, " = ", al[1], ".", no)
#
#       return(op)
#
#     })
#
#     return(paste(anno_joins, collapse = ""))
#
#   }
#
# }
#
# writeJoins <- function(queryObject) {
#
#   writeJoin <- function(table1, table2, field, schema) {
#
#     if(table1 %in% oncore2_settings$protocol_joins) {
#       return(sprintf("\n\tLEFT JOIN %s.%s\n\t\tON %s.SUBJECT_NO = SV_BSM_CASE.SUBJECT_NO AND %s.PROTOCOL_ID = SV_PROTOCOL.PROTOCOL_ID", schema, table1, table1, table1))
#       pid_lookup <- sprintf("(SELECT PROTOCOL_ID FROM %s.SMRS_PROTOCOL WHERE PROTOCOL_NO = '%s')", schema, queryObject$protocol_filter)
#       sub_table <- sprintf("(SELECT * FROM %s.%s WHERE PROTOCOL_ID = %s)", schema, table1, pid_lookup)
#       t1 <- sprintf("(SELECT * FROM %s.%s WHERE REGEXP_LIKE(PROTOCOL_NO, '%s')) %s", schema, table1, queryObject$protocol_filter, table1)
#       field <- c("PROTOCOL_NO", "PROTOCOL_SUBJECT_ID")
#       return(
#         paste0("\n\tLEFT JOIN ",
#                paste(schema, table1, sep = "."),
#                "\n\t\tON ",
#                paste(paste(table2, field, sep = "."), "=", paste(t1, field, sep = "."), collapse = " AND\n")
#       ))
#     } else {
#       return(paste0("\n\tLEFT JOIN ",
#              paste(schema, table1, sep = "."),
#              "\n\t\tON ",
#              paste(table2, field, sep = "."), " = ", paste(table1, field, sep = ".")
#       ))
#     }
#
#     paste0("\n\tLEFT JOIN ",
#            paste(schema, table1, sep = "."),
#            "\n\t\tON ",
#            paste(table2, field, sep = "."), " = ", paste(table1, field, sep = ".")
#     )
#   }
#
#   primaryJoins <- function(primary_joins) {
#     j <- ""
#     for(r in seq(nrow(primary_joins))) {
#       for(c in seq(2, ncol(primary_joins))) {
#         if(colnames(primary_joins)[c] != primary_joins$TABLE_NAME[r] & primary_joins[r, c] == TRUE) {
#           j <- paste(j, writeJoin(colnames(primary_joins)[c], primary_joins$TABLE_NAME[r], oncore2_settings$primary_views[colnames(primary_joins)[c]], queryObject$connection$schema), sep = "\n")
#         }
#       }
#     }
#     return(j)
#   }
#
#   secondaryJoins <- function(joins) {
#     paste(sapply(seq(nrow(joins)), function(i) {
#       x <- min(match(TRUE, joins[i, ]))
#       writeJoin(joins$TABLE_NAME[i], colnames(joins)[x], oncore2_settings$primary_views[colnames(joins)[x]], queryObject$connection$schema)
#     }), collapse = "")
#   }
#
#   joins <- queryObject$joins
#   pv_count <- sum(names(oncore2_settings$primary_views) %in% joins)
#   if(pv_count > 1) {
#     joins <- unique(c(joins, "SV_BSM_CASE"))
#   }
#
#   jdf <- field_list()[field_list()$TABLE_NAME %in% joins,]
#   for(i in seq_along(oncore2_settings$primary_views)) {
#     if(sum(jdf[[names(oncore2_settings$primary_views)[i]]][jdf$TYPE != "primary_view"]) > 0) {
#       joins <- unique(c(joins, names(oncore2_settings$primary_views)[i]))
#     }
#   }
#   jdf <- field_list()[field_list()$TABLE_NAME %in% joins,]
#   jdf <- jdf[order(jdf$SCORE), ]
#   jdf <- jdf[,  -c(2,3,4)]
#
#   jdf <- unique(jdf)
#   jdf <- jdf[, colnames(jdf) %in% c("TABLE_NAME", jdf$TABLE_NAME, "PROTOCOL_JOIN")]
#
#   join <- paste0(queryObject$connection$schema, ".", jdf$TABLE_NAME[1])
#
#   primary_joins <- jdf[jdf$TABLE_NAME %in% names(oncore2_settings$primary_views), ]
#   if(nrow(primary_joins) > 0) {
#     primary_joins <- primaryJoins(primary_joins)
#   } else {
#     primary_joins <- NULL
#   }
#   joins <- jdf[!jdf$TABLE_NAME %in% names(oncore2_settings$primary_views), ]
#   if(nrow(joins) > 0) {
#     joins <- secondaryJoins(joins)
#   } else {
#     joins <- NULL
#   }
#
#   join <- paste(join, primary_joins, joins)
#
#   return(join)
#
# }
#
# writeFilters <- function(queryObject) {
#
# }
