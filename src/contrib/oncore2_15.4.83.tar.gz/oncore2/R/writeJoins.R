writeJoins <- function(queryObject) {

  selects <- queryObject$selects
  primary_views <- c()
  fl <- field_list()
  specimen_ids <- oncore2_settings$primary_views$SV_BSM_SPECIMEN
  case_ids <- oncore2_settings$primary_views$SV_BSM_CASE
  subject_ids <- oncore2_settings$primary_views$SMRS_PCL_CENT_SUBJECT
  protocol_ids <- oncore2_settings$primary_views$SV_PROTOCOL

  source_names <- unique(c(selects$TABLE_NAME, queryObject$joins))

  sources <- fl %>%
    dplyr::filter(TABLE_NAME %in% source_names) %>%
    dplyr::select(-COLUMN_NAME, -SCORE) %>%
    dplyr::distinct() %>%
    dplyr::mutate(
      table2 = NA,
      jf = NA
    )

  schema <- queryObject$connection$schema
  join <- function(schema, table1, table2, jf) {
    return(glue::glue("\n\n\tLEFT JOIN {schema}.{table1}\n\t\tON {table1}.{jf} = {table2}.{jf}"))
  }

  primary_views <- names(oncore2_settings$primary_views)
  primary_views <- primary_views[primary_views %in% sources$TABLE_NAME]
  secondary_views <- sources$TABLE_NAME[!sources$TABLE_NAME %in% primary_views]

  if(length(secondary_views) > 0) {
    for(sv in secondary_views) {

      f <- fl %>%
        dplyr::filter(TABLE_NAME == sv)

      if(any(specimen_ids %in% f$COLUMN_NAME)) {
        sources$table2[sources$TABLE_NAME == sv] <- "SV_BSM_SPECIMEN"
        sources$jf[sources$TABLE_NAME == sv] <- specimen_ids[specimen_ids %in% f$COLUMN_NAME][1]
      } else if(any(case_ids %in% f$COLUMN_NAME)) {
        sources$table2 <- "SV_BSM_CASE"
        sources$jf[sources$TABLE_NAME == sv] <- case_ids[case_ids %in% f$COLUMN_NAME][1]
      } else if("PROTOCOL_SUBJECT_ID" %in% f$COLUMN_NAME) {
        sources$table2[sources$TABLE_NAME == sv] <- "SMRS_PCL_CENT_SUBJECT"
        sources$jf[sources$TABLE_NAME == sv] <- "PROTOCOL_SUBJECT_ID"
      } else if(any(subject_ids %in% f$COLUMN_NAME)) {
        sources$table2[sources$TABLE_NAME == sv] <- "SMRS_PCL_CENT_SUBJECT"
        sources$jf[sources$TABLE_NAME == sv] <- subject_ids[subject_ids %in% f$COLUMN_NAME][1]
      } else if(any(protocol_ids %in% f$COLUMN_NAME)) {
        sources$table2[sources$TABLE_NAME == sv] <- "SV_PROTOCOL"
        sources$jf[sources$TABLE_NAME == sv] <- protocol_ids[protocol_ids %in% f$COLUMN_NAME][1]
      } else {
        stop("CANNOT JOIN TO ", sources$TABLE_NAME[i])
      }

    }
  }

  primary_views <- unique(c(primary_views, sources$table2))
  primary_views <- primary_views[!is.na(primary_views)]
  pv <- which(names(oncore2_settings$primary_views) %in% primary_views)
  primary_views <- names(oncore2_settings$primary_views)[min(pv):max(pv)]

  joins <- glue::glue("{schema}.{primary_views[1]}")
  if(length(primary_views) > 1) {
    for(i in seq(2, length(primary_views))) {
      jf <- oncore2_settings$primary_views[[primary_views[i]]][1]
      joins <- glue::glue("{joins}{join(schema, primary_views[i], primary_views[i-1], jf)}")
    }
  }

  all_sources = sources
  sources <- sources[!sources$TABLE_NAME %in% names(oncore2_settings$primary_views), ]

  if(nrow(sources) > 0) {
    for(i in seq(nrow(sources))) {

      f <- fl %>%
        dplyr::filter(TABLE_NAME == sources$TABLE_NAME[i])

      if(any(specimen_ids %in% f$COLUMN_NAME)) {
        table2 <- "SV_BSM_SPECIMEN"
        jf <- specimen_ids[specimen_ids %in% f$COLUMN_NAME][1]
      } else if(any(case_ids %in% f$COLUMN_NAME)) {
        table2 <- "SV_BSM_CASE"
        jf <- case_ids[case_ids %in% f$COLUMN_NAME][1]
      } else if("PROTOCOL_SUBJECT_ID" %in% f$COLUMN_NAME) {
        table2 <- "SMRS_PCL_CENT_SUBJECT"
        jf <- "PROTOCOL_SUBJECT_ID"
      } else if(any(subject_ids %in% f$COLUMN_NAME)) {
        table2 <- "SMRS_PCL_CENT_SUBJECT"
        jf <- subject_ids[subject_ids %in% f$COLUMN_NAME][1]
      } else if(any(protocol_ids %in% f$COLUMN_NAME)) {
        table2 <- "SV_PROTOCOL"
        jf <- protocol_ids[protocol_ids %in% f$COLUMN_NAME][1]
      } else {
        stop("CANNOT JOIN TO ", sources$TABLE_NAME[i])
      }

      joins <- glue::glue("{joins}{join(schema, f$TABLE_NAME[1], table2, jf)}")

    }
  }

  queryObject$all_source = all_sources
  queryObject$join_statement = joins

  return(queryObject)

}
