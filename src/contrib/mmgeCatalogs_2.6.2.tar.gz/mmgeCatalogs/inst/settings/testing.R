open = FALSE
debug = TRUE
devtools::load_all()
if(debug) debug(mmgeCatalog$new)
x <- mmgeCatalog$new("MMGE-NIA-NCRAD-ADCFB")
if(open) {
  x$open("config")
  x$open("dictionary")
  x$open("preprocess_oncore")
}
if(debug) base::debug(x$build)
x$build()
base::debug(x$save)
x$save()

devtools::load_all()
dirs <- get_catalog_directories()

x <- process_catalogs(fn = function(protocol, catalog_name, config, dir) {

  settings_file <- file.path("/media", "HG-Data", protocol, "Settings", "settings.yaml")
  settings <- try({yaml::yaml.load_file(settings_file)})
  if(!inherits(settings, 'try-error')) {
    config_file <- file.path(dir, "config.yaml")
    config <- yaml::yaml.load_file(config_file)

    if('subject_ids' %in% names(settings)) {

      if('grouping' %in% names(config$build)) {

        print(settings$subject_ids)

        rstudioapi::navigateToFile(config_file)

        y <- readline("Next...")

      }

    }

  }

})
