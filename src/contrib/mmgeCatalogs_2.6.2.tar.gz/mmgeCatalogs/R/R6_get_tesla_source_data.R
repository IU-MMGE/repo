R6_get_tesla_source_data <- function() {

  db <- debugR::debug("tesla_data")

  tesla_sources <- private$config_obj$build$tesla_sources

  for(i in seq(length(tesla_sources))) {
    source <- tesla_sources[[i]]
    source_name <- names(tesla_sources)[i]
    tesla_con <- DBI::dbConnect(odbc::odbc(), "TESLA", uid = Sys.getenv("tesla_user"), pwd = Sys.getenv("tesla_pass"))
    if("sql" %in% names(source)) {
      sql <- source$sql
    } else if("view" %in% names(source)) {
      sql <- glue::glue("SELECT * FROM {source$db}.dbo.{source$view}")
    } else {
      stop("You must provide view name or a SQL statement to pull data from tesla", call. = FALSE)
    }
    query <- DBI::dbGetQuery(tesla_con, sql)

    if(glue::glue("preprocess_{source_name}") %in% ls(private$build_environment)) {
      tryCatch({
        query <- private$build_environment[[glue::glue("preprocess_{source_name}")]](dplyr::ungroup(query), config, dictionary)
      }, error = function(e) {
        if(rstudioapi::isAvailable()) {
          assign("df", value = dplyr::ungroup(query), pos = .GlobalEnv)
          self$open(glue::glue("preprocess_{source_name}"))
        }
        stop(e)
      })
    }

    query <- dplyr::ungroup(query)

    private$sources[[source_name]] <- query

  }

  return(invisible(self))

}

