R6_recode_data <- function() {

  db <- debugR::debug("recode_data")

  for(field in private$recodes_obj) {
    if(is.null(field$source) || field$source != 'standard_field') {
      recodes <- paste(glue::glue("\"{names(field$recode)}\" = \"{field$recode}\""), collapse = ", ")
      if(private$config_obj$build$ignore_case) {
        field$source_id <- toupper(field$source_id)
      }
      invisible(eval(parse(text = glue::glue('private$sources${field$source}$`{field$source_id}` <- dplyr::recode(private$sources${field$source}$`{field$source_id}`, {recodes})'))))
      w <- 1
    }
  }

  return(invisible(self))

}