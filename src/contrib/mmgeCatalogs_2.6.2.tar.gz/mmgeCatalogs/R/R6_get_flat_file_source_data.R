R6_get_flat_file_source_data <- function(self) {

  db <- debugR::debug('flat_file_sources')

  needed_sources <- unique(c(private$dictionary_obj$source, names(private$config_obj$build$source_joins)))
  needed_sources <- needed_sources[!needed_sources %in% private$reserved_source_types]
  needed_sources <- needed_sources[!grepl("^_", needed_sources)]

  if("tesla_sources" %in% names(private$config_obj$build)) {
    needed_sources <- needed_sources[!needed_sources %in% names(private$config_obj$build$tesla_sources)]
  }
  # source_loc <- c(private$config_obj$build$locations$sources, file.path(self$catalog_dir, "sources"), file.path(self$protocol_dir, "Data"))
  #
  # source_list <- unlist(sapply(source_loc, function(loc) {
  #   list.files(loc, full.names = TRUE, pattern = "\\.(xlsx|xls|csv|tsv)$")
  # }))
  # source_list <- normalizePath(source_list[!grepl("~$", source_list, fixed = TRUE)])
  #
  for(source in needed_sources) {

    # src <- source_list[grepl(paste0(source, "\\.(csv|xlsx|xls|tsv)$"), source_list)]
    #
    # if(length(src) > 1) {
    #   warning("Multiple sources found that match: ", source)
    # }
    #
    # src <- src[1]
    #
    # src <- suppressWarnings(switch(gsub("^.+\\.", "", src),
    #                               "xlsx" = openxlsx::read.xlsx(file.path(src), sheet = 1, check.names = FALSE, sep.names = " "),
    #                               "xls" = openxlsx::read.xlsx(file.path(src), sheet = 1, check.names = FALSE, sep.names = " "),
    #                               "csv" = read.csv(file.path(src), stringsAsFactors = FALSE, check.names = FALSE),
    #                               "tsv" = read.delim(file.path(src), as.is = TRUE, stringsAsFactors = FALSE, check.names = FALSE),
    #                               "R" = run_r_script(src),
    #                               {stop("Unrecognized source format: ", src)}))
    #
    # if(glue::glue("preprocess_{source}") %in% ls(private$build_environment)) {
    #   tryCatch({
    #     src <- private$build_environment[[glue::glue("preprocess_{source}")]](dplyr::ungroup(src), config, dictionary)
    #   }, error = function(e) {
    #     if(rstudioapi::isAvailable()) {
    #       assign("df", value = dplyr::ungroup(src), pos = .GlobalEnv)
    #       self$open(glue::glue("preprocess_{source}"))
    #     }
    #     stop(e)
    #   })
    # }
    #
    # src <- dplyr::ungroup(src)
    #
    # if(any(colnames(src) == "")) {
    #   warning("Fields without names found in `", source, "`. Removing fields.")
    #   src <- src[, colnames(src) != ""]
    # }

    src <- private$open_data_file(source)

    if(glue::glue("preprocess_{source}") %in% ls(private$build_environment)) {
      tryCatch({
        fn <- private$build_environment[[glue::glue("preprocess_{source}")]]
        src <- fn(dplyr::ungroup(src), private$config_obj, private$dictionary_obj)
      }, error = function(e) {
        if(rstudioapi::isAvailable()) {
          self$open(glue::glue("preprocess_{source}"))
        }
        stop(e)
      })
    }

    src <- dplyr::ungroup(src)

    private$sources[[source]] <- src

  }

  return(invisible(self))

}

R6_open_data_file <- function(source) {

  source_loc <- c(private$config_obj$build$locations$sources, file.path(self$catalog_dir, "sources"), file.path(self$protocol_dir, "Data"))

  source_list <- unlist(sapply(source_loc, function(loc) {
    list.files(loc, full.names = TRUE, pattern = "\\.(xlsx|xls|csv|tsv)$")
  }))
  source_list <- normalizePath(source_list[!grepl("~$", source_list, fixed = TRUE)])

  src <- source_list[grepl(paste0(source, "\\.(csv|xlsx|xls|tsv)$"), source_list)]

  if(length(src) > 1) {
    warning("Multiple sources found that match: ", source)
  }

  src <- src[1]

  src <- suppressWarnings(switch(gsub("^.+\\.", "", src),
                                 "xlsx" = openxlsx::read.xlsx(file.path(src), sheet = 1, check.names = FALSE, sep.names = " "),
                                 "xls" = openxlsx::read.xlsx(file.path(src), sheet = 1, check.names = FALSE, sep.names = " "),
                                 "csv" = read.csv(file.path(src), stringsAsFactors = FALSE, check.names = FALSE),
                                 "tsv" = read.delim(file.path(src), as.is = TRUE, stringsAsFactors = FALSE, check.names = FALSE),
                                 "R" = run_r_script(src),
                                 {stop("Unrecognized source format: ", src)}))

  if(any(colnames(src) == "")) {
    warning("Fields without names found in `", source, "`. Removing fields.")
    src <- src[, colnames(src) != ""]
  }

  return(src)

}