context("test-get_protocol_settings.R")

test_that("correctly reads a protocol_file", {
  expect_is(get_protocol_settings("MMGE-MJFF-PPMI-BIO"), "protocol")
  expect_equal(get_protocol_settings("MMGE-MJFF-PPMI-BIO")$protocol, "MMGE-MJFF-PPMI-BIO")
})
