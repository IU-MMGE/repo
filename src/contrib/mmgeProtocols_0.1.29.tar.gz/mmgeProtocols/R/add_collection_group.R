#' add a collection group to a protocol
#'
#' @param collection_group the name of the collection group
#' @param aliquot_size the default aliquot size
#' @param depletion_warning_level depletion warning level
#' @param manifest_fields fields to include in manifest for collection group
#' @param pattern pattern for matching protocol names
#' @param ... additional arguments passed to grepl when matching protocols
#'
#' @return TRUE if successful
#' @export
#'
#' @examples
#'
#' #add 'CSF' collection group to all NCRAD protocols
#' add_collection_group("CSF", aliquot_size = 250,
#'                      depletion_warning_level = 2000,
#'                      manifest_fields = "Hemoglobin Assay",
#'                      pattern = "NCRAD")
#'
add_collection_group <- function(collection_group,
                     aliquot_size = 0,
                     depletion_warning_level = 0,
                     manifest_fields = c("",""),
                     pattern, ...) {

  set_protocol_key(paste0("aliquot_sizes$", collection_group),
                   value = aliquot_size,
                   pattern = pattern,
                   ... = ...,
                   overwrite = FALSE)

  set_protocol_key(paste0("depletion_warning_levels$", collection_group),
                   value = depletion_warning_level,
                   pattern = pattern,
                   ... = ...,
                   overwrite = FALSE)

  set_protocol_key(paste0("manifest$specimen_types$", collection_group),
                   value = manifest_fields,
                   pattern = pattern,
                   ... = ...,
                   overwrite = FALSE)

  return(invisible(TRUE))

}