#' @importFrom magrittr %>%
#' @export
magrittr::`%>%`

cat_line <- function(...) {
  cat(..., "\n", sep = "")
}

get_protocols <- function(pattern, fixed = FALSE, ...) {

  protocols <- list.dirs(get_setting("protocol_dir"), full.names = FALSE, recursive = FALSE)
  protocols <- grep("-", fixed = TRUE, protocols, value = TRUE)

  if(!missing(pattern)) {
    protocols <- grep(pattern, protocols, value = TRUE, ...)
  }

  return(protocols)

}

get_setting <- function(key) {
  x <- yaml::yaml.load_file(system.file("settings/settings.yaml", package = "mmgeProtocols"))[[key]]
  if(is.null(x)) {
    stop("`", key, "` not found in mmgeProtocols settings.", call. = FALSE)
  }
  return(x)
}

#'@export
protocol_path <- function(protocol, subdir) {

  if(!missing(protocol)) {
    if(grepl("MMGE-CTSI-IB-CC",protocol)){
      pp <- file.path(get_setting("protocol_dir"),"MMGE-CTSI-IB-CC",protocol)
    }
    else{
      pp <- file.path(get_setting("protocol_dir"), protocol)
    }
    if(!missing(subdir)) {
      pp <- file.path(pp, subdir)
      if(!dir.exists(pp)) {
        stop("'", subdir, "' subdirectory does not exist in '", protocol, "' directory.", call. = FALSE)
      }
    }
  } else {
    pp <- get_setting("protocol_dir")
  }

  return(pp)

}

#'@export
check_protocol <- function(protocol) {
  if(missing(protocol)) {
    protocol <- get_default_protocol()
    if(is.na(protocol)) {
      stop("You must pass a protocol name to this function or set a default protocol with `set_default_protocol()`", call. = FALSE)
    }
  }

  if(!protocol %in% get_protocols()) {
    m <- agrep(protocol, x = get_protocols(), value = TRUE)
    if(length(m) > 0) {
      stop("'", protocol, "' is not a valid protocol. Did you mean '", m[1], "'?")
    } else {
      stop("'", protocol, "' is not a valid protocol.")
    }
  }

  return(protocol)

}

#'@export
set_default_protocol <- function(protocol) {
  if(protocol_exists(protocol)) {
    options(mmgeProtocols_protocol = protocol)
    cat_line(crayon::green(clisymbols::symbol$star, "Setting default protocol to", protocol, "\b..."))
  } else {
    cat_line(crayon::red(clisymbols::symbol$cross, protocol, "didn't match any known protocols..."))
  }
}

#'@export
unset_default_protocol <- function() {
  options(mmgeProtocols_protocol = NULL)
}

get_default_protocol <- function() {
  x <- unname(unlist(options("mmgeProtocols_protocol")))
  if(is.null(x)) {
    x <- NA
  }
  return(x)
}