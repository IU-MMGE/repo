#'@export
build_pullsheet_wb <- function(..., pull, aliquot, extract, box_design,
                                    check_depletion_levels=T, summary_sheet = T,
                                    dir = ".",box_sheet=T,position=F,
                                    ref_pool_exclude = c(9999999),multiple_per_visit=F,box_size=NULL,number_of_children = 1,
                                    visit_type = "VISIT",query) {
  extra_sheets <- list(...)

  if(!missing(pull)) {
    pull <- dplyr::ungroup(pull)
  }
  if(!missing(aliquot)) {
    aliquot <- dplyr::ungroup(aliquot)
  }
  if(!missing(extract)) {
    extract <- dplyr::ungroup(extract)
  }

  config = get_pullsheet_config(dir)

  if(missing(check_depletion_levels)) {
    check_depletion_levels <- config$check_depletion_levels
  }

  extra_fields <- config$extra_fields
  if(!missing(box_design)) {
    extra_fields <- unique(c(extra_fields, config$balance_vars))
  }

  if(!missing(pull)) {
    if(nrow(pull) > 0) {
      pull <- pull %>%
        select_pullsheet_fields(.dots = extra_fields, dir = dir, box_name = "Pull",box_size = box_size)
    } else {
      pull <- NULL
    }
  } else {
    pull <- NULL
  }

  if(!missing(aliquot)) {
    aliquot_test = split_aliquots(aliquot,number_of_children)
    aliquot_test = create_aliquot_cols(aliquot_test,number_of_children,"Aliquot",box_size = box_size)
    aliquot = create_aliquot_cols(aliquot,number_of_children,"Aliquot",box_size = box_size)

  }
  else {
    aliquot <- NULL
    aliquot_test = NULL
  }

  if(!missing(extract)) {
    extract = create_aliquot_cols(extract,number_of_children,"Extract",box_size = box_size)
    extract_test = split_aliquots(extract,number_of_children)
    extract_test = create_aliquot_cols(extract_test,number_of_children,"Extract",box_size = box_size)
  } else {
    extract <- NULL
    extract_test = NULL
  }

  if(!missing(box_design)) {
    summary_box <- tidy_box(pull,aliquot = aliquot_test,extract = extract_test,box_design,subject = config$subject_ids$blinded,
                            visit_type,position,multiple_per_visit,ref_pool_exclude,box_size = box_size)

    summary_cols <- unique(c("SPECIMEN_BAR_CODE", "PATIENT_ID","ALTERNATE_MRN","SUBJECT_LAST_NAME",config$subject_ids$blinded, "VISIT",
                             "COLLECTION_GROUP", "SPECIMEN_QUANTITY", "TEMP_BOX_NO", "TEMP_BOX_POSITION",
                             "FINAL_RUN_NO", "FINAL_RUN_POSITION", "HEMOGLOBIN_ASSAY","FINAL_BOX_NO","FINAL_BOX_POSITION"))
    summary_cols <- summary_cols[summary_cols %in% colnames(summary_box)]
    box <- summary_box %>%
      dplyr::select_(.dots = summary_cols) %>%
      dplyr::mutate(SCANNED_BAR_CODE = NA)

    bingo <- box %>%
      arrange(TEMP_BOX_NO,TEMP_BOX_POSITION)

    from_children_box <- which(grepl("^[Aliquot|Extract]", box$TEMP_BOX_NO))
    from_children_bingo <- which(grepl("^[Aliquot|Extract]", bingo$TEMP_BOX_NO))
    from_children_style <- openxlsx::createStyle(border = "TopBottomLeftRight", borderColour = "#f1da2c", borderStyle = "medium")
    pull <- add_final_box_positions(pull, summary_box)
  }

  wb <- openxlsx::createWorkbook()
  if(!is.null(pull)){
    pull = pull%>%ungroup()%>%select(-TEMP_BOX_NO,-TEMP_BOX_POSITION)
  }
  if(!is.null(aliquot)){
    aliquot = aliquot%>%ungroup()%>%select(-TEMP_BOX_NO,-TEMP_BOX_POSITION)
  }
  if(!is.null(extract)){
    extract = extract%>%ungroup()%>%select(-TEMP_BOX_NO,-TEMP_BOX_POSITION)
  }
  mmgeDistributions:::addWorksheet(wb, "Pull", pull, tabColour = "#33cc33", pullsheet = TRUE)
  mmgeDistributions:::addWorksheet(wb, "Aliquot", aliquot, tabColour = "#f1da2c", pullsheet = TRUE)
  mmgeDistributions:::addWorksheet(wb, "Extract", extract, tabColour = "#FF9900", pullsheet = TRUE)




  if(!missing(box_design)) {
    mmgeDistributions:::addWorksheet(wb, "Bingo", bingo, tabColour = "#6600cc")
    mmgeDistributions:::addWorksheet(wb, "Box", box, tabColour = "#0066cc")
    openxlsx::addStyle(wb, "Box", rows = from_children_box+1, cols = 1, style = from_children_style, stack = TRUE)
    openxlsx::addStyle(wb, "Bingo", rows = from_children_bingo+1, cols = 1, style = from_children_style, stack = TRUE)
    row_track = c()
    letter_track=3
    p=1
    for(r in from_children_box) {
      if(grepl("^Aliquot", box$TEMP_BOX_NO[r])) {
        s = aliquot
        sn = "Aliquot"
      } else {
        s = extract
        sn = "Extract"
      }
      box_row <- which(s$SPECIMEN_BAR_CODE == box$SPECIMEN_BAR_CODE[r])+1
      row_track[r]=box_row
      if(r>1){
        if(box_row==row_track[r-1]){
          letter_track=letter_track+1
        }
      }
      if(letter_track>(number_of_children+2)){
        letter_track = 3
      }
      letter = chartr("123456789","ABCDEFGHI",letter_track)

      q = which(bingo$SPECIMEN_BAR_CODE==box$SPECIMEN_BAR_CODE[r])

      openxlsx::writeFormula(wb, "Box", startCol = 1, startRow = r+1, x = paste0(sn,"!$",letter,"$", box_row))
      openxlsx::writeFormula(wb, "Bingo", startCol = 1, startRow = q[p]+1, x = paste0(sn,"!$",letter,"$", box_row))
      p = p+1
      if(p>number_of_children){
        p=1
        letter_track = 3
      }
    }

    mmgeDistributions:::addWorksheet(wb, "Box_Design", box_design)
    add_scanned_barcode(wb,"Box",box,box=T)
    add_scanned_barcode(wb,"Bingo",bingo,box=T)
    build_summary_sheets(wb, summary_box, dir = dir,multiple_per_visit=multiple_per_visit)

  }

  if(missing(box_design)&box_sheet==T){
    summary_box = create_box_sheet(pull,aliquot_test,extract_test,subject = config$subject_ids$blinded,box_size = box_size)
    summary_cols <- c("SPECIMEN_BAR_CODE", config$subject_ids$blinded, "VISIT",
                      "COLLECTION_GROUP", "SPECIMEN_QUANTITY", "TEMP_BOX_NO", "TEMP_BOX_POSITION",
                      "FINAL_RUN_NO", "FINAL_RUN_POSITION", "HEMOGLOBIN_ASSAY","FINAL_BOX_NO","FINAL_BOX_POSITION")
    summary_cols <- summary_cols[summary_cols %in% colnames(summary_box)]
    box <- summary_box %>%
      dplyr::select_(.dots = summary_cols) %>%
      dplyr::mutate(SCANNED_BAR_CODE = NA)%>%
      dplyr::mutate(TEMP_BOX_NO=NA)%>%
      dplyr::mutate(TEMP_BOX_POSITION=NA)

    from_children_box <- which(grepl("^[Aliquot|Extract]", box$TEMP_BOX_NO))
    from_children_style <- openxlsx::createStyle(border = "TopBottomLeftRight", borderColour = "#f1da2c", borderStyle = "medium")

    pull <- add_final_box_positions(pull, summary_box)

    mmgeDistributions:::addWorksheet(wb, "Box", box, tabColour = "#0066cc")
    openxlsx::addStyle(wb, "Box", rows = from_children_box+1, cols = 1, style = from_children_style, stack = TRUE)
    row_track = c()
    letter_track=3
    for(r in from_children_box) {
      if(grepl("^Aliquot", box$TEMP_BOX_NO[r])) {
        s = aliquot
        sn = "Aliquot"
      } else {
        s = extract
        sn = "Extract"
      }
      box_row <- which(s$SPECIMEN_BAR_CODE == box$SPECIMEN_BAR_CODE[r])+1
      row_track[r]=box_row
      if(r>1){
        if(box_row==row_track[r-1]){
          letter_track=letter_track+1
        }
      }
      if(letter_track>(number_of_children+2)){
        letter_track = 3
      }
      letter = chartr("123456789","ABCDEFGHI",letter_track)
      openxlsx::writeFormula(wb, "Box", startCol = 1, startRow = r+1, x = paste0(sn,"!$",letter,"$", box_row))
    }
    add_scanned_barcode(wb,"Box",box,box=T)
  }

  if(check_depletion_levels) {
    dc = query%>%
      semi_join(rbind(pull,aliquot,extract),by=c("CASE_NO","COLLECTION_GROUP"))%>%
      filter(SPECIMEN_STATUS=="Available"&!is.na(SPECIMEN_QUANTITY))%>%
      group_by(CASE_NO,COLLECTION_GROUP)%>%
      mutate(TOTAL_VOLUME = sum(SPECIMEN_QUANTITY))%>%
      select(PATIENT_ID,SUBJECT_LAST_NAME,ALTERNATE_MRN,CASE_NO,TOTAL_VOLUME)%>%
      filter(row_number()==1)%>%
      arrange(TOTAL_VOLUME)
    mmgeDistributions:::addWorksheet(wb, "Depletion_Check", data = dc)
  }

  if(length(extra_sheets) > 0) {
    for(i in seq(length(extra_sheets))) {
      mmgeDistributions:::addWorksheet(wb, names(extra_sheets)[i], extra_sheets[[i]])
    }
  }

  if(summary_sheet == T){
    mmgeDistributions:::addWorksheet(wb,"Summary",mmgeDistributions:::summarysheet(pull=pull,aliquot=aliquot,extract=extract))
  }

  wb = inventory_sheet(wb,pull,aliquot,extract)

  return(invisible(wb))

}