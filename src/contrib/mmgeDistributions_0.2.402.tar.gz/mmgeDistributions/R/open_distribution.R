#' #'@export
#' open_distribution <- function(fp_id) {
#'
#'   for(p in list.dirs(get_order_dir(), full.names = TRUE, recursive = FALSE)) {
#'
#'     project <- grep(paste0("_", fp_id, "$"), list.dirs(p, full.names = TRUE, recursive = FALSE), value = TRUE)
#'
#'     if(length(project) > 0) {
#'
#'       rstudioapi::openProject(file.path(project, "R"), newSession = TRUE)
#'       return(invisible(TRUE))
#'
#'     }
#'
#'   }
#'
#'   message("Could not find a distribution with fp_id ", fp_id, ".")
#'   return(invisible(FALSE))
#'
#' }
