#'Remove Warming Event Samples
#'
#'Removes samples involved in Corriell's 'warming event.' Intended to be piped
#'into a pullsheet workflow
#'
#'@param query The returned query
#'
#'@export
remove_warming_event <- function(query) {
  filter(query, !grepl("warming event", SPECIMEN_COMMENTS))
}

#'Remove non-existent samples
#'
#'Remove samples that are marked destroyed with a reason of 'Extra Label' or
#''Not Filled'. Meant to be part of a piped pullsheet workflow.
#'
#'@param query The returned query
#'
#'@export
remove_destroyed_samples <- function(query) {
  if("REASON_DESTROYED" %in% colnames(query)) {
    query <- filter(query, !(SPECIMEN_STATUS == "Destroyed" & REASON_DESTROYED %in% c("Not Filled", "Extra Label")))
  } else {
    warning("`REASON_DESTROYED` not in dataset. `remove_destroyed_samples` returned original data.")
  }
  return(query)
}

#'Remove New Specimens
#'
#'Remove New Specimens from the OnCore query
#'
#'@param query The returned query
#'
#'@export
not_new <- function(query) {
  filter(query, SPECIMEN_STATUS != "New")
}

#'Get PPMI Mutrslt
#'
#'Pull the PPMI mutation data from LONI for incorporation into a pullsheet. Meant
#'to be part of a piped pullsheet workflow.
#'
#'@param query The returned query
#'
#'@export
join_ppmi_mutrslt <- function(query) {

  mutrslt <- get_ppmi_mutrslt()

  return(left_join(df, mutrslt, by = c("SUBJECT_LAST_NAME" = "PATNO")))

}

#'@export
subset_dataframe <- function(df1, df2, by) {

  df1 %>%
    semi_join(df2, by = by) %>%
    left_join(df2, by = by)

}

#'@export
select_distributable_aliquots <- function(df, dir = ".") {

  config <- get_pullsheet_config(dir)

  aliquot_sizes <- config$aliquot_sizes
  COLLECTION_GROUP = config$collection_group

  df <- df %>%
    dplyr::filter(SPECIMEN_QUANTITY == aliquot_sizes[COLLECTION_GROUP])

}

#'@export
select_parent_aliquots <- function(df, dir = ".") {

  config <- get_pullsheet_config(dir)

  aliquot_sizes <- config$aliquot_sizes
  COLLECTION_GROUP = config$collection_group

  df <- df %>%
    dplyr::filter(SPECIMEN_QUANTITY > aliquot_sizes[COLLECTION_GROUP]) %>%
    dplyr::group_by_(.dots = c(config$subject_ids$blinded, "VISIT", "COLLECTION_GROUP")) %>%
    dplyr::arrange(FREEZE_._THAW_CYCLE, desc(SPECIMEN_COMMENTS), desc(SPECIMEN_QUANTITY)) %>%
    dplyr::filter(SPECIMEN_QUANTITY == max(SPECIMEN_QUANTITY))

  return(df)

}

#'@export
remove_pullable <- function(df, pull, dir = ".") {

  config <- get_pullsheet_config(dir)

  df <- df %>%
    dplyr::anti_join(pull, by = c(config$subject_ids$blinded, "VISIT", "COLLECTION_GROUP"))


}

#'@export
select_aliquots <- function(df, n = 1, dir = ".") {

  config <- get_pullsheet_config(dir)

  df %>%
    dplyr::group_by_(.dots = c(config$subject_ids$blinded, "VISIT", "COLLECTION_GROUP")) %>%
    dplyr::arrange(dplyr::desc(FREEZE_._THAW_CYCLE), SPECIMEN_COMMENTS) %>%
    dplyr::filter(row_number() <= n) %>%
    dplyr::ungroup()

}