#'@export
build_summary_sheets <- function(wb, box, dir = ".",multiple_per_visit=multiple_per_visit) {

  config <- get_pullsheet_config(dir)

  for(i in seq(length(config$balance_vars))) {
    if(multiple_per_visit==T){
      box = box%>%
        ungroup()%>%
        group_by_(.dots=c(config$subject_ids$blinded,"VISIT"))%>%
        filter(row_number()==1)%>%
        ungroup()
      s <- box %>%
        dplyr::filter(VISIT != "POOL") %>%
        dplyr::group_by_(.dots = c("FINAL_RUN_NO", config$balance_vars[i])) %>%
        dplyr::summarize(Count = n()) %>%
        reshape2::dcast(reformulate(config$balance_vars[i], "FINAL_RUN_NO"), value.var = "Count") %>%
        dplyr::mutate(TOTAL = rowSums(., na.rm = TRUE) - FINAL_RUN_NO)
    }
    else{
      s <- box %>%
        dplyr::filter(VISIT != "POOL") %>%
        dplyr::group_by_(.dots = c("FINAL_RUN_NO", config$balance_vars[i])) %>%
        dplyr::summarize(Count = n()) %>%
        reshape2::dcast(reformulate(config$balance_vars[i], "FINAL_RUN_NO"), value.var = "Count") %>%
        dplyr::mutate(TOTAL = rowSums(., na.rm = TRUE) - FINAL_RUN_NO)
    }


    sc <- c("TOTAL", colSums(s[2:ncol(s)], na.rm = TRUE))

    s <- rbind(s,sc)

    sn = paste("Summary -", substr(config$balance_vars[i], 1, 20))
    mmgeDistributions:::addWorksheet(wb, sn, s, borders = "all")

  }

  return(invisible(wb))

}