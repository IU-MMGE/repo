#'@export

build_dcr_pullsheet = function(pull,subject_sheet){
  require(openxlsx)
  if(any(grepl("barcode|bar code",names(subject_sheet),ignore.case = TRUE))){
    names(subject_sheet)[grepl("barcode|bar code",names(subject_sheet),ignore.case=TRUE)][1] = "DNANumber"
  }
  duplicated = pull[duplicated(pull$DNANumber),]%>%select(DNANumber)
  missing = subject_sheet%>%anti_join(pull)
  wb = openxlsx::createWorkbook()
  openxlsx::addWorksheet(wb,"Pullsheet")
  openxlsx::addWorksheet(wb,"Duplicated")
  openxlsx::addWorksheet(wb,"Missing")
  openxlsx::writeData(wb,sheet=1,pull)
  openxlsx::writeData(wb,sheet=2,duplicated)
  openxlsx::writeData(wb,sheet=3,missing)
  openxlsx::saveWorkbook(wb,"./pullsheet.xlsx",overwrite = TRUE)
}
