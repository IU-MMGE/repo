#' Save attachments related to a Footprints pullsheet request
#'
#'@param fp_id the footprints issue id
#'@param dest The destination directory for the save files
#'
#'@export
get_footprints_attachments <- function(fp_id, dest = "./data") {

  request_data <- get_footprints_issue(fp_id, ask = FALSE)

  email_subject <- sprintf("ISSUE=%s PROJ=161", request_data$number)
  attachments <- unlist(strsplit(request_data$attachments, split = "\n"))
  attachments <- attachments[attachments != ""]

  if(!grepl("/$", dest)) dest <- sprintf("%s/", dest)

  if(!dir.exists(dest)) {
    dir.create(dest, recursive = TRUE)
  }

  rPython::python.exec("from exchangelib import DELEGATE, Account, Credentials, Configuration")
  rPython::python.exec(sprintf("lp = '%s'", dest))
  rPython::python.exec(sprintf("credentials = Credentials(username='ADS\\\\%s', password='%s')", Sys.info()['user'], mmge:::iup()))
  rPython::python.exec("config = Configuration(server='eas.exchange.iu.edu', credentials=credentials)")
  rPython::python.exec(sprintf("account = Account(primary_smtp_address='%s@iu.edu', config=config, autodiscover=False, access_type=DELEGATE)", Sys.info()['user']))
  suppressWarnings(rPython::python.exec(sprintf("

  it_folder = account.root.get_folder_by_name('IT Help')

  xx = it_folder.filter(subject__startswith='New Request', subject__contains='%s')

  for item in xx:
    for attachment in item.attachments:
      local_path = lp + attachment.name
      with open(local_path, 'wb') as f:
        f.write(attachment.content)
        print('Saved attachment to ', local_path)

  ", email_subject)))

  shorten_file_names <- function(dest, regex, short_name = regex) {

    files <- list.files(dest)
    matched_files <- files[grepl(regex, files, ignore.case = TRUE)]

    if(length(matched_files) > 0) {

      for(i in seq(length(matched_files))) {
        if(grepl("\\.xlsx|\\.csv", matched_files[i])) {
          ext <- ifelse(grepl("\\.xlsx", matched_files[i]), ".xlsx", ".csv")
          cnt <- ifelse(i == 1, "", i)
          file.rename(file.path(dest, matched_files[i]), file.path(dest, paste0(short_name, cnt, ext)))
        }
      }

    }

  }

  shorten_file_names(dest, "clinical")
  shorten_file_names(dest, "request")


}