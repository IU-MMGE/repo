library(mmge)
library(mmgeCatalogs)
library(htmltools)

process_catalogs <- function(base_dir = getOption("catalog_dir")) {

  catalog_dirs <- get_catalog_dirs(base_dir)
  dirs <- list.dirs(getOption('catalog_dir'), full.names = TRUE, recursive = FALSE)
  #dirs <- dirs[c(1,7)]
  msgs <- list()
  has_errors <- FALSE

  add_msg <- function(msg, type = 'message', name = config$name) {
    msg <- glue::glue(msg)
    styles <- list(
      success = "color: green; font-family: sans-serif; padding-top: 5px;",
      message = "color: black; font-family: sans-serif; padding-top: 5px;",
      failure = 'color: red; font-family: sans-serif; padding-top: 5px;',
      code = 'padding: 20px; background-color: #DDD; color: red; font-family: monospace;'
    )
    if(type != 'code') {
      msg <- as.character(tags$tr(style = styles[[type]], tags$td(width = 30, ""), tags$td(tags$li("")), tags$td(style = 'padding-left: 10px;', msg)))
    } else {
      msg <- as.character(tags$tr(tags$td(colspan = "2", " "), tags$td(style = styles[[type]], msg)))
    }
    attr(msg, 'type') <- type
    msgs[[name]][length(msgs[[name]]) + 1] <<- msg
  }

  for(dir in dirs) {
    x <- list.files(dir)
    all_successful <- TRUE
    if('config.yaml' %in% x) {
      config <- try({
        x <- mmgeCatalogs:::initialize_catalog_object(dir) %>%
          mmgeCatalogs:::get_config()
        x$config
      }, silent = TRUE)
      message(config$name)
      if(file.exists(file.path(dir, ".last_successful"))) {
        last_successful <- as.Date(readLines(file.path(dir, ".last_successful")))
      } else {
        last_successful <- as.Date("1900-01-01")
      }
      if(Sys.Date() == last_successful) {
        add_msg("{config$name} already successful today. Skipped...")
      } else {
        if(file.exists(file.path(dir, ".last_successful"))) {
          last_successful <- as.Date(readLines(file.path(dir, ".last_successful")))
        } else {
          last_successful <- as.Date("1900-01-01")
        }
        if(Sys.Date() == last_successful) {
          add_msg()
        } else {
        catalog <- try(mmgeCatalogs::build_catalog(catalog_dir = dir), silent = TRUE)
        if(inherits(catalog, 'try-error')) {
          all_successful <- FALSE
          add_msg("{config$name} failed to run. This is the reported error", 'failure')
          add_msg(attr(catalog, 'condition')$message, 'code')
        } else {
          add_msg("{config$name} ran successfully.", "success")
          catalog_published <- try(mmgeCatalogs::publish_catalog_data(catalog), silent = TRUE)
          if(inherits(catalog_published, 'try-error')) {
            all_successful <- FALSE
            add_msg("Unable to publish {config$name} data to database.", 'failure')
            add_msg(attr(catalog_published, 'condition')$message, 'code')
          } else {
            add_msg("Successfully published {config$name} data to database.", 'success')
          }
          if("publish" %in% names(config)) {
            catalog_pushed <- try(mmgeCatalogs::push_catalog(catalog), silent = TRUE)
            if(inherits(catalog_pushed, 'try-error')) {
              all_successful <- FALSE
              add_msg("Unable to publish {config$name} data to {config$publish$where}.", 'failure')
              add_msg(attr(catalog_pushed, 'condition')$message, 'code')
            } else {
              add_msg("Successfully pushed {config$name} data to {config$publish$where}.", 'success')
            }
          } else {
            add_msg("No publishing set for {config$name}.")
          }
          if("save_day" %in% names(config)) {
            save_day <- config$save_day
          } else {
            save_day <- "Friday"
          }
          if(format(Sys.Date(), "%A") %in% save_day) {
            catalog_saved <- try(mmge::save_report(catalog$catalog, name = "Sample Catalog", protocol = config$protocol, type = 'csv'), silent = TRUE)
            if(inherits(catalog_saved, 'try-error')) {
              all_successful <- FALSE
              add_msg("Unable to save {config$name} data to HG-Data.", 'failure')
              add_msg(attr(catalog_saved, 'condition')$message, 'code')
            } else {
              add_msg("Successfully saved {config$name} data to HG-Data.", 'success')
            }
          } else {
            add_msg("No need to save catalog to HG-Data.")
          }
        }
      }
      if(all_successful) {
        f <- file(file.path(dir, '.last_successful'), open = "w")
        writeLines(as.character(Sys.Date()), con = f)
        close(f)
      } else {
        has_errors <- TRUE
      }
    }}
  }

  html_body <- c()

  for(i in seq(length(msgs))) {

    a <- names(msgs)[i]

    html_body <- c(html_body, as.character(tags$tr(tags$td(style = 'border-bottom: solid #333 1px;', colspan = '3', valign = 'bottom', height = '40', tags$h2(style = 'padding-top: 30px; font-family: sans-serif; color: #333;', names(msgs)[i])))))
    for(j in seq(length(msgs[[i]]))) {
      html_body <- c(html_body, msgs[[i]][j])
    }

  }

  html_body <- paste("<table>", paste(html_body, collapse = "\n"), "</table>", sep = "\n")

  pymailr::send_email("Catalog Creation Report", html_body = html_body, to = c('baileye@iu.edu'), from = "hgreport", send = TRUE)

}

get_catalog_dirs <- function(base_dir = "/media/HG-Data") {

  test_catalog_dirs <- Vectorize(function(catalog_dirs) {
    any(c("catalog.yaml", "config.yaml") %in% list.files(catalog_dirs))
  })

  catalog_dirs <- list.dirs(base_dir, recursive = TRUE)
  catalog_dirs <- catalog_dirs[grepl("/Catalogs", catalog_dirs)]
  catalog_dirs <- catalog_dirs[test_catalog_dirs(catalog_dirs)]

  return(catalog_dirs)

}