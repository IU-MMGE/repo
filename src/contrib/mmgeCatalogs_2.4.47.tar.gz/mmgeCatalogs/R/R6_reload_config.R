R6_reload_config <- function() {

  private$get_config()
  private$get_dictionary()
  private$get_recodes()
  private$initialize_build_environment()

}