catalog_template <- function(protocol, catalog_name) {

  protocol_dir <- file.path("/media/HG-Data", protocol)

  if(!dir.exists(protocol_dir)) {
    stop(protocol, " folder does not exist on HG-Data. Please create the folder and try again. See mmgeProtocols for functions to assist with this.")
  }

  catalog_dir <- file.path(protocol_dir, "Catalogs")

  if(!dir.exists(catalog_dir)) {
    dir.create(catalog_dir)
  }

  if('config.yaml' %in% list.files(catalog_dir)) {
    message("Existing root-level catalog found. Moving to a subfolder before continuing.")
    old_config <- yaml::yaml.load_file(file.path(catalog_dir, "config.yaml"))
    tryCatch({
      td <- file.path(tempdir(), old_config$short_name)
      dir.create(td)
      system(glue::glue("cp {catalog_dir}/* {td} -r"))
#      system(glue::glue("rm {catalog_dir}/* -r"))
      new_dir <- file.path(catalog_dir, old_config$short_name)
      dir.create(new_dir)
      system(glue::glue("cp {td}/* {new_dir} -r"))
    },
    error = function(e) {
      warning(e)
      system(glue::glue("cp {td}/* {catalog_dir} -r"))
    })
  }

  new_cat_dir <- file.path(catalog_dir, catalog_name)
  dir.create(new_cat_dir)



}