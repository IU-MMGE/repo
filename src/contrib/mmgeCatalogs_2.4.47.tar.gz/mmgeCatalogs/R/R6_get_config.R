R6_get_config <- function() {

  db <- debugR::debug('get_config')

  if(!all(file.exists(file.path(self$catalog_dir, c("config.yaml", "dictionary.yaml"))))) {
    stop("`", self$catalog_dir, "` must contain both a `config.yaml` and `dictionary.yaml` file.", call. = FALSE)
  }

  config <- try(yaml::yaml.load_file(file.path(self$catalog_dir, 'config.yaml')), silent = TRUE)

  if(inherits(config, 'try-error')) {
    stop("`config.yaml` in `", self$catalog_dir, "` not readable as yaml.", call. = FALSE)
  }

  protocol_settings <- try(yaml::yaml.load_file(file.path(self$protocol_dir, "Settings", "settings.yaml")), silent = TRUE)
  if(inherits(protocol_settings, 'try-error')) {
    protocol_settings <- list()
    warning("No `settings.yaml` file found...")
  }

  build <- yaml::yaml.load_file(system.file("defaults/build.yaml", package = "mmgeCatalogs"))
  display <- yaml::yaml.load_file(system.file("defaults/display.yaml", package = "mmgeCatalogs"))
  deploy <- yaml::yaml.load_file(system.file("defaults/deploy.yaml", package = "mmgeCatalogs"))

  mdr <- TRUE
  if("merge_distribution_rules" %in% names(config$build)) {
    mdr <- config$build$merge_distribution_rules
  }

  if(mdr == FALSE) {
    distribution_rules <- config$build$distribution_rules
  } else {
    if('distribution_rules' %in% names(protocol_settings)) {
      distribution_rules <- protocol_settings$distribution_rules
    } else {
      distribution_rules <- build$distribution_rules
    }
    if('distribution_rules' %in% names(config$build)) {

      drs <- config$build$distribution_rules

      for(i in seq(length(drs))) {

        dr <- drs[[i]]

        if(is.list(dr)) {
          distribution_rules[[names(drs)[i]]] <- dr
        } else if(tolower(dr) == 'exclude') {
          distribution_rules[[names(drs)[i]]] <- NULL
        } else {
          if(interactive()) {
            self$open('config')
          }
          stop("distribution_rules should contain either a list of distribution rules or the word `exclude`.", call. = FALSE)
        }

      }

    }
  }

  attribute_definitions <- build$attribute_definitions
  if('subject_ids' %in% names(settings)) {
    attribute_definitions$subject_id <- settings$subject_ids$clinical
  }
  if("attribute_definitions" %in% names(config$build)) {
    attribute_definitions <- utils::modifyList(attribute_definitions, config$build$attribute_definitions)
  }
  build$attribute_definitions <- attribute_definitions[attribute_definitions != "exclude"]

  if(!"grouping" %in% names(config$build)) {
    build$grouping <- c(
      attribute_definitions$subject_id,
      attribute_definitions$visit_id,
      attribute_definitions$specimen_type
    )
  }

  if('build' %in% names(config)) {
    build <- utils::modifyList(build, config$build)
  }

  build$distribution_rules <- distribution_rules

  if('display' %in% names(config)) {
    display <- utils::modifyList(display, config$display)
  }
  if('deploy' %in% names(config)) {
    deploy <- utils::modifyList(deploy, config$deploy)
  }

  compiled_config <- config[!names(config) %in% c('build', 'display', 'deploy')]
  compiled_config$catalog_dir <- self$catalog_dir
  compiled_config$build <- build
  compiled_config$display <- display
  compiled_config$deploy <- deploy

  private$config_obj <- compiled_config

  check_config(compiled_config)

  self$protocol <- compiled_config$protocol
  self$catalog_name <- compiled_config$short_name

  return(invisible(self))

}
