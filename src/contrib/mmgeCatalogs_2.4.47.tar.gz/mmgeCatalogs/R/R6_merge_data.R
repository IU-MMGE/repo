R6_merge_data <- function() {

  db <- debugR::debug("merge_data")

  # If only one source is present, no need to do anything else, just set the
  # catalog to that df and return.
  if(length(private$sources) == 1) {
    private$catalog_obj <- private$sources[[1]]
    return(self)
  }

  dict <- private$dictionary_obj
  if(private$config_obj$build$ignore_case) {
    dict$source_id <- dict$upper_id
  }

  # Find the source_joins section, either under 'build' or under the root of config
  if("source_joins" %in% names(private$config_obj$build)) {
    joins <- private$config_obj$build$source_joins
  } else if("source_joins" %in% names(private$config_obj)) {
    warning("`source_joins` should be moved under `build` in the config.yaml file.")
    joins <- private$config_object$source_joins
  } else {
    joins <- list()
  }

  # A vector of source names to keep track of which sources still need to be
  # joined.
  sources <- names(private$sources)

  # Determine the `primary_source`; the source that all other sources are joined
  # to
  if('primary_source' %in% names(private$config_obj$build)) {
    df <- private$sources[[private$config_obj$build$primary_source]]
    private$primary_source <- private$config_obj$build$primary_source
  } else if('oncore' %in% sources) {
    df <- private$sources$oncore
    private$primary_source <- 'oncore'
  } else if('tesla' %in% sources) {
    df <- private$sources$tesla
    private$primary_source <- 'tesla'
  } else {
    df <- private$sources[[1]]
    private$primary_source <- names(private$sources)[1]
    warning("No primary source defined. Using `", private$primary_source, "`")
  }

  db(paste0("primary_source: ", private$primary_source))

  # Remove primary source from list of sources and since its in the df now
  sources <- sources[sources != private$primary_source]

  # Remove the primary_source from the joins list (if it exists) and warn that it
  # shouldn't be there
  if(private$primary_source %in% names(joins)) {
    warning("`", primary$primary_source, "` is listed in the source joins section but it is the primary source. Ignoring join...")
    joins <- joins[names(joins) != private$primary_source]
  }
  cnt <- 0
  stp <- length(private$sources) + 1

  join_types <- list(
    inner = dplyr::inner_join,
    left = dplyr::left_join,
    right = dplyr::right_join,
    full = dplyr::full_join
  )

  while(length(sources) > 0) {

    # Insurance against an annoying infinite loop
    if(cnt > stp) {
      stop("Unknown error during source merging. Stopping to prevent infinite loop.", call. = FALSE)
    }

    if(length(joins) > 0) {

      src <- private$sources[[names(joins)[1]]]
      nm <- names(joins)[1]

      if('fields' %in% names(joins[[1]])) {
        fields <- joins[[1]]$fields
      } else {
        fields <- joins[[1]]
      }

      if('join_type' %in% names(joins[[1]])) {
        join_type <- join_types[[joins[[1]]$join_type]]
      } else {
        join_type <- join_types$left
      }

      if(any(sapply(fields, is.list))) {
        by <- c()
        for(i in seq(length(fields))) {
          field <- fields[[i]]
          if(!is.list(field)) {
            by <- c(by, field)
            names(by)[length(by)] <- names(fields)[i]
          } else {
            if(private$config_obj$build$ignore_case) {
              field$source_id <- toupper(field$source_id)
            }
            if('recode' %in% names(field)) {
              if(all(sapply(field$recode, is.numeric))) {
                recodes <- paste(glue::glue("\"{names(field$recode)}\" = {field$recode}"), collapse = ", ")
              } else {
                recodes <- paste(glue::glue("\"{names(field$recode)}\" = \"{field$recode}\""), collapse = ", ")
              }
              suppressWarnings(eval(parse(text = glue::glue('src${field$source_id} <- dplyr::recode(src${field$source_id}, {recodes}, .missing = as.character(src${field$source_id}))'))))
              src <- src[!is.na(src[[field$source_id]]), ]
            }
            if('mutate' %in% names(field)) {
              eval(parse(text = glue::glue("src <- dplyr::mutate(src, {field$source_id} = {field$mutate})")))
            }
            by <- c(by, field$source_id)
            names(by)[length(by)] <-  names(fields)[i]
          }
        }
      } else {
        by <- unlist(fields)
      }


      if(length(joins) == 1) {
        joins <- list()
      } else {
        joins <- joins[2:length(joins)]
      }
    } else {
      src <- private$sources[[1]]
      nm <- names(private$sources)[1]
      by <- c(colnames(df), colnames(src))[duplicated(c(colnames(df), colnames(src)))]
      if(length(x) == 0) {
        stop("Cannot join `", nm, "` because it isn't in the source joins and doesn't have any field names in common.")
      }
      warning("No entry for `", nm, "` in source_joins. Joining on ", paste("`", by, "`", sep = "", collapse = ", "))
    }

    # ##TESTING##
    # nm <- "test"
    # df <- mtcars
    # df$make <- sample(c("Ford", "Chevy", "Toyota", "Honda", "Kia"), size = 32, replace = TRUE)
    # src <- df[c('drat', 'make', 'vs', 'carb', 'gear', 'wt')]
    # df <-  df[c('drat', 'make', 'vs', 'mpg', 'cyl', 'hp', 'wt', 'qsec', 'am')]
    # by <- c("drat", "make", "vs")
    # names(by) <- by
    # ##TESTING##

    byn <- names(by)
    names(by) <- byn
    needed_fields <- c(dict$source_id[dict$source == nm])
    df_to_remove <- colnames(df)[colnames(df) %in% needed_fields[!needed_fields %in% unname(by)]]
    src_to_remove <- colnames(src)[!(colnames(src) %in% needed_fields | (colnames(src) %in% unname(by)))]
    src_to_remove <- src_to_remove[src_to_remove %in% colnames(df)]
    df <- df[,!colnames(df) %in% df_to_remove]
    src <- src[,!colnames(src) %in% src_to_remove]

    orig_class <- sapply(names(by), function(n) class(df[[n]]))
    for(i in seq(length(by))) {
      if(orig_class[i] != "character") {
        df[[names(by)[i]]] <- as.character(df[[names(by)[i]]])
      }
      src[[by[i]]] <- as.character(src[[by[i]]])
    }
    df_cnt <- nrow(df)
    df <- join_type(df, src, by = by)
    if(nrow(df) > df_cnt) {
      warning("Joining `", nm, "` increased record count from ", df_cnt, " to ", nrow(df), ". You may be missing a join field.", call. = FALSE)
    }
    for(i in seq(length(orig_class))) {
      if(orig_class[i] != "character") {
        df[[names(orig_class)[i]]] <- as(df[[names(orig_class)[i]]], Class = orig_class[i])
      }
    }

    sources <- sources[sources != nm]

    cnt <- cnt + 1

  }

  private$catalog_obj <- df

  return(invisible(self))

}