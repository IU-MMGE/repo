get_default_config <- function(protocol) {

  settings <- mmgeProtocols::get_protocol_settings(protocol)

  build <- yaml::yaml.load_file(system.file("defaults/build.yaml", package = "mmgeCatalogs"))

  if("subject_ids" %in% names(settings)) {
    if('clinical' %in% names(settings$subject_ids)) {
      build$attribute_definitions$subject_id <- settings$subject_ids$clinical
    }
  }

  if("distribution_rules" %in% names(settings)) {
    build$distribution_rules <- settings$distribution_rules
  }

  build$oncore_settings$filters$protocol <- protocol

  build$grouping <- unlist(unname(build$attribute_definitions[c("subject_id", "visit_id", "specimen_type")]))

  save <- yaml::yaml.load_file(system.file("defaults/save.yaml", package = "mmgeCatalogs"))

  display <- yaml::yaml.load_file(system.file("defaults/display.yaml", package = "mmgeCatalogs"))

  display$color <- sample(c("purple", "green", "red", "yellow", "blue"), 1)
  display$draft <- getOption("catalog_environment") != "PRD"

  config <- list(
    protocol = protocol,
    log_level = 'ERROR',
    build = build,
    save = save,
    display = display
  )

}