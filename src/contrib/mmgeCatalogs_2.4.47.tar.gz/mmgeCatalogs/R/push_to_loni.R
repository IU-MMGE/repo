#'@export
push_to_loni <- function(df, study, table, ..., intern = false) {

  loni_url <- "https://ida.loni.usc.edu/dbsync/table"

  opts <- list(...)

  defaults <- list(
    dateFormat = "YYYY-MM-DD",
    nullDateTime = "",
    nullString = "",
    nullFloat="",
    nullInteger="",
    fullSync=TRUE
  )

  for(i in seq_along(opts)) {
    defaults[[names(opts)[i]]] <- opts[i]
  }

  user <- Sys.getenv("LONI_USER")
  pw <- Sys.getenv("LONI_PW")

  cl_args <- sapply(seq_along(defaults), function(i) {

    if("logical" %in% class(defaults[[i]])) {
      if(defaults[[i]] == TRUE) {
        paste0("-", names(defaults)[i])
      }
    } else {
      paste0("-", names(defaults)[i],"=\"",defaults[[i]],"\"")
    }

  })

  for(i in seq(ncol(df))) {
    df[[i]] <- as.character(df[[i]])
  }

  tf <- tempfile(fileext = ".csv")
  # df <- gsub(",", replacement = "|", x = df, fixed = TRUE)
  write.table(df, file = tf, row.names = FALSE, quote = FALSE, col.names=FALSE, sep = ",", na="")

  jf <- system.file("java/LONIupload.jar", package = "mmgeCatalogs")
  jf <- gsub(" ", "\\ ", jf)
  cmd <- paste("java -jar -Djava.net.useSystemProxies=true", shQuote(jf), paste(cl_args, collapse = " "), shQuote(tf), loni_url, study, table, user, pw)

  op <- system(cmd, intern = intern)

}
