#'@export
build_catalog_data_warehouse <- function(dirs, include_tesla = TRUE, add_indices = TRUE) {

  warehouse_log <- function(level, event, msg = "") {

    mmgeCatalogsLite::write_log(protocol = "ALL", catalog = "ALL",
                              user = unname(Sys.info()['user']),
                              level = level, event = event, message = msg)

  }

  warehouse_log('info', "Updating Catalog Source Data")

  meta <- list(
    start_time = Sys.time()
  )

  if(missing(dirs)) {
    dirs <- get_catalog_directories()
  }

  protocols <- c("MMGE-REF-POOL")
  fields <- c()
#  fields <- unique(oncore2::field_list()$COLUMN_NAME[oncore2::field_list()$TABLE_NAME %in% c("SV_BSM_SPECIMEN")])
  fields <- unique(c(fields, settings$default_fields))
  bad_fields <- c()

  query <- NULL
  valid_fields <- unique(c(oncore2::annotation_list()$ANNOTATION, oncore2::field_list()$COLUMN_NAME))

  tryCatch({
    for(dir in dirs) {
      suppressWarnings({
        config <- try(yaml::yaml.load_file(file.path(dir, "config.yaml")))
        dictionary <- try(yaml::yaml.load_file(file.path(dir, "dictionary.yaml")))
      })
      if(!inherits(config, 'try-error') && !inherits(dictionary, 'try-error')) {
        other_fields <- c()
        try({
          other_fields <- unique(c(config$build$oncore_settings$fields))
        }, silent = TRUE)
        protocols <- c(protocols, config$protocol)
        catalog_fields <- c(other_fields, get_oncore_fields(dictionary))
        bad_catalog_fields <- catalog_fields[!catalog_fields %in% valid_fields]
        if("CONCENTRATION_UOM" %in% catalog_fields) {
          print(config$protocol)
        }
        if(length(bad_catalog_fields) > 0) {
          message("Found ", length(bad_catalog_fields), " unrecognized field(s) in ", dir, ":\n\t", paste(bad_catalog_fields, collapse = "\n\t"))
        }
        if("COLLECTION_DATE" %in% catalog_fields) {
          warning(config$name, " contains COLLECTION_DATE. This could cause problems.")
        }
        fields <- c(fields, catalog_fields)
      } else {
        if(inherits(config, 'try-error')) {
          warehouse_log("error", "Config Load", config)
        }
        if(inherits(dictionary, 'try-error')) {
          warehouse_log("error", "Dictionary Load", dictionary)
        }
      }
    }

    protocols_all <- unlist(oncore2::query_oncore("select distinct P.PROTOCOL_NO from {schema}.ONC_PCL_MANAGEMENT_GROUP M, {schema}.SV_ACTIVE_PROTOCOLS P, {schema}.ONC_MANAGEMENT_GROUP G where  G.NAME in ('MMGE- Hereditary Genomics', 'MMGE-CC- Hereditary Genomics') and P.PROTOCOL_ID = M.PROTOCOL_ID and G.ONC_MANAGEMENT_GROUP_ID = M.RESEARCH_MANAGEMENT_GROUP_ID"), recursive = TRUE)

    fields <- unique(unlist(fields))
    valid_fields <- unique(c(oncore2::annotation_list()$ANNOTATION, oncore2::field_list()$COLUMN_NAME))
    bad_fields <- fields[!fields %in% valid_fields]
    fields <- unique(fields)
    fields <- sort(fields)
    if(length(bad_fields) > 0) {
      message("Removing ", length(bad_fields), " unrecognized field(s) from the oncore query.\n\t",paste(bad_fields, collapse = "\n\t"))
      fields <- fields[fields %in% valid_fields]
    }
    protocols <- unique(c(protocols, protocols_all))
    oncore_settings <- list(distinct = TRUE, recode = TRUE)

    query <- oncore2::oncore_query(selects = fields, filters = oncore2::mmge_protocols(), .args = oncore_settings) %>%
      dplyr::select(-JOIN_SPECIMEN_NO, -JOIN_CASE_NO)

  },
  error = function(e) {
    warehouse_log(level = "error", event = "OnCore Data Error", msg = e['message'])
    if(interactive()) stop(e)
  })

  con <- mmgeMongo::mongo_connection(settings$mongo$database, settings$mongo$data_collection)
  con$drop()
  con$insert(query, na = "string", null = "list")

  if(include_tesla) {
    tesla_map <- yaml::yaml.load_file(system.file("settings/tesla_map.yaml", package = "mmgeCatalogs"))
    tesla_con <- DBI::dbConnect(odbc::odbc(), "WATERBIRD_PRD", uid = "mjffdata", pwd = "MJF-123-ata")
    tesla <- DBI::dbGetQuery(tesla_con, "SELECT * FROM WATERBIRD_PRD.dbo.V_MJFF_DATA") %>%
      dplyr::select(names(tesla_map))
    colnames(tesla) <- tesla2oncore(colnames(tesla), clean = TRUE)
    tesla <- dplyr::anti_join(tesla, query, by = c("PROTOCOL_NO", "SUBJECT_MRN", "CASE_NO", "COLLECTION_GROUP")) %>%
      dplyr::select(colnames(query)[colnames(query) %in% colnames(tesla)])
    con$insert(tesla, na = "string", null = "list")
  }

  tryCatch({

    if(add_indices) {
      indices <- local({
        prt <- c("PROTOCOL_NO")
        sbj <- c("SUBJECT_LAST_NAME", "ALTERNATE_MRN", "SUBJECT_MRN")
        vst <- c("VISIT", "TIMEPOINT_LABEL")
        stp <- c("COLLECTION_GROUP", "SPECIMEN_TYPE")
        spm <- c("SPECIMEN_NO", "ALT_SPECIMEN_ID", "SPECIMEN_BAR_CODE")

        all_fields <- as.list(c(prt, sbj, vst, stp))
        indices <- as.list(c(prt, spm, vst, stp, sbj))
        for(sub in sbj) {
          for(vis in vst) {
            indices[[length(indices)+1]] <- c(sub, vis)
            for(spe in stp) {
              indices[[length(indices)+1]] <- c(sub, vis, spe)
            }
          }
        }

#        indices <- intersect(colnames(query), indices)
        indices <- indices[1:min(length(indices), 63)]

        return(indices)

      })


      sapply(indices, function(ind) {
        index <- as.list(rep(1, times = length(ind)))
        names(index) <- ind
        index <- jsonlite::toJSON(index, auto_unbox = TRUE)
        if (interactive())
          message("Adding index: ", index)
        con$index(add = index)
      })

    }

    meta$protocols <- protocols
    meta$records <- nrow(query)
    meta$end_time <- Sys.time()

    con <- mmgeMongo::mongo_connection(settings$mongo$database, settings$mongo$meta_collection)
    con$drop()
    con$insert(meta)
  }, error = function(e) {
    warehouse_log(level = "error", event = "Mongo Data Error", msg = e['message'])
  })

}

get_oncore_fields <- function(dictionary) {

  oncore_dictionary <- unlist(sapply(seq_along(dictionary), function(i) {
    field <- dictionary[[i]]
    if("source" %in% names(field)) {
      if(field$source == 'oncore') {
        if("source_id" %in% names(field)) {
          return(field$source_id)
        } else {
          return(names(dictionary)[i])
        }
      }
    }
    return(NULL)
  }))

}
