depletion_check <- function(pull = NULL, aliquot = NULL, dir = ".", query_date = NULL) {

  config <- get_pullsheet_config(dir)
  dl <- config$depletion_warning_levels

  query <- oncore_pullsheet_query(dir, verbose = FALSE, query_date = query_date) %>%
    dplyr::mutate(COLLECTION_GROUP = ifelse(COLLECTION_GROUP == "BUFFY COAT" &
                                     !("BUFFY COAT" %in% names(config$aliquot_sizes)), "DNA", COLLECTION_GROUP))

  if(sum(duplicated(query$SPECIMEN_NO)) > 0 & "ALTERNATE_MRN" %in% colnames(query)) {
    query <- query %>%
      dplyr::group_by(SPECIMEN_NO) %>%
      dplyr::filter(ifelse(n() > 1, !is.na(ALTERNATE_MRN), TRUE))
  #  query <- dplyr::filter(query, !is.na(ALTERNATE_MRN))
  }

  query <- query %>%
    dplyr::filter(SPECIMEN_STATUS == "Available") %>%
    dplyr::group_by(SPECIMEN_NO) %>%
    dplyr::mutate(DISTRIBUTABLE_ALIQUOT = min(config$aliquot_sizes[COLLECTION_GROUP][[1]])) %>%
    dplyr::ungroup() %>%
    dplyr::filter(SPECIMEN_QUANTITY >= DISTRIBUTABLE_ALIQUOT) %>%
    dplyr::mutate(VALIQUOTS = floor(SPECIMEN_QUANTITY / DISTRIBUTABLE_ALIQUOT)) %>%
    dplyr::mutate(VALIQUOTS = ifelse(VALIQUOTS == 1, 1, VALIQUOTS - 1)) %>%
    dplyr::mutate(DISTRIBUTABLE_VOLUME = VALIQUOTS * DISTRIBUTABLE_ALIQUOT) %>%
    dplyr::group_by_(.dots = c(config$subject_ids$blinded, "VISIT", "COLLECTION_GROUP")) %>%
    dplyr::summarize(
      DISTRIBUTABLE_VOLUME = sum(DISTRIBUTABLE_VOLUME)
    )

  request <- data.frame()
  if(!is.null(aliquot)) {
    ali <- aliquot %>%
      dplyr::ungroup() %>%
      dplyr::group_by(SPECIMEN_NO) %>%
      dplyr::mutate(SPECIMEN_QUANTITY = min(config$aliquot_sizes[[COLLECTION_GROUP]])) %>%
      dplyr::select_(.dots = c("SPECIMEN_NO", "SUBJECT_LAST_NAME","ALTERNATE_MRN","PATIENT_ID", "VISIT", "COLLECTION_GROUP" ,REQUESTED_VOLUME = "SPECIMEN_QUANTITY")) %>%
      dplyr::ungroup()
    request <- rbind(request, ali)
  }
  if(!is.null(pull)) {
    pul <- pull %>%
      dplyr::ungroup() %>%
      dplyr::select_(.dots = c("SPECIMEN_NO", "SUBJECT_LAST_NAME","ALTERNATE_MRN","PATIENT_ID", "VISIT", "COLLECTION_GROUP", REQUESTED_VOLUME = "SPECIMEN_QUANTITY")) %>%
      dplyr::ungroup()
    request <- rbind(request, pul)
  }
  if(nrow(request) > 0) {
    request <- request %>%
      dplyr::group_by_(.dots = c("SUBJECT_LAST_NAME","ALTERNATE_MRN","PATIENT_ID", "VISIT", "COLLECTION_GROUP")) %>%
      dplyr::summarize(
        REQUESTED_VOLUME = sum(REQUESTED_VOLUME)
      )

    report <- query %>%
      dplyr::semi_join(request) %>%
      dplyr::left_join(request) %>%
      dplyr::mutate(REMAINING_VOLUME = DISTRIBUTABLE_VOLUME - REQUESTED_VOLUME) %>%
      dplyr::group_by_(.dots = c(config$subject_ids$blinded, "VISIT", "COLLECTION_GROUP")) %>%
      dplyr::mutate(DEPLETION_LEVEL = dl[[COLLECTION_GROUP]]) %>%
      dplyr::ungroup() %>%
      dplyr::filter(REMAINING_VOLUME < DEPLETION_LEVEL) %>%
      dplyr::arrange(REMAINING_VOLUME)

    report = cbind(report[,c("SUBJECT_LAST_NAME","ALTERNATE_MRN","PATIENT_ID")],dplyr::select(report,-SUBJECT_LAST_NAME,-ALTERNATE_MRN,
                                                                                              -PATIENT_ID))
  } else {
    report <- NULL
  }

  return(report)

}

#'@export
depletion_table = function(pull=NULL,aliquot=NULL,extract=NULL,combine=NULL,query){
  if(!is.null(pull)){
    dcpull = pull%>%
      dplyr::select(SPECIMEN_BAR_CODE,PATIENT_ID,SPECIMEN_QUANTITY,SUBJECT_LAST_NAME,ALTERNATE_MRN,CASE_NO,COLLECTION_GROUP)
  } else{
    dcpull = NULL
  }
  if(!is.null(aliquot)){
    dcaliquot = aliquot%>%
      dplyr::select(SPECIMEN_BAR_CODE,PATIENT_ID,SPECIMEN_QUANTITY,SUBJECT_LAST_NAME,ALTERNATE_MRN,CASE_NO,COLLECTION_GROUP,SPECIMEN_TYPE)
    dcaliquot2 = query%>%
      filter(SPECIMEN_STATUS=="Available")%>%
      semi_join(dcaliquot,by=c("SPECIMEN_TYPE","COLLECTION_GROUP","CASE_NO"))%>%
      filter(!grepl(".",SPECIMEN_NO,fixed = T))%>%
      anti_join(dcaliquot,by="SPECIMEN_BAR_CODE")%>%
      mutate(PARENT_ALIQUOT_EXISTS = TRUE)%>%
      select(CASE_NO,PARENT_ALIQUOT_EXISTS)
    dcaliquot = select(dcaliquot,-SPECIMEN_TYPE)
  } else{
    dcaliquot = NULL
  }
  if(!is.null(extract)){
    dcextract = extract%>%
      dplyr::select(SPECIMEN_BAR_CODE,PATIENT_ID,SPECIMEN_QUANTITY,SUBJECT_LAST_NAME,ALTERNATE_MRN,CASE_NO,COLLECTION_GROUP)
  } else{
    dcextract = NULL
  }
  if(!is.null(combine)){
    dccombine = combine%>%
      dplyr::select(SPECIMEN_BAR_CODE,PATIENT_ID,SPECIMEN_QUANTITY,SUBJECT_LAST_NAME,ALTERNATE_MRN,CASE_NO,COLLECTION_GROUP)
  } else{
    dccombine = NULL
  }



  dc = query%>%
    semi_join(rbind(dcpull,dcaliquot,dcextract,dccombine),by=c("CASE_NO","COLLECTION_GROUP"))%>%
    filter(SPECIMEN_STATUS=="Available"&!is.na(SPECIMEN_QUANTITY))%>%
    group_by(CASE_NO,COLLECTION_GROUP)%>%
    arrange(SPECIMEN_QUANTITY)%>%
    mutate(TOTAL_VOLUME = sum(SPECIMEN_QUANTITY))%>%
    mutate(QUANTITY_LIST = list(SPECIMEN_QUANTITY))%>%
    select(PATIENT_ID,SUBJECT_LAST_NAME,ALTERNATE_MRN,CASE_NO,COLLECTION_GROUP,TOTAL_VOLUME,QUANTITY_LIST,SPECIMEN_BAR_CODE)%>%
    filter(row_number()==1)%>%
    arrange(TOTAL_VOLUME)
  if(!is.null(aliquot)){
    dc = dc%>%
      left_join(dcaliquot2,by="CASE_NO")%>%
      mutate(PARENT_ALIQUOT_EXISTS = ifelse(is.na(PARENT_ALIQUOT_EXISTS)&SPECIMEN_BAR_CODE%in%dcaliquot$SPECIMEN_BAR_CODE,FALSE,PARENT_ALIQUOT_EXISTS))%>%
      select(-SPECIMEN_BAR_CODE)
  }
  if(nrow(dc)==0){
    dc = data.frame(INFO = "No Available Samples in the provided Case No.")
  }
  return(dc)
}

