#'@export

pullsheet_lab = function(record_id,file){
  require(mmgeMongo)
  dir = "/media/R/zagoodma/PULLSHEETS/MMGE-ALL/FLUIDIGM_PULLSHEETS/R"
  setwd(dir)
  if(!missing(record_id)){
    rcon = redcapAPI::redcapConnection(url = "https://redcap.uits.iu.edu/api/",
                                       token = "1B910E78315CDFE527811B042540E5C6")
    table = redcapAPI::exportReports(rcon, 58763)
    if(!is.na(table$subj_visit_select_file[table$record_id==record_id])){
      do.call(file.remove, list(list.files("./samples", full.names = TRUE)))
      redcapAPI::exportFiles(rcon,record = record_id,field="subj_visit_select_file",dir=file.path("/media/R/zagoodma/PULLSHEETS","MMGE-ALL","FLUIDIGM_PULLSHEETS","R","samples"))
    }
  }
  if(missing(file)){
    if(length(list.files(file.path(dir,"samples")))>0){
      subject_sheet = mmgeDistributions::read_excel_allsheets("samples")
      subject_sheet = subject_sheet[[1]]
    }
  }
  if(any(!is.na(subject_sheet$SPECIMEN_BAR_CODE))){
    pull = moncore_query(SPECIMEN_BAR_CODE=subject_sheet$SPECIMEN_BAR_CODE)
    query = moncore_query(CASE_NO=pull$CASE_NO)
    wb = build_pullsheet_wb_test(pull = pull,query = query)
    file_name = save_pullsheet_workbook(wb,paste0("Fluidigm_Pullsheet_",record_id))
    message("Pullsheet Complete")
  } else{
    message("No Barcodes Available")
  }
}