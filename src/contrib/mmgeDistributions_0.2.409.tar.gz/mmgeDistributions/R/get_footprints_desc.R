#'Return description information for a selected footprints issue id
#'
#'Will return any description data from the Footprints API given a provided
#'footprints issue id.
#'
#'@param fp_id The Footprints Issue ID
#'
#'@export
get_footprints_desc <- function(fp_id) {

  url <- sprintf("https://ebidvt.uits.iu.edu/denodo-restfulws/footprints/views/fpprod_in_medgen_descriptions?$filter=number_param%%3D%s", fp_id)
  x <- httr::content(httr::GET(url, httr::accept_json(), mmge::authenticate_iu()))$elements
  x <- paste(unlist(as.data.frame(do.call(rbind, x))$data), collapse = "\n")

  return(x)

}