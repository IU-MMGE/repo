#'Begin a standard oncore query for pullsheets
#'
#'@param dir The directory that contains the pullsheet project
#'
#'@export
oncore_pullsheet_query <- function(dir = ".", execute = TRUE, query_date = NULL, verbose, async = TRUE,filter_cg=T,filter_protocol=T,filter_status=T,filter_rrf=F) {

  config <- get_pullsheet_config(dir)
  if(missing(verbose)) {
    verbose = config$verbose
  }

  if(is.null(query_date)) {

    fields <-  c("PROTOCOL_NO","SPECIMEN_NO", "SPECIMEN_STORAGE_LOCATION", "PARENT_SPECIMEN_ID",
      "ALTERNATE_MRN", "PATIENT_ID","SUBJECT_LAST_NAME","COLLECTION_GROUP", "SPECIMEN_TYPE",
      "VISIT", "CASE_NO", "SPECIMEN_QUANTITY", "SPECIMEN_BAR_CODE", "SPECIMEN_STATUS",
      "PCS_SPECIMEN_ID", "SPECIMEN_COMMENTS","SEQUENCE_NUMBER","SPECIMEN_REQUEST_ID","UNIT_OF_MEASURE","GENDER")

    process_hemoglobin <- any(c("SERUM", "CSF", "PLASMA") %in% config$collection_group)

    if(!is.null(config$additional_oncore_fields)) {
      fields <- unique(c(fields, config$additional_oncore_fields))
    }

    query_name <- sprintf("%s_query", config$order_name)

    queryObject <- oncore2::oncore_connect(verbose = verbose,
                                           env = config$oncore_environment,
                                           query_name = query_name)

    queryObject <- oncore2::select_fields_(queryObject, .dots = fields)

    queryObject <- oncore2::select_annotations(queryObject, "Freeze / Thaw Cycle")
    queryObject = oncore2::select_annotations(queryObject, "Kit Number")
    queryObject = oncore2::select_annotations(queryObject, "Researcher Reserved For")
    queryObject <- oncore2::select_annotations(queryObject, "Concentration")
    queryObject <- oncore2::select_annotations(queryObject, "Concentration UOM")
    queryObject <- oncore2::select_annotations(queryObject, "Instrument for QC")
    queryObject <- oncore2::select_annotations(queryObject, "Volume")
    queryObject <- oncore2::select_annotations(queryObject, "Volume UOM")
    queryObject = oncore2::select_annotations(queryObject, "Collection Container")
    queryObject = oncore2::select_annotations(queryObject, "Storage Container")
    queryObject = oncore2::select_annotations(queryObject, "Cell Type")
    queryObject <- oncore2::select_annotations(queryObject, "Hemolysis Grade")
    queryObject <- oncore2::select_annotations(queryObject, "Hemoglobin Assay")
    queryObject <- oncore2::select_annotations(queryObject, "Turbidity Grade")
    queryObject <- oncore2::select_annotations(queryObject, "260/230 Ratio")
    queryObject <- oncore2::select_annotations(queryObject, "260/280 Ratio")
    queryObject <- oncore2::select_annotations(queryObject, "RIN Value")
    queryObject <- oncore2::select_annotations(queryObject, "Case or Control")

    if(any(c("DNA", "BUFFY COAT") %in% config$collection_group)) {
      queryObject <- oncore2::select_annotations(queryObject, "DNA Source")
      queryObject <- oncore2::select_annotations(queryObject, "Genotyped")
      queryObject <- oncore2::select_annotations(queryObject, "Last Date Genotyped")
    }

    if(!is.null(config$additional_oncore_annotations)) {
      queryObject <- oncore2::select_annotations(queryObject, .dots = config$additional_oncore_annotations)
    }

    if(config$only_available_specimens) {
      if(filter_status==T){
        queryObject <- oncore2::filter_oncore(queryObject, oncore2::specimen_status("Available"))
      }
    } else {
      queryObject <- oncore2::select_fields(queryObject, REASON_DESTROYED)
    }
    if(filter_protocol==T){
      queryObject <- oncore2::filter_oncore(queryObject, oncore2::protocol(config$protocol))
    }
    if(!is.null(config$collection_group)) {
      if("DNA" %in% config$collection_group) {
        config$collection_group <- unique(c(config$collection_group, "BUFFY COAT"))
      }
      cg <- paste0("oncore2::or(", paste(sprintf("oncore2::collection_group('%s')", config$collection_group), collapse = ", "), ")")
      if(filter_cg==T){
        eval(parse(text = paste0("queryObject <- oncore2::filter_oncore(queryObject,", cg, ")")))
      }
    }

    if(execute) {
      if(verbose) {message("Oncore query initiated: ", Sys.time())}
      query <- oncore2::execute_query(queryObject, recode = TRUE)
      if(verbose) {message("Oncore query complete: ", Sys.time())}
      if(process_hemoglobin) {
        if(config$hemoglobin_level == "case") {
          query <- dplyr::group_by(query, CASE_NO)
        } else if(config$hemoglobin_level == "parent") {
          query <- dplyr::mutate(query, PARENT_SPECIMEN_ID = ifelse(is.na(PARENT_SPECIMEN_ID), PCS_SPECIMEN_ID, PARENT_SPECIMEN_ID))
          query <- dplyr::group_by(query,PARENT_SPECIMEN_ID)
        }
        query <- suppressWarnings(dplyr::mutate(query, HEMOGLOBIN_ASSAY = ifelse(is.na(HEMOGLOBIN_ASSAY), max(HEMOGLOBIN_ASSAY, na.rm = TRUE), HEMOGLOBIN_ASSAY)))
        query <- dplyr::mutate(query, SPECIMEN_COMMENTS = ifelse(is.na(SPECIMEN_COMMENTS), "", SPECIMEN_COMMENTS))
      }
      query = recode_field(query,"CONCENTRATION_UOM")
      query = recode_field(query,"INSTRUMENT_FOR_QC")
      query = recode_field(query,"VOLUME_UOM")
      query = recode_field(query,"RESEARCHER_RESERVED_FOR")
      query = recode_field(query,"STORAGE_CONTAINER")
      query = recode_field(query,"COLLECTION_CONTAINER")
      query = recode_field(query,"CASE_OR_CONTROL")
      query = recode_field(query,"HEMOLYSIS_GRADE")
      query = recode_field(query,"TURBIDITY_GRADE")
      if("DNA" %in% config$collection_group){
        query = recode_field(query,"CONCENTRATION_UOM")
        query = recode_field(query,"INSTRUMENT_FOR_QC")
        query = recode_field(query,"VOLUME_UOM")
        query = recode_field(query,"DNA_SOURCE")
        query = recode_field(query,"GENOTYPED")
        query = recode_field(query,"RESEARCHER_RESERVED_FOR")
        query = recode_field(query,"STORAGE_CONTAINER")
        query = recode_field(query,"COLLECTION_CONTAINER")
        query = recode_field(query,"CASE_OR_CONTROL")
        query = recode_field(query,"HEMOLYSIS_GRADE")
        query = recode_field(query,"TURBIDITY_GRADE")
        query = query%>%dplyr::filter(!GENOTYPED%in%c("FAIL","GENOERR"))
      }
      if(filter_rrf==T){
        query = oncore2::recode_field(query,"RESEARCHER_RESERVED_FOR")
        query = query%>%dplyr::filter(RESEARCHER_RESERVED_FOR!="Reference Pool"|is.na(RESEARCHER_RESERVED_FOR))
      }

      query$FREEZE_._THAW_CYCLE[!is.na(query$FREEZE_._THAW_CYCLE)] <- 0

      fn <- file.path(config$directory, "R", "data", paste0("query_", Sys.Date(), ".rda"))
      save(query, file = fn)
      return(invisible(query))
    } else {
      return(invisible(queryObject))
    }

  } else {
    fn <- file.path(config$directory, "R", "data", paste0("query_", format(as.Date(query_date), "%Y-%m-%d"), ".rda"))
    if(file.exists(fn)) {
      if(verbose) {message("Loading saved query from ", query_date, "...")}
      load(fn)
      return(invisible(query))
    } else {
      stop("No query data saved for ", query_date, call. = FALSE)
    }
  }

}