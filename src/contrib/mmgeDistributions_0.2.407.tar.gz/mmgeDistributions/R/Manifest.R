Manifest <- R6::R6Class("Manifest",
  public = list(

    initialize = function(request_id, verbose = TRUE) {
      private$verbose = verbose
      private$request_id = request_id
      private$manifest_settings <- mmge::get_config("manifests")
      private$getRedCapData()
      private$getOnCoreData()
      if("DNA" %in% private$collection_groups) {
        if(length(private$collection_groups) > 1) {
          private$active = FALSE
          private$addProblem("This tool currently cannot combine DNA manifests with other manifests for other specimen types.", level = "error")
        } else {
          private$message("DNA Manifest Detected...")
        }
        # Add code to start DNA Manifest
      } else {
        private$message("Pull and Ship Manifest Detected...")
        private$getPullsheet()
        private$getBoxPositions()
        private$getProjectSettings()
        private$getManifestFields()
        if(private$active) {
          private$message(crayon::green("All required information found. Run `build` method to create the manifest then `save` method to save it to the appropriate directory."))
        } else {
          private$message("Could not find all required information to create manifest. Please correct issues found below:")
          self$error
        }
      }

      return(invisible(self))

    },
    build = function() {
      private$createManifest()
      return(invisible(self))
    },
    print = function() {
      print(private$manifest)
      return(invisible(self))
    },
    save = function(directory, filename, save_report = TRUE) {
      if(missing(directory)) {
        directory <- file.path(private$project_dir, "Manifests")
      }
      if(!dir.exists(directory)) {
        dir.create(directory)
      }
      if(missing(filename)) {
        filename <- paste0(private$project_settings$order_name, "_manifest_", Sys.Date(), ".xlsx")
      } else {
        if(!grepl("xlsx$", filename)) {
          filename = paste0(filename, ".xlsx")
        }
      }
      private$message("Saving Manifest as ", filename)
      openxlsx::write.xlsx(private$manifest, file = file.path(directory, filename))
      private$filepath <- file.path(directory, filename)

      if(save_report) {
        if(length(private$problemList) > 0) {
          rep_fn <- paste0(private$project_settings$order_name, "_manifest_report_", Sys.Date(), ".txt")
          private$message("Saving Manifest Report as ", rep_fn)
          report = c()
          for(level in names(private$problemList)) {
            if(length(private$problemList[[level]] > 0)) {
              report <- c(report, paste0("#### ", toupper(level) , "S ####"))
              for(problem in private$problemList[[level]]) {
                report = c(report, paste0("\t* ", problem))
              }
              report <- c(report, "")
            }
          }
          report_path <- file.path(directory, rep_fn)
          report_file <- file(report_path)
          writeLines(report, report_file)
          close(report_file)
          mmge::unix2win(report_path) ## Change line ending so it opens nicely in notepad on windows
        }
      }

      return(invisible(self))

    }

  ),
  active = list(
    problems = function() {
      private$problemReport()
    },
    errors = function() {
      private$problemReport("error")
    },
    warnings = function() {
      private$problemReport("warning")
    },
    messages = function() {
      private$problemReport("message")
    }
  ),
  private = list(
    # Private Properties
    filepath = NULL,
    active = TRUE,
    box_positions = NULL,
    collection_groups = c(),
    id_fields = NULL,
    manifest = NULL,
    manifest_fields = list(),
    oncore_data = NULL,
    oncore_protocols = NULL,
    problemList = list(error = c(), warning = c(), message = c()),
    project_dir = NULL,
    project_settings = NULL,
    protocol = NULL,
    pullsheet = NULL,
    manifest_settings = NULL,
    redcap_data = NULL,
    request_id = NULL,
    request_ids = c(),
    verbose = TRUE,

    #Private Methods
    ############################################################################
    addProblem = function(..., level = 'warning', stop_on_error = TRUE) {
      problem <- paste(list(...), collapse = "")
      private$problemList[[level]] <- c(private$problemList[[level]], problem)
      private$displayProblem(paste0("\n", problem, "\n"), level)
      if(level == "error" && stop_on_error) {
        private$active = FALSE
      }
    },
    ############################################################################
    createManifest = function() {

      query <- oncore2::oncore_connect(verbose = private$verbose, distinct = TRUE)
      if(length(private$manifest_fields$oncore_fields) > 0) {
        query <- oncore2::select_fields_(query, .dots = private$manifest_fields$oncore_fields)
      }
      if(length(private$manifest_fields$oncore_annotations) > 0) {
        query <- oncore2::select_annotations(query, .dots = private$manifest_fields$oncore_annotations)
      }
      query <- query %>%
        oncore2::filter_oncore(oncore2::value_in("SPECIMEN_REQUEST_ID", private$request_ids)) %>%
        oncore2::execute_query()

#      query$SPECIMEN_BAR_CODE[5] <- "0001112223" # Testing non-matching barcode

      query <- query %>%
        dplyr::mutate(VISIT = ifelse(PROTOCOL_NO == "MMGE-REF-POOL", "POOL", VISIT)) %>%
        dplyr::left_join(private$box_positions, by = "SPECIMEN_BAR_CODE")


      id_fields <- c(unlist(unname(private$project_settings$subject_ids)), "VISIT", "COLLECTION_GROUP")
      id_fields <- id_fields[id_fields %in% colnames(query)]

      if(length(private$manifest_fields$other_fields) > 0) {

        id_fields <- unique(unlist(unname(id_fields[id_fields %in% colnames(private$pullsheet)])))

        query <- query %>%
          dplyr::left_join(private$pullsheet %>% dplyr::select_(.dots=unique(c("SPECIMEN_BAR_CODE", id_fields, private$manifest_fields$other_fields))), by = id_fields) %>%
          dplyr::rename(SPECIMEN_BAR_CODE = SPECIMEN_BAR_CODE.x, PULLSHEET_BAR_CODE = SPECIMEN_BAR_CODE.y)

      }

      private$id_fields <- id_fields
      manifest <- list()

      for(cg in private$collection_groups) {
        fields <- unname(unlist(private$manifest_fields$final_fields[cg]))
        man <- query %>%
          dplyr::filter(COLLECTION_GROUP == cg)

        private$performChecks(cg, man)

        man <- man %>%
          dplyr::select(oncore2:::standardNames(fields))

        if("FINAL_BOX_POSITION" %in% colnames(man)) {
          man <- man %>% dplyr::arrange(FINAL_BOX_POSITION)
        }

        if("FINAL_BOX_NO" %in% colnames(man)) {
          man <- man %>% dplyr::arrange(FINAL_BOX_NO)
        }

        manifest[[cg]] <- man

      }

      private$manifest <- manifest

    },
    ############################################################################
    displayProblem = function(problem, level, check_verbose = TRUE) {
      style = switch(level,
                     error = function(...) crayon::bold(crayon::red(...)),
                     warning = function(...) crayon::bold(crayon::yellow(...)),
                     message = function(...) crayon::bold(crayon::blue(...))
      )
      if(check_verbose) {
        private$message(style(problem))
      } else {
        message(style(problem))
      }
    },
    ############################################################################
    getBoxPositions = function() {
      if(private$active) {
        bp_dir <- file.path(private$manifest_settings$lab_dir)
        dir.exists(bp_dir)
        project_dirs <- list.dirs(bp_dir, full.names = FALSE, recursive = FALSE)
        project_dir <- project_dirs[grepl(private$request_id, project_dirs, fixed = TRUE)]

        if(length(project_dir) > 1) {
          private$addProblem("Could not located Box Positions file because multiple directories match request_id: ", private$request_id, level = "error")
          private$active = FALSE
        } else if(length(project_dir) == 0) {
          private$addProblem("Could not located Box Positions file because no directories match request_id: ", private$request_id, level = "error")
          private$active = FALSE
        } else {
          private$addProblem("Using lab project directory: ", project_dir, level = "message")
          fp <- file.path(bp_dir, project_dir, "Manifest", "Files for making manifest")
          if(!dir.exists(fp)) {
            private$addProblem("No `Files for making manifest` folder found in project directory: ", project_dir, level = "error")
          } else {
            bp_files <- list.files(fp, pattern = "xlsx$")
            if(length(bp_files) == 0) {
              private$addProblem("No xlsx files found in `Files for making manifest` directory in project directory: ", project_dir, level = 'error')
            } else if(length(bp_files) > 1) {
              private$addProblem("Multiple xlsx files found in `Files for making manifest` directory in project directory: ", project_dir, level = 'error')
            } else {
              box_positions <- openxlsx::read.xlsx(file.path(fp, bp_files))
              if(all(c("Barcode", "Box.Name", "Position") %in% colnames(box_positions))) {
                private$box_positions <- box_positions %>%
                  dplyr::rename("SPECIMEN_BAR_CODE" = Barcode, "FINAL_BOX_NO" = Box.Name, "FINAL_BOX_POSITION" = Position)
              } else {
                private$addProblem("Missing column names in box positions file ", bp_files, ". Must contain 'Barcode', 'Box Name', and 'Position'.", level = "error")
              }
            }
          }
        }
      }
    },
    ############################################################################
    getManifestFields = function() {
      if(private$active) {

        settings <- mmgeProtocols::get_protocol_settings(private$protocol)

        raw_fields <- c(settings$manifest$default_fields, unname(unlist(settings$manifest$specimen_types[private$collection_groups])))
        fields <- unique(c(unlist(unname(private$project_settings$subject_ids)), "COLLECTION_GROUP", "SPECIMEN_STATUS", "PROTOCOL_NO", "SPECIMEN_REQUEST_ID"))
        annotations <- c()
        others <- c()
        final_fields <- c()

        build_field_name <- function(raw_field) {
          f <- raw_field
          if(grepl("^<.+>$", f)) {
            f <- gsub("<|>", "", f)
            v <- unname(unlist(eval(parse(text = paste0("settings$", f)))))
            if(!is.null(v)) {
              f <- v
            }
          }
          return(f)
        }

        for(i in seq_along(raw_fields)) {
          f <- build_field_name(raw_fields[i])
          if(f %in% oncore2::field_list$COLUMN_NAME) {
            fields <- unique(c(fields, f))
          } else if(f %in% oncore2::annotation_list$ANNOTATION) {
            annotations <- c(annotations, f)
          } else if(f %in% colnames(private$pullsheet)) {
            others <- c(others, f)
          } else {
            stop("Unrecognized manifest column ", f)
          }
        }

        default_fields <- sapply(settings$manifest$default_fields, build_field_name)

        for(cg in private$collection_groups) {

          manifest_fields <- c(default_fields, "FINAL_BOX_NO", "FINAL_BOX_POSITION")

          if("PULLSHEET_BOX_NO" %in% colnames(private$pullsheet)) {
            others <- c(others, "PULLSHEET_BOX_NO")
          }

          if("PULLSHEET_BOX_POSITION" %in% colnames(private$pullsheet)) {
            others <- c(others, "PULLSHEET_BOX_POSITION")
          }

          if("FINAL_RUN_NO" %in% colnames(private$pullsheet)) {
            manifest_fields <- c(manifest_fields, "FINAL_RUN_NO")
            others <- c(others, "FINAL_RUN_NO")
          }

          if("FINAL_RUN_POSITION" %in% colnames(private$pullsheet)) {
            manifest_fields <- c(manifest_fields, "FINAL_RUN_POSITION")
            others <- c(others, "FINAL_RUN_POSITION")
          }

          cg_fields <- sapply(settings$manifest$specimen_types[[cg]], build_field_name)

          if(length(cg_fields) > 0) {
            manifest_fields <- c(manifest_fields, cg_fields)
          }

          final_fields[[cg]] <- manifest_fields

        }

        private$manifest_fields <- list(
          oncore_fields = unique(fields),
          oncore_annotations = unique(annotations),
          other_fields = unique(others),
          final_fields = final_fields
        )

      }
    },
    ############################################################################
    getOnCoreData = function() {
      if(private$active) {
        if(is.null(private$redcap_data)) private$getRedCapData()
        private$message("Querying OnCore for Initial Manifest Information")
        oncore_data <- oncore2::oncore_connect(distinct = TRUE) %>%
          oncore2::select_fields(SPECIMEN_BAR_CODE, COLLECTION_GROUP, PROTOCOL_NO, SPECIMEN_REQUEST_ID) %>%
          oncore2::filter_oncore(oncore2::value_in("SPECIMEN_REQUEST_ID", private$request_ids)) %>%
          oncore2::execute_query()
        if(nrow(oncore_data) > 0) {
          private$message(nrow(oncore_data), " samples found in OnCore")
          private$oncore_data <- oncore_data
          cg <- private$oncore_data$COLLECTION_GROUP
          cg[cg=="BUFFY COAT"] = "DNA"
          cg = unique(cg)
          cg <- cg[!is.na(cg)]
          if(length(cg) > 0) {
            private$collection_groups = cg
            private$message("Collection Groups: ", paste(cg, collapse = ", "))
          } else {
            private$addProblem("Could not determine applicable COLLECTION GROUPs for Request ID ", private$request_id, level = "error")
          }
          # Check for protocol inconsistencies
          oncore_protocols <- unique(oncore_data$PROTOCOL_NO)
          non_ref_pool_protocols <- oncore_protocols[oncore_protocols != "MMGE-REF-POOL"]
          if(length(non_ref_pool_protocols) > 1) { # Is there more than one protocol (excluding MMGE-REF-POOL)
            private$addProblem("Multiple Non-Ref-Pool Protocols found for OnCore Request IDs: ", paste(non_ref_pool_protocols, collapse = ", "))
          } else if(length(non_ref_pool_protocols) == 1 && non_ref_pool_protocols != private$protocol) {
            private$addProblem("RedCap Protocol (", private$protocol, ") does not match OnCore Protocol (", non_ref_pool_protocols, ")")
          }
          private$oncore_protocols <- oncore_protocols
        } else {
          private$addProblem("Could not find any specimens in OnCore associated with Request ID(s): ", paste(private$request_ids, collapse = ", "), level = "error")
        }
      }
    },
    ############################################################################
    getProjectSettings = function() {
      if(is.null(private$project_dir)) {
        stop("No Project Directory Set")
      }
      private$project_settings <- get_manifest_config(private$project_dir)
    },
    ############################################################################
    getPullsheet = function() {
      if(private$active) {
        protocol_dir <- file.path(private$manifest_settings$pullsheet_dir, private$protocol)
        if(!dir.exists(protocol_dir)) {
          private$addProblem(private$protocol, " does not have a directory under Distributions")
        } else {
          project_dirs <- list.dirs(protocol_dir, recursive = FALSE)
          project_dir <- project_dirs[grepl(private$request_id, project_dirs, fixed = TRUE)]
          private$project_dir <- project_dir
          if(length(project_dir) == 0) {
            private$addProblem("Could not locate a project directory for Request #", level = 'error')
          } else if(length(project_dir) > 1) {
            private$addProlem("Could not identify a single project directory for Request #", level = 'error')
          } else {
            ps_dir <- file.path(project_dir, "Pullsheet")
            files <- list.files(ps_dir, pattern = paste0(".*", private$request_id, ".*\\.xlsx"))
            files <- files[!grepl("^~", files)] # I shouldn't need this but R regular expressions are weird and I don't know how to incorporate it...
            if(length(files) == 0) {
              private$addProblem("Could not identify a pullsheet directory for request #", level = 'error')
            } else {
              latest_date <- as.character(max(as.Date(unlist(regmatches(files, regexec("[0-9]{4}-[0-9]{2}-[0-9]{2}", files))))))
              pullsheet_file <- files[grepl(latest_date, files)]
              if(length(pullsheet_file) > 1) {
                private$addProblem("Could not identify a unique pullsheet for request #", level = 'error')
              } else {
                if(length(files) > 1) {
                  private$addProblem("Multiple pullsheets detected, using one with latest date: ", latest_date)
                }
                pullsheet <- try(openxlsx::read.xlsx(file.path(ps_dir, pullsheet_file), "Box"))
                if(inherits(pullsheet, "try-error")) {
                  private$active = FALSE
                  private$addProblem("Could not load `Box` tab in pullsheet file: ", pullsheet_file, level = "error")
                } else {
                  private$pullsheet <- openxlsx::read.xlsx(file.path(ps_dir, pullsheet_file), "Box") %>%
                    dplyr::rename(PULLSHEET_BOX_NO = FINAL_BOX_NO, PULLSHEET_BOX_POSITION = FINAL_BOX_POSITION)
                }
              }
            }
          }
        }
      }
    },
    ############################################################################
    getRedCapData = function() {
      if(private$active) {
        private$message("Getting Data from RedCap")
        data <- mmge::get_redcap_records("IUGB Distribution Tracking", paste0('[webform_request_num]=', private$request_id))
        if(length(data) > 0) {
          private$redcap_data = data
          private$protocol <- data$oncore_protocol_number
          if(is.null(private$protocol)) {
            private$active = FALSE
            private$addProblem("Could not find protocol in RedCap.", level = "error")
          } else {
            private$message("Protocol: ", private$protocol)
          }
          request_ids <- unique(unlist(private$redcap_data[colnames(private$redcap_data)[grepl("^oncore_request_num[[:digit:]]{1,2}", x = colnames(private$redcap_data))]]))
          request_ids <- request_ids[request_ids != ""]
          if(length(request_ids) > 0) {
            private$request_ids = request_ids
            private$message(length(request_ids), " OnCore Request ID(s) found: ", paste(request_ids, collapse = ", "))
          } else {
            private$active = FALSE
            private$addProblem("No OnCore Request IDs found in RedCap project", level = "error")
          }
          private$message("RedCap record found: ", data$record_id)
        } else {
          private$active = FALSE
          private$addProblem("Could not find RedCap record", level = "error")
        }
      }
    },
    ############################################################################
    message = function(...) {
      if(private$verbose) message(...)
    },
    ############################################################################
    performChecks = function(cg, man) {

      private$message("")
      private$message(crayon::green("#######################################################"))
      private$message(crayon::green("Beginning manifest checks for", cg))
      private$message(crayon::green("#######################################################"))
      private$message("")

      redcap_cg <- private$manifest_settings$collection_group_key[[cg]]$redcap
      oncore_st <- private$manifest_settings$collection_group_key[[cg]]$specimen_type
      volume <- private$redcap_data[[paste0('volume_', redcap_cg)]]
      aliquots <- as.numeric(private$redcap_data[[paste0('aliquots_', redcap_cg)]])
      requested_units <- regmatches(volume, regexpr("[[:alpha:]]+$", volume))
      requested_quantity <- as.numeric(regmatches(volume, regexpr("^[[:digit:]]+", volume)))

      # Samples – are the correct samples present – does the subject ID, Case No, Visit match what was on the pullsheet

      sub_vis_problem = FALSE

      ps_count = nrow(private$pullsheet)
      man_count = nrow(man)

      if(ps_count > man_count) {
        private$addProblem("Pullsheet has ", (ps_count - man_count), " more specimens than manifest.", level = 'error', stop_on_error = FALSE)
      } else if(man_count < ps_count) {
        private$addProblem("Manifest has ", (man_count - ps_count), " more specimens than pullsheet.", level = 'error', stop_on_error = FALSE)
      }

      pullsheet_fields <- unique(c(unlist(unname(private$project_settings$subject_ids)), "SPECIMEN_BAR_CODE", "VISIT"))
      pullsheet_fields <- pullsheet_fields[pullsheet_fields %in% names(private$pullsheet)]
      join_fields <- pullsheet_fields[pullsheet_fields != "SPECIMEN_BAR_CODE"]
      suppressMessages({
        pullsheet_samples <- private$pullsheet %>%
          dplyr::select(pullsheet_fields) %>%
          dplyr::rename(PULLSHEET_BAR_CODE = "SPECIMEN_BAR_CODE")
        manifest_samples <- man %>%
          dplyr::select(pullsheet_fields) %>%
          dplyr::rename(MANIFEST_BAR_CODE = "SPECIMEN_BAR_CODE")

        p_no_m <- pullsheet_samples %>%
          dplyr::anti_join(manifest_samples, by = join_fields)
        m_no_p <- manifest_samples %>%
          dplyr::anti_join(pullsheet_samples, by = join_fields)

      })

      if(nrow(p_no_m) > 0) {
        if(nrow(p_no_m) == 1) {
          private$addProblem("Subject/Visit from pullsheet not found in manifest: \n\n", textTable(p_no_m))
        } else {
          private$addProblem("Multiple Subject/Visits from pullsheet not found in manifest: \n\n", textTable(p_no_m))
        }
        sub_vis_problem = TRUE
      }

      if(nrow(m_no_p) > 0) {
        if(nrow(m_no_p) == 1) {
          private$addProblem("Subject/Visit from manifest not found in pullsheet: \n\n", textTable(m_no_p))
        } else {
          private$addProblem("Multiple Subject/Visits from manifest not found in pullsheet: \n\n", textTable(m_no_p))
        }
        sub_vis_problem = TRUE
      }

      if(!sub_vis_problem) {
        private$addProblem("\U2713 No issues found with SUBJECT VISITs in the manifest for ", cg, level = "message")
      }




      # Specimen Type – is this the same for all samples and what was requested
      specimen_type_problem = FALSE
      if(length(volume) == 0 || is.na(aliquots)) {
        private$addProblem(oncore_st, " manifest created, but not a requested specimen type in RedCap request", level = "error", stop_on_error = FALSE)
        specimen_type_problem = TRUE
      } else {

        if("COLLECTION_GROUP" %in% colnames(man)) {
          if(any(man$COLLECTION_GROUP != cg)) {
            bad_specimens <- man$SPECIMEN_BAR_CODE[man$COLLECTION_GROUP != cg]
            private$addProblem("Incorrect COLLECTION_GROUP found in ", cg, " manifest", level = "error", stop_on_error = FALSE)
            specimen_type_problem = TRUE
          }
        }

        if("SPECIMEN_TYPE" %in% colnames(man)) {
          if(any(man$SPECIMEN_TYPE != oncore_st)) {
            bad_specimens <- man$SPECIMEN_BAR_CODE[man$SPECIMEN_TYPE != oncore_st]
            private$addProblem("Incorrect SPECIMEN_TYPE found in ", cg, " manifest", level = "error", stop_on_error = FALSE)
            specimen_type_problem = TRUE
          }
        }
      }

      if(!specimen_type_problem) {
        private$addProblem("\U2713 No issues found with SPECIMEN_TYPE for ", cg, " manifest.", level = "message")
      }

      # Quantity – Does the quantity match the request? This is where I have found lower or higher volume aliquots used by accident
      quantity_problem <- FALSE
      manifest_quantities <- unique(man$SPECIMEN_QUANTITY)
      if(length(manifest_quantities) > 1) {
        # Allow a 10% variance to account for
        max_manifest_quantity <- max(manifest_quantities)
        min_manifest_quantity <- min(manifest_quantities)
        if(max(abs(max_manifest_quantity - requested_quantity), abs(min_manifest_quantity - requested_quantity)) / requested_quantity <= 0.1) {
          l = 'warning'
        } else {
          l = 'error'
        }
        private$addProblem("SPECIMEN_QUANTITY for ", cg, " manifest varies from ", min_manifest_quantity, " to ", max_manifest_quantity, ". RedCap request listed: ", requested_quantity, level = l, stop_on_error = FALSE)
        quantity_problem = TRUE
      } else {
        if(manifest_quantities != requested_quantity) {
          private$addProblem("SPECIMEN_QUANTITY for all ", cg, " specimens: ", manifest_quantities, "; RedCap request listed: ", requested_quantity, level = "error", stop_on_error = FALSE)
          quantity_problem = TRUE
        }
      }
      if(!quantity_problem) {
        private$addProblem("\U2713 All SPECIMEN_QUANTITYs for ", cg, " appear to be correct.", level = "message")
      }
      # Units of measure – Is this correct

      manifest_units <- unique(man$UNIT_OF_MEASURE)
      if(length(manifest_units) > 1) {
        private$addProblem("Multiple UNIT_OF_MEASUREs found in ", cg, " manifest: ", paste(manifest_units, collapse = ", "), level = "error", stop_on_error = FALSE)
      } else if(manifest_units != requested_units) {
        private$addProblem("Incorrect UNIT_OF_MEASUREs found in ", cg, " manifest: ", manifest_units, "; RedCap request: ", requested_units, level = "error", stop_on_error = FALSE)
      } else {
        private$addProblem("\U2713 All UNIT_OF_MEASUREs for ", cg, " appear to be correct.", level = 'message')
      }

      # Box Design – is everything in the correct boxes and positions as specified in the pullsheet

      box_design_errors <- FALSE

      missing_box_positions <- man %>%
        dplyr::filter(is.na(FINAL_BOX_NO) | is.na(FINAL_BOX_POSITION)) %>%
        dplyr::select_(.dots = c("SPECIMEN_BAR_CODE", private$id_fields))

      if(nrow(missing_box_positions) > 0) {
        private$active = FALSE
        private$addProblem("Could not identify Box Positions for ", nrow(missing_box_positions), ifelse(nrow(missing_box_positions) > 1, " samples:", " sample:"), "\n\n", textTable(missing_box_positions))
      } else {
        different_box_positions <- man %>%
          dplyr::filter(PULLSHEET_BOX_POSITION != FINAL_BOX_POSITION | PULLSHEET_BOX_NO != FINAL_BOX_NO) %>%
          dplyr::select_(.dots = c("SPECIMEN_BAR_CODE", private$id_fields, "PULLSHEET_BOX_NO", "FINAL_BOX_NO", "PULLSHEET_BOX_POSITION", "FINAL_BOX_POSITION"))
        if(nrow(different_box_positions) > 0) {
          private$active = FALSE
          private$addProblem("Some Box Positions do not match original Pullsheet Box Positions:\n\n", textTable(different_box_positions))
        } else {
          private$addProblem("\U2713 All specimen box positions match original pullsheet.", level = 'message')
        }
      }

      # Were reference pools included, if requested
      ref_pool <- private$redcap_data$reference_pools
      if(ref_pool != "") {
        if("MMGE-REF-POOL" %in% man$PROTOCOL_NO) {
          sub_field <- private$id_fields[!private$id_fields %in% c("VISIT", "COLLECTION_GROUP")]
          refpools <- man[man$PROTOCOL_NO == "MMGE-REF-POOL", sub_field, drop = FALSE] %>%
            dplyr::group_by_(.dots = sub_field) %>%
            dplyr::summarize(Count = n())
          colnames(refpools)[colnames(refpools) == sub_field] <- "Reference Pool"
          private$addProblem("RedCap Requested Reference Pools: `", ref_pool, "`, found the following reference pools in ", cg, " manifest:\n\n", textTable(refpools), level = 'message')
        } else {
          private$addProblem("RedCap Requested Reference Pools: `", ref_pool, "`. No reference pools found in ", cg, " manifest.")
        }
      } else {
        if("MMGE-REF-POOL" %in% man$PROTOCOL_NO) {
          sub_field <- private$id_fields[!private$id_fields %in% c("VISIT", "COLLECTION_GROUP")]
          refpools <- man[man$PROTOCOL_NO == "MMGE-REF-POOL", sub_field, drop = FALSE] %>%
            dplyr::group_by_(.dots = sub_field) %>%
            dplyr::summarize(Count = n())
          colnames(refpools)[colnames(refpools) == sub_field] <- "Reference Pool"
          private$addProblem("No reference pools requested in RedCap but reference pools found in ", cg, " manifest:\n\n", textTable(refpools))
        } else {
          private$addProblem("\U2713 No Reference Pools requested in RedCap and none found in ", cg, " manifest.", level = 'message')
        }
      }

    },
    problemReport = function(level) {
      report = function(level) {
        if(length(private$problemList[[level]] > 0)) {
          private$message("")
          private$message("### ", toupper(level), " REPORT ###")
          private$message("")
          for(problem in private$problemList[[level]]) {
            if(!is.null(problem)) {
              private$displayProblem(problem, level, FALSE)
            }
          }
        } else {
          private$message("No ", level, "s found.")
        }
      }
      if(missing(level)) {
        for(level in names(private$problemList)) {
          report(level)
        }
      } else {
        report(level)
      }
    }
  )
)

textTable <- function(df, vert_sep = "|", hori_sep = "-") {

  col_widths <- sapply(seq(ncol(df)), function(i) {
    max(c(nchar(colnames(df)[i]), nchar(df[, i])), na.rm = TRUE)
  })

  writeDivider <- function(table, vert_sep = vert_sep, hori_sep = hori_sep, seperated = TRUE) {
    if(seperated) {
      x <- paste0(vert_sep, paste(sapply(col_widths, function(w) paste(rep(hori_sep, times = w + 2), collapse = "")), collapse = vert_sep) , vert_sep)
    } else {
      table_width <- sum(col_widths) + (length(col_widths) * 3) + 1
      x <- paste(rep(hori_sep, times = table_width), collapse = "")
    }
    table <- c(table, x)
    return(table)
  }
  writeLine <- function(table, ..., cells) {
    if(missing(cells)) {
      cells <- list(...)
    }
    cells <- unname(unlist(cells))
    for(i in seq(length(cells))) {
      if(is.na(cells[i])) {
        cells[i] <- "NA"
      }
      padding <- (col_widths[i] - nchar(cells[i])) / 2
      padding <- c(floor(padding + 1), ceiling(padding + 1))
      cells[i] <- paste0(paste(rep(" ", times = padding[1]), collapse = ""), cells[i], paste(rep(" ", times = padding[2]), collapse = ""))
    }
    table <- c(table, (paste0(vert_sep, paste(cells, collapse = vert_sep), vert_sep)))
    return(table)
  }
  table <- c() %>%
    writeLine(colnames(df)) %>%
    writeDivider(hori_sep = "=", seperated = FALSE)

  for(r in seq(nrow(df))) {
    table <- writeLine(table, cells = unlist(df[r, ]))
  }

  table <- writeDivider(table, hori_sep = "-", seperated = FALSE)

  table <- paste(table, collapse = "\n")

  class(table) <- c("text_table", class(table))

  return(table)

}

print.text_table <- function(x) {
  cat(x)
  return(invisible(x))
}
