#'@export
get_reference_pools <- function(n, dir = ".") {

  config <- get_pullsheet_config(dir)

  fields <-  unique(c("SPECIMEN_NO", "SPECIMEN_STORAGE_LOCATION", "PARENT_SPECIMEN_ID",
               config$subject_ids$blinded, "COLLECTION_GROUP", "SPECIMEN_TYPE", "VISIT",
               "SPECIMEN_QUANTITY", "SPECIMEN_BAR_CODE", "SPECIMEN_STATUS", "PCS_SPECIMEN_ID",
               "SPECIMEN_COMMENTS", "CASE_NO", config$additional_oncore_fields))

  pool_query <- oncore2::oncore_connect(verbose = TRUE, query_name = paste0("reference_pools_", config$subject_ids$blinded)) %>%
    oncore2::select_fields_(.dots = fields) %>%
    oncore2::filter_oncore(oncore2::protocol("POOL"), oncore2::specimen_status("Available")) %>%
    oncore2::execute_query() %>%
    dplyr::mutate(VISIT = "POOL")

  return(pool_query)

}