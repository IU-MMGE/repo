#'@export
create_manifest <- function(pullsheet, protocol, specimen_request_id) {

  if(class(pullsheet) != "data.frame") {
    df <- openxlsx::read.xlsx(pullsheet)
  }

  get_guess_arguments <- function() {
    oncore2::oncore_connect(distinct = TRUE) %>%
      oncore2::select_fields(PROTOCOL_NO, SPECIMEN_REQUEST_ID) %>%
      oncore2::filter_oncore(oncore2::value_in("SPECIMEN_BAR_CODE", df$SPECIMEN_BAR_CODE[1:min(20, nrow(df))])) %>%
      oncore2::execute_query()
  }

  if(missing(protocol)) {

    message("Guessing protocol...")

    x <- get_guess_arguments()

    if(length(unique(x$PROTOCOL_NO)) == 1) {
      protocol <- unique(x$PROTOCOL_NO)
      message("Protocol: ", protocol)
    } else {
      stop("Could not guess PROTOCOL_NO")
    }

  }

  if(missing(specimen_request_id)) {

    if(!exists("x")) {
      x <- get_guess_arguments()
    }

    if(length(unique(x$SPECIMEN_REQUEST_ID)) == 1) {
      specimen_request_id <- unique(x$SPECIMEN_REQUEST_ID)
      message("SPECIMEN_REQUEST_ID: ", specimen_request_id)
    } else {
      stop("Could not guess SPECIMEN_REQUEST_ID")
    }

  }

  settings <- mmgeProtocols::get_protocol_settings(protocol)

  raw_fields <- unique(unname(unlist(settings$manifest)))
  fields <- c("COLLECTION_GROUP", "SPECIMEN_STATUS")
  annotations <- c()
  others <- c()
  manifest_fields <- c()

  build_field <- function(raw_field) {
    f <- raw_field
    if(grepl("^<.+>$", f)) {
      f <- gsub("<|>", "", f)
      v <- unname(unlist(eval(parse(text = paste0("settings$", f)))))
      if(!is.null(v)) {
        f <- v
      }
    }
    return(f)
  }

  for(i in seq_along(raw_fields)) {
    f <- build_field(raw_fields[i])
    if(f %in% oncore2::field_list$COLUMN_NAME) {
      fields <- c(fields, f)
    } else if(f %in% oncore2::annotation_list$ANNOTATION) {
      annotations <- c(annotations, f)
    } else if(f %in% colnames(df)) {
      others <- c(others, f)
    } else {
      stop("Unrecognized manifest column ", f)
    }
  }

  query <- oncore2::oncore_connect(verbose = TRUE, query_name = "manifest2", distinct = TRUE)
  if(length(fields) > 0) {
    query <- oncore2::select_fields_(query, .dots = unique(fields))
  }
  if(length(annotations) > 0) {
    query <- oncore2::select_annotations(query, .dots = unique(annotations))
  }

  query <- query %>%
    oncore2::filter_oncore(oncore2::protocol(protocol))

  if(length(unique(df$SPECIMEN_BAR_CODE)) < 1000) {
    query <- query %>%
      oncore2::filter_oncore(oncore2::value_in("SPECIMEN_BAR_CODE", df$SPECIMEN_BAR_CODE))
  }

  query <- query %>%
    oncore2::execute_query(execute = TRUE) %>%
    dplyr::full_join(df)

  if(length(unique(df$SPECIMEN_BAR_CODE)) >= 1000) {
    query <- query %>%
      dplyr::filter(SPECIMEN_BAR_CODE %in% df$SPECIMEN_BAR_CODE)
  }

  collection_groups <- unique(query$COLLECTION_GROUP)

  default_fields <- sapply(settings$manifest$default_fields, build_field)

  manifests <- list()

  for(cg in collection_groups) {

    manifest_fields <- default_fields
    cg_fields <- sapply(settings$manifest$specimen_types[[cg]], build_field)

    if(length(cg_fields) > 0) {
      manifest_fields <- c(manifest_fields, cg_fields)
    }

    manifest <- query %>%
      dplyr::filter(COLLECTION_GROUP == cg) %>%
      dplyr::select(oncore2:::standardNames(manifest_fields))

    manifests[[cg]] <- manifest

  }

  attributes(manifests) <- c(attributes(manifests), list(protocol = protocol, specimen_request_id = specimen_request_id, pullsheet = df))
  attr(manifests, "problems") <- c()
  attr(manifests, 'fields') <- fields
  attr(manifests, 'annotations') <- annotations
  class(manifests) <- c("manifest", class(manifests))

  return(manifests)

}
