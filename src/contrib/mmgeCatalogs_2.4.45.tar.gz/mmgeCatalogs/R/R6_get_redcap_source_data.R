R6_get_redcap_source_data <- function() {

  redcap <- mmge::get_redcap_report(
    private$config_obj$build$redcap_settings$study,
    private$config_obj$build$redcap_settings$report
  )


  if("preprocess_redcap" %in% ls(private$build_environment)) {
    redcap <- private$build_environment$preprocess_redcap(dplyr::ungroup(redcap), private$config_obj, private$dictionary_obj)
  }

  private$sources$redcap <- redcap

  return(invisible(self))

}

# redcap <- mmge::get_redcap_report(study = "NCRAD IPSC", report_id = 13925)
# redcap <- mmge::get_redcap_report(study = "PNRR", report_id = 38063)

