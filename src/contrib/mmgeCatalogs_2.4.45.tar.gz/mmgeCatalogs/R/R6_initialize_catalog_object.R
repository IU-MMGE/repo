# `protocol` determines the folder where config files are looked for. `.protocol` determines what protocol is filtered on in OnCore/Tesla if it is different
R6_initialize_catalog_object <- function(protocol, catalog_name = NULL,
                                         env = getOption('catalog_environment'),
                                         catalog_dir, dev = FALSE) {

  db <- debugR::debug('initialize')

  if(missing(protocol) & missing(catalog_dir)) {
      stop("Must provide either `protocol` or `catalog_dir` when creating a catalog object", call. = FALSE)
  }

  if(!missing(protocol)) {
    if(is.null(getOption('catalog_dir'))) {
      stop("If specifying protocol, you must set the `catalog_dir` option.", call. = FALSE)
    }
    self$protocol_dir <- file.path(getOption('catalog_dir'), protocol)
    self$catalog_dir <- file.path(self$protocol_dir, "Catalogs")
    if(!missing(catalog_dir)) {
      warning("Both `protocol` and `catalog_dir` were supplied. Ignoring `catalog_dir`...", call. = FALSE)
    }
    if(!is.null(catalog_name)) {
      self$catalog_dir <- file.path(self$catalog_dir, catalog_name)
    }
  } else if(!missing(catalog_dir)) {
    self$catalog_dir <- catalog_dir
    self$protocol_dir <- gsub("/Catalogs.*$", "", self$catalog_dir)
  }

  if(!dir.exists(self$protocol_dir)) {
    stop(self$protocol[1], " does not have a directory in ", getOption('catalog_dir'), call. = FALSE)
  }

  if(!dir.exists(self$catalog_dir)) {
    stop(self$protocol[1], " does not have a catalog directory at ", self$catalog_dir, call. = FALSE)
  }

  if(!env %in% c("PRD", "STG", "DEV")) {
    if(nchar(env) > 0) {
      stop("Invalid `env` argument. Must be one of `PRD`, `STG`, or `DEV`.", call. = FALSE)
    } else {
      stop("Invalid `env` argument. Did you set the `catalog_environment` option?", call. = FALSE)
    }
  }
  self$env <- env

  self$dev <- dev

  self$reload()

  if(!missing(protocol)) {
    if(!protocol %in% self$protocol[1]) {
      stop(crayon::white(glue::glue("The supplied protocol: {crayon::red(protocol)} does not match the protocol listed in `config.yaml`: {crayon::red(self$protocol[1])}")), call. = FALSE)
    }
  }

  if(!is.null(catalog_name)) {
    if(catalog_name != self$catalog_name) {
      stop(crayon::white(glue::glue("The supplied catalog_name: {crayon::red(catalog_name)} does not match the short_name listed in `config.yaml`: {crayon::red(self$catalog_name)}")), call. = FALSE)
    }
  }

  message("mmgeCatalog object created and linked to ", self$catalog_dir, ".")

  return(invisible(self))

}