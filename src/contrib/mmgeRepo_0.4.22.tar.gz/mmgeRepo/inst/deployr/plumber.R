library(plumber)
library(digest)

plumber::options_plumber(port = 3579)

#* @apiTitle R Package Deployment API

#* deployment endpoint
#* @post /
function(req, res) {

  authorized <- FALSE

  key <- Sys.getenv("webhook_key")
  if(key == "") {
    key <- getOption("mmgeRepo.webhook_key")
  }

  try({
    hash <- digest::hmac(key, req$postBody, algo = "sha1")
    gh_hash <- gsub("sha1=", "", req$HTTP_X_HUB_SIGNATURE)
    if(gh_hash == hash) {
      authorized <- TRUE
    }
  })

  if(!authorized) {
    res$status = 403
    return("Forbidden")
  }

  body <- jsonlite::fromJSON(req$postBody)
  if(!"ref" %in% names(body)) {
    res$status = 400
    return("This endpoint only processes push hooks")
  }

  branch <- ifelse(grepl("/dev$", body$ref), "dev", ifelse(grepl("/master$", body$ref), "master", body$ref))
  name <- body$repository$name
  url <- body$repository$ssh_url
  commit_message <- body$head_commit$message
  committer <- body$head_commit$author$username

  if(!branch %in% c("dev", "master")) {
    res$status <- 204
    return("This endpoint only processes pushes to `dev` or `master`")
  }

  if(branch == "dev") {
    drat_repo <- "dev-repo"
    drat_repo_url <- "git@github-dev-repo:IU-MMGE/dev-repo.git"
  } else {
    drat_repo <- "repo"
    drat_repo_url <- "git@github-prd-repo:IU-MMGE/repo.git"
  }

  td <- tempdir()
  cmd <- glue::glue("git -C '{td}' clone --branch {branch} {url}")
  message("Running `", cmd, "`")
  system(cmd, wait = TRUE)
  pkg_file <- devtools::build(file.path(td, name))

  version <- try(gsub(".tar.gz$", "", gsub(paste0(name, "_"), "", basename(pkg_file))))
  if(inherits(version, 'try-error')) {
    commit_msg <- glue::glue("{committer} updated {name} - ({commit_message})")
  } else {
    commit_msg <- glue::glue("{committer} updated {name} to version {version} - ({commit_message})")
  }

  cmd <- glue::glue("git -C '{td}' clone --branch gh-pages {drat_repo_url}")
  message("Running `", cmd, "`")
  system(cmd, wait = TRUE)

  message("Beginning drat process...")
  drat::insertPackage(pkg_file, repo = file.path(td, drat_repo), commit=FALSE)
  drat::pruneRepo(repo = file.path(td, drat_repo), remove = TRUE)
  message("Pushing updated repo...")
  system(glue::glue("git -C '{file.path(td, drat_repo)}' add -A"), wait = TRUE)
  system(glue::glue("git -C '{file.path(td, drat_repo)}' commit -m '{commit_msg}'"), wait = TRUE)
  system(glue::glue("git -C '{file.path(td, drat_repo)}' push"), wait = TRUE)

  return(commit_msg)

}