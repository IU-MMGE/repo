#'@export
finalize_pull_sheet <- function(pull, dir = ".") {

  config <- get_pullsheet_config(dir)


  return(invisible(pull))

}