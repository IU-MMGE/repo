#'@export

choose_dna = function(data){
  require(dplyr)
  data = data%>%
    filter(SPECIMEN_TYPE%in%c("Nucleic Acids","Saliva","Buffy Coat","Whole Blood")&
             (is.na(NUCLEIC_ACID_DERIVATIVE)|NUCLEIC_ACID_DERIVATIVE=="DNA"|
                NUCLEIC_ACID_DERIVATIVE=="")&
             (is.na(COLLECTION_GROUP)|COLLECTION_GROUP!="RNA"|COLLECTION_GROUP==""))%>%
    mutate(sort = ifelse(SPECIMEN_TYPE=="Nucleic Acids","A",
                         ifelse(SPECIMEN_TYPE=="Buffy Coat","B","Z")))%>%
    arrange(sort)
  return(data)
}
