# get_oncore_id <- function(request, ask = FALSE) {
#
#   oncore_id <- regmatches(request$desc, gregexpr("oncore.*?([0-9]{5})", request$desc, ignore.case = TRUE))[[1]]
#
#   if(length(oncore_id) > 0) {
#     oncore_id <- oncore_id[nchar(oncore_id) == min(nchar(oncore_id))]
#     oncore_id <- as.numeric(regmatches(oncore_id, regexec("[0-9]{5}", oncore_id))[[1]])
#   } else {
#     if(ask) {
#       oncore_id <- ask_for_value(request$subject, request$desc, "OnCore Request ID")
#     } else {
#       oncore_id <- NULL
#     }
#   }
#
#   return(oncore_id)
#
# }
#
# get_oncore_protocol <- function(request, ask = FALSE) {
#
#   desc <- paste(request$subject, request$desc, sep = "\n")
#
#   re <- "[[[A-Z|0-9]-]+]+[A-Z|0-9]"
#
#   re <- "([A-Z|0-9]+-){2,}[A-Z|0-9]+"
#   protocol <- regmatches(desc, regexpr(re, desc))[[1]]
# #  protocol <- regmatches(desc, regexec("MMGE[A-Z|0-9|-]+", desc))[[1]]
#
#   if(length(protocol) == 0) {
#     if(ask) {
#       protocol <- ask_for_value(request$subject, request$desc, "Protocol")
#     } else {
#       protocol <- NULL
#     }
#   }
#
#   return(protocol)
#
# }
#
# get_project_name <- function(request, ask = FALSE) {
#
#   desc <- paste(request$subject, request$desc, sep = "\n\n")
#   project_name = NULL
#   project_keywords <- c("Project Name", "Investigator", "PI")
#   cnt = 1
#   while(length(project_name) == 0 & cnt <= length(project_keywords)) {
#     regex = paste0(project_keywords[cnt], "(\\s|:\\s|:)([A-Z]|[0-9]|\\s)+?\\n")
#     project_name <- regmatches(desc, gregexpr("Investigator(\\s|:\\s|:)([A-Z]|[0-9]|\\s)+?\\n", desc, ignore.case = TRUE))[[1]]
#     cnt = cnt + 1
#   }
#   if(length(project_name) == 0) {
#     pn <- request$subject
#     pn <- gsub("Pull|sheet|pullsheet|Box|design", "", pn, ignore.case = TRUE)
#     pn <- gsub('[[:punct:]]', "", pn)
#     pn <- trimws(pn)
#     pn <- gsub(" ", "_", pn)
#     if(ask) {
#       project_name <- ask_for_value(request$subject, request$desc, "Project Name", pn)
#     }
#   }
#
#   project_name <- gsub(paste0(project_keywords[cnt], "(\\s|:\\s|:)"), "", project_name, ignore.case = TRUE)
#   project_name <- gsub("\\n", "", project_name)
#   project_name <- trimws(project_name)
#
#   return(project_name)
#
# }
#
# get_collection_groups <- function(request, ask = FALSE) {
#
#   desc <- paste(request$subject, request$desc, sep = "\n\n")
#
#   cg <- unique(toupper(regmatches(desc, gregexpr("dna|rna|pbmc|plasma|serum|csf|urine", desc, ignore.case = TRUE))[[1]]))
#
#   if(length(cg) == 0) {
#     if(ask) {
#       cg <- toupper(ask_for_value(request$subject, request$desc, "COLLECTION_GROUP"))
#     } else {
#       cg <- ""
#     }
#   }
#
#   return(cg)
#
# }
#
# get_order_dir <- function(request) {
#
#   base_dir <- file.path("/media", "distributions")
#
#   if(!missing(request)) {
#     return(file.path(base_dir, mmge::protocol_match(request$protocol), request$order_name))
#   } else {
#     return(base_dir)
#   }
#
# }
#
# ask_for_value <- function(subject = "Request Value", desc, type, default = NULL) {
#
#   if(rstudioapi::isAvailable()) {
#     msg <- paste0("SUBJECT: ", subject,"<br />DESCRIPTION:\n-\n", desc, "\\n-\\n", "Please identify the ", type, ":")
#     x <- rstudioapi::showPrompt(paste0("Unable to identify ", type), msg, default)
#     if(is.null(x)) x = ""
#   } else {
#     desc <- paste(subject, desc, sep = "\n")
#     cat(desc)
#     x <- readline(sprintf("Unable to identify %s: ", type))
#   }
#
#   if(x == "") stop("Must provide ", type, call. = FALSE)
#   return(x)
#
# }
#
# get_footprints_email_subject <- function(ticket) {
#   sprintf("%s ISSUE=%s PROJ=161", ticket$subject, as.character(ticket$number))
# }