#'@export
design_box.1 = function(pull,aliquot,extract,combine, balance_vars, box_size, subject_id,maximize_fullness = T,
                        dir = ".", verbose = FALSE, iterations=5, calibrate=0.001,visit=T,visit_type="VISIT",number_of_children=1,
                        box_design_name = "box_design_beta",previous_box_design = 0){

  statlist=c()
  stat_list = data.frame()
  stat=c()
  fullness = c()
  box_design1=c()
  box_design_list=list()
  maxlist=c()

  config = mmgeDistributions:::get_pullsheet_config(dir)

  if(missing(subject_id)) {
    subject_id <- config$subject_ids$blinded
  }

  if(missing(box_size)) {
    box_size <- config$box_size
  }

  if(missing(balance_vars)) {
    balance_vars = config$balance_vars
  }

  if(!is.data.frame(previous_box_design)){
    if(!missing(pull)) {
      if(nrow(pull)>0){
        pull <- dplyr::ungroup(pull)
      } else{pull = NULL}
    } else{
      pull = NULL
    }
    if(!missing(aliquot)) {
      if(nrow(aliquot)>0){
        aliquot <- dplyr::ungroup(aliquot)
        aliquot_test = mmgeDistributions::split_aliquots(aliquot,number_of_children)
      } else{aliquot_test=NULL}

    } else{
      aliquot_test = NULL
    }
    if(!missing(extract)) {
      if(nrow(extract)>0){
        extract <- dplyr::ungroup(extract)
        extract_test = mmgeDistributions::split_aliquots(extract,number_of_children)
      } else{extract_test=NULL}

    } else{
      extract_test = NULL
    }
    if(!missing(combine)) {
      if(nrow(combine)>0){
        combine <- dplyr::ungroup(combine)%>%
          group_by(CASE_NO)%>%
          filter(row_number()==1)%>%
          ungroup()
      } else{combine=NULL}

    } else{
      combine = NULL
    }
    if(visit==F){
      box_design <- dplyr::bind_rows(pull,aliquot_test,extract_test,combine) %>%
        dplyr::distinct_(.dots = c(subject_id, visit_type), .keep_all = TRUE) %>%
        dplyr::select_(.dots = c(subject_id,visit_type, balance_vars)) %>%
        dplyr::group_by_(.dots = c(subject_id,visit_type, balance_vars)) %>%
        dplyr::summarise(VISITS = n()) %>%
        dplyr::arrange_(.dots = balance_vars) %>%
        dplyr::mutate(FINAL_RUN_NO = 0)
    }
    if(visit==T){
      box_design <- dplyr::bind_rows(pull,aliquot_test,extract_test,combine) %>%
        dplyr::distinct_(.dots = c(subject_id, visit_type), .keep_all = TRUE)%>%
        dplyr::select_(.dots = c(subject_id,visit_type, balance_vars)) %>%
        dplyr::group_by_(.dots = c(subject_id, balance_vars)) %>%
        dplyr::summarise(VISITS = n()) %>%
        dplyr::arrange_(.dots = balance_vars) %>%
        dplyr::mutate(FINAL_RUN_NO = 0)
    }
  }

  if(is.data.frame(previous_box_design)){
    box_design = previous_box_design
  }

  boxes = ceiling(sum(box_design$VISITS)/box_size)


  for (l in 1:iterations){
    tim = proc.time()
    itr = paste("Iteration #",l,sep=" ")
    message("")
    message(itr)
    message("")
    box_design = box_design[sample(nrow(box_design)),]
    #for (k in 1:length(unique(box_design[,balance_vars]))){
    #maxlist[k]=sum(box_design$VISITS[which(box_design[,balance_vars]==as.character(unique(box_design[k,balance_vars])))])/(sum(box_design$VISITS))*box_size
    #}

    for (i in 1:nrow(box_design)){
      time = proc.time()
      for (j in 1:boxes){
        box_design$FINAL_RUN_NO[i]=j
        statlist[j]=calc_score(box_design,balance_vars = balance_vars,box_size=box_size,calibrate=calibrate,maximize_fullness = maximize_fullness)
      }
      box_design$FINAL_RUN_NO[i]=which.min(statlist)
      time2 = proc.time()-time
      time3 = tim+time2*nrow(box_design)
      eta = paste("Row",i,"completed","(",ceiling((time3-proc.time())/60)["elapsed"],"minutes left",")",sep=" ")
      message(eta)
    }
    box_design_list[[l]]=box_design%>%mutate(FINAL_BOX_NO=1)
    if(box_design_name!=""){
      assign(box_design_name,box_design_list,envir = globalenv())
    }
  }
  for (i in 1:iterations){
    box_design1[i]=calc_score(box_design_list[[i]],balance_vars = balance_vars,box_size=box_size,calibrate=calibrate,maximize_fullness = maximize_fullness)
  }
  boxy = box_design_list[[which.min(box_design1)]]
  boxy$FINAL_BOX_NO = boxy$FINAL_RUN_NO
  boxy = boxy%>%
    arrange_(.dots=c("FINAL_RUN_NO",subject_id))
  return(boxy)
}

calc_score = function(box_design,balance_vars,box_size,calibrate,maximize_fullness){
  boxes = ifelse(maximize_fullness == T,ceiling(sum(box_design$VISITS)/box_size),ceiling(sum(box_design$VISITS)/box_size)+1)
  full = rep(box_size,(boxes-1))
  fullness = data.frame()
  stat=data.frame()
  final = c()
  fullness_score = data.frame()
  for (m in 1:length(balance_vars)){
    maxlist=c()
    stat_list = data.frame()
    for (k in 1:nrow(unique(box_design[,balance_vars[[m]]]))){
      maxlist[k]=sum(box_design$VISITS[which(box_design[,balance_vars[m]]==as.character(unique(box_design[,balance_vars[m]])[k,]))])/(sum(box_design$VISITS))*box_size
    }

    for (j in 1:nrow(unique(box_design[,balance_vars[m]]))){
      for (h in 1:(boxes-1)){
        stat_list[h,j] = sum(box_design$VISITS[which(box_design$FINAL_RUN_NO==h&box_design[,balance_vars[m]]==as.character(unique(box_design[,balance_vars[m]])[j,]))])
      }
    }
    for (h in 1:(boxes-1)){
      stat[m,h]=sum((maxlist-stat_list[h,])^2)
    }
    for(i in 1:(boxes-1)){
      fullness[m,i] = sum(box_design$VISITS[which(box_design$FINAL_RUN_NO==i)])
    }
    for (p in 1:(boxes-1)){
      fullness_score[m,p] = calibrate*sum((box_size-fullness[m,p])^2)
    }
    final[m] = sum(stat[m,])+sum(fullness_score[m,])
  }

  return(sum(final))
}


#'@export
box_design_summary <- function(box_design,balance_vars,subject_id,multiple_per_visit=FALSE) {

  s = list()
  sc = list()
  if("list"%in%class(box_design)){

    eval(parse(text = paste0("ss = list(",paste0(rep("list()",length(box_design)),collapse = ","),")")))

    box_number = length(box_design)
  } else{
    eval(parse(text = paste0("ss = list(",paste0(rep("list()",1),collapse = ","),")")))

    box_number = 1
  }
  for(j in 1:box_number){

    if("list"%in%class(box_design)){
      box = box_design[[j]]
    } else{
      box = box_design
    }

    for(i in seq(length(balance_vars))) {
      if(multiple_per_visit==T){
        box = box%>%
          ungroup()%>%
          group_by_(.dots=c(subject_id,"VISIT"))%>%
          filter(row_number()==1)%>%
          ungroup()
        s[[i]] <- box %>%
          dplyr::group_by_(.dots = c("FINAL_RUN_NO", balance_vars[i])) %>%
          dplyr::summarize(Count = n()) %>%
          reshape2::dcast(reformulate(balance_vars[i], "FINAL_RUN_NO"), value.var = "Count") %>%
          dplyr::mutate(TOTAL = rowSums(., na.rm = TRUE) - FINAL_RUN_NO)
      }
      else{
        s[[i]] <- box %>%
          dplyr::group_by_(.dots = c("FINAL_RUN_NO", balance_vars[i])) %>%
          dplyr::summarize(Count = sum(VISITS)) %>%
          reshape2::dcast(reformulate(balance_vars[i], "FINAL_RUN_NO"), value.var = "Count") %>%
          dplyr::mutate(TOTAL = rowSums(., na.rm = TRUE) - FINAL_RUN_NO)
      }


      sc[[i]] <- c("TOTAL", colSums(s[[i]][2:ncol(s[[i]])], na.rm = TRUE))

      s[[i]] <- rbind(s[[i]],sc[[i]])
      ss[[j]][[i]] = s[[i]]

    }
  }

  return(ss)

}
