#'@export
#leave rows at end of box_design
specify_rows = function(box_design,empty_row_num,sample_num){
  box_design1 = box_design%>%
    ungroup()%>%
    mutate(FINAL_BOX_POSITION=row_number())%>%
    mutate(FINAL_BOX_POSITION = FINAL_BOX_POSITION+empty_row_num*(FINAL_BOX_POSITION-1)%/%sample_num)
  return(box_design1)
}
