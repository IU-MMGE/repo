#'@export


arrange_dcr = function(pull){
  pull = pull%>%
    arrange(ReferencedTable,DNAStatus,DNASource,DCRDateRemoved,IsBackup,Available,desc(Yieldug))
  return(pull)
}
