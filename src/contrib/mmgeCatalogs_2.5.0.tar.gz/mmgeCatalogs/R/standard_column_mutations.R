standardColumnMutations <- list(
  specimen_type = function(df, dict) {
    fields <- df$SPECIMEN_TYPE
    fields[fields == "Nucleic Acids"] <- df$COLLECTION_GROUP
    fields[fields == "Buffy Coat"] <- "DNA"
    if('recode' %in% names(dict)) {
      fields <- dplyr::recode(fields, dict$recode)
    }
  }
)