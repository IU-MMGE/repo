#'@export

dia = function(query,cg,grouping){
  require(dplyr)
  query = query%>%ungroup()
  if(!missing(grouping)){
    query = query%>%group_by(.data[[grouping]])
  }
  if(missing(cg)){
    num_rows = nrow(query)
    num_samples = nrow(query%>%distinct(SPECIMEN_BAR_CODE))
    num_subjects = length(unique(query$PATIENT_ID))
    num_cases = length(unique(query$CASE_NO))
    num_subj_visit_pairs = nrow(unique(query[,c("PATIENT_ID","VISIT")]))
    na_storage_loc = nrow(query[is.na(query$SPECIMEN_STORAGE_LOCATION),])
    na_specimen_quantity = nrow(query[is.na(query$SPECIMEN_QUANTITY),])
    num_comments = nrow(query[!(is.na(query$SPECIMEN_COMMENTS)|query$SPECIMEN_COMMENTS==""),])
    na_visits = nrow(query[(is.na(query$VISIT)|query$VISIT==""),])

    f = query
    f$SPECIMEN_QUANTITY = ifelse(f$SPECIMEN_QUANTITY<200,"Residual",ifelse(f$SPECIMEN_QUANTITY>200&!f$SPECIMEN_QUANTITY%in%c(250,500,750,1000,1500,2000,3000,5000,6000),"Parent Resid",f$SPECIMEN_QUANTITY))
    quantities = count(f,SPECIMEN_QUANTITY)%>%arrange(SPECIMEN_QUANTITY)
    #make hist of quantities
    x = data.frame(
      `Rows` = num_rows,
      `Samples` = num_samples,
      `Subjects` = num_subjects,
      `Cases` = num_cases,
      `Subj_Visit_Pairs` = num_subj_visit_pairs,
      `NA_Storage` = na_storage_loc,
      `NA_Quantities` = na_specimen_quantity,
      `NA_Visits` = na_visits

    )
    y = unique(query[,c("COLLECTION_GROUP","SPECIMEN_TYPE")])
    z = table(query$SPECIMEN_STATUS)
    w = quantities
    return(list(x,y,z,w))
  } else{
    query = query%>%filter(COLLECTION_GROUP==cg)
    num_rows = nrow(query)
    num_samples = nrow(query%>%distinct(SPECIMEN_BAR_CODE))
    num_subjects = length(unique(query$PATIENT_ID))
    num_cases = length(unique(query$CASE_NO))
    num_subj_visit_pairs = nrow(unique(query[,c("PATIENT_ID","VISIT")]))
    na_storage_loc = nrow(query[is.na(query$SPECIMEN_STORAGE_LOCATION),])
    na_specimen_quantity = nrow(query[is.na(query$SPECIMEN_QUANTITY),])
    num_comments = nrow(query[!(is.na(query$SPECIMEN_COMMENTS)|query$SPECIMEN_COMMENTS==""),])
    na_visits = nrow(query[(is.na(query$VISIT)|query$VISIT==""),])

    f = query
    f$SPECIMEN_QUANTITY = ifelse(f$SPECIMEN_QUANTITY<200,"Residual",ifelse(f$SPECIMEN_QUANTITY>200&!f$SPECIMEN_QUANTITY%in%c(250,500,750,1000,1500,2000,3000,5000,6000),"Parent Resid",f$SPECIMEN_QUANTITY))
    quantities = count(f,SPECIMEN_QUANTITY)%>%arrange(SPECIMEN_QUANTITY)
    #make hist of quantities
    x = data.frame(
      `Rows` = num_rows,
      `Samples` = num_samples,
      `Subjects` = num_subjects,
      `Cases` = num_cases,
      `Subj_Visit_Pairs` = num_subj_visit_pairs,
      `NA_Storage` = na_storage_loc,
      `NA_Quantities` = na_specimen_quantity,
      `NA_Visits` = na_visits

    )
    y = f%>%count(COLLECTION_GROUP,SPECIMEN_TYPE,SPECIMEN_QUANTITY)%>%
      arrange(SPECIMEN_TYPE)
    z = table(query$SPECIMEN_STATUS)
    w = quantities
    return(list(x,y,z,w))
  }


}

#'@export
depletion_test = function(pull1,query,record_id,level,dir = "."){
  if(missing(record_id)){
    record_id = get_pullsheet_config(dir)$record_id
  }
  if(is.null(record_id)){
    record_id = 0
  }
  if(record_id==0){
    return("No record ID found")
  } else{
    if(missing(level)){
      rcon = redcapAPI::redcapConnection(url = "https://redcap.uits.iu.edu/api/",token = "AAAAA96CCB080D300451B4976E75A624")
      table = redcapAPI::exportRecords(rcon,records = record_id)
      level = as.numeric(gsub("ul","",table$minimum_retain_qnty,fixed = TRUE))
      print(paste0("Depletion Level recorded as: '",level,"'"))
    }

    if(is.na(level)){
      return("No depletion requirements")
    } else{
      sum = query2%>%
        semi_join(pull1,by=c("CASE_NO","COLLECTION_GROUP","SPECIMEN_TYPE"))%>%
        filter(SPECIMEN_STATUS=="Available"&!is.na(SPECIMEN_QUANTITY))%>%
        group_by(CASE_NO,COLLECTION_GROUP,SPECIMEN_TYPE)%>%
        arrange(SPECIMEN_QUANTITY)%>%
        mutate(TOTAL_VOLUME = sum(SPECIMEN_QUANTITY))%>%
        select(PATIENT_ID,CASE_NO,COLLECTION_GROUP,SPECIMEN_TYPE,TOTAL_VOLUME)%>%
        distinct()
      if(min(sum$TOTAL_VOLUME,na.rm=TRUE)<level){
        return(sum%>%filter(TOTAL_VOLUME<level))
      } else{
        return("Requirements met")
      }
    }

  }

}


