#'@export
design_box.2 = function(pull,aliquot,extract,combine, balance_vars, box_size, subject_id,maximize_fullness = T,
                        dir = ".", verbose = FALSE, iterations=5, calibrate=0.001,visit=T,visit_type="VISIT",number_of_children=1){
  config = mmgeDistributions:::get_pullsheet_config(dir)

  if(missing(subject_id)) {
    subject_id <- config$subject_ids$blinded
  }

  if(missing(box_size)) {
    box_size <- config$box_size
  }

  if(missing(balance_vars)) {
    balance_vars = config$balance_vars
  }


  if(missing(pull)){
    pull = data.frame(matrix(ncol=2,nrow=0))
    colnames(pull) = c(subject_id,"FINAL_RUN_NO")
    pull[,1] = as.character(pull[,1])
    pull[,2] = as.numeric(pull[,2])

  } else{
    pull = ungroup(pull)
  }
  if(missing(aliquot)){
    aliquot = data.frame(matrix(ncol=2,nrow=0))
    colnames(aliquot) = c(subject_id,"FINAL_RUN_NO")
    aliquot[,1] = as.character(aliquot[,1])
    aliquot[,2] = as.numeric(aliquot[,2])
  }
  if(missing(extract)){
    extract = data.frame(matrix(ncol=2,nrow=0))
    colnames(extract) = c(subject_id,"FINAL_RUN_NO")
    extract[,1] = as.character(extract[,1])
    extract[,2] = as.numeric(extract[,2])
  }
  if(missing(combine)){
    combine = data.frame(matrix(ncol=2,nrow=0))
    colnames(combine) = c(subject_id,"FINAL_RUN_NO")
    combine[,1] = as.character(combine[,1])
    combine[,2] = as.numeric(combine[,2])
  }
  nsamples = function(nrow,box_size,splits){
    return(ceiling(nrow/box_size/splits)*box_size)
  }



  nrow = nrow(pull)+nrow(aliquot)*number_of_children+nrow(extract)*number_of_children+nrow(combine)


  n2samples = nsamples(nrow,box_size,2)


  b1 = design_box(pull = pull,aliquot = aliquot,extract = extract,combine = combine, balance_vars=balance_vars, box_size=n2samples, subject_id,maximize_fullness = maximize_fullness,
                  dir =dir, verbose = verbose,  calibrate=calibrate,visit=visit,visit_type=visit_type,
                  number_of_children=number_of_children)

  n4samples = nsamples(nrow,box_size,4)
  b2 = list()
  for(i in 1:2){
    b2[[i]] = design_box(pull = pull%>%semi_join(b1%>%filter(FINAL_RUN_NO==i),by=c(subject_id)),aliquot = aliquot%>%semi_join(b1%>%filter(FINAL_RUN_NO==i),by=c(subject_id)),
                      extract = extract%>%semi_join(b1%>%filter(FINAL_RUN_NO==i),by=c(subject_id)),combine = combine%>%semi_join(b1%>%filter(FINAL_RUN_NO==i),by=c(subject_id)),
                      balance_vars, box_size=n4samples, subject_id,maximize_fullness = maximize_fullness,
                      dir =dir, verbose = verbose,  calibrate=calibrate,visit=visit,visit_type=visit_type,
                      number_of_children=number_of_children)
  }

  n8samples = nsamples(nrow,box_size,8)
  b3 = list()
  for(i in 1:4){
    if(i==1){j=1;k=1}
    if(i==2){j=1;k=2}
    if(i==3){j=2;k=1}
    if(i==4){j=2;k=2}

    b3[[i]] = design_box(pull = pull%>%semi_join(b2[[j]]%>%filter(FINAL_RUN_NO==k),by=c(subject_id)),aliquot = aliquot%>%semi_join(b2[[j]]%>%filter(FINAL_RUN_NO==k),by=c(subject_id)),
                         extract = extract%>%semi_join(b2[[j]]%>%filter(FINAL_RUN_NO==k),by=c(subject_id)),combine = combine%>%semi_join(b2[[j]]%>%filter(FINAL_RUN_NO==k),by=c(subject_id)),
                         balance_vars, box_size=n8samples, subject_id,maximize_fullness = maximize_fullness,
                         dir =dir, verbose = verbose,  calibrate=calibrate,visit=visit,visit_type=visit_type,
                         number_of_children=number_of_children)
  }
  n16samples = nsamples(nrow,box_size,16)
  b4 = list()
  for(i in 1:8){
    if(i==1){j=1;k=1}
    if(i==2){j=1;k=2}
    if(i==3){j=2;k=1}
    if(i==4){j=2;k=2}
    if(i==5){j=3;k=1}
    if(i==6){j=3;k=2}
    if(i==7){j=4;k=1}
    if(i==8){j=4;k=2}

    b4[[i]] = design_box(pull = pull%>%semi_join(b3[[j]]%>%filter(FINAL_RUN_NO==k),by=c(subject_id)),aliquot = aliquot%>%semi_join(b3[[j]]%>%filter(FINAL_RUN_NO==k),by=c(subject_id)),
                         extract = extract%>%semi_join(b3[[j]]%>%filter(FINAL_RUN_NO==k),by=c(subject_id)),combine = combine%>%semi_join(b3[[j]]%>%filter(FINAL_RUN_NO==k),by=c(subject_id)),
                         balance_vars, box_size=n16samples, subject_id,maximize_fullness = maximize_fullness,
                         dir =dir, verbose = verbose,  calibrate=calibrate,visit=visit,visit_type=visit_type,
                         number_of_children=number_of_children)
  }

  # b2.1 = design_box(pull = pull%>%semi_join(b1%>%filter(FINAL_RUN_NO==1),by=c(subject_id)),aliquot = aliquot%>%semi_join(b1%>%filter(FINAL_RUN_NO==1),by=c(subject_id)),
  #                     extract = extract%>%semi_join(b1%>%filter(FINAL_RUN_NO==1),by=c(subject_id)),combine = combine%>%semi_join(b1%>%filter(FINAL_RUN_NO==1),by=c(subject_id)),
  #                     balance_vars, box_size=n4samples, subject_id,maximize_fullness = maximize_fullness,
  #                   dir =dir, verbose = verbose,  calibrate=calibrate,visit=visit,visit_type=visit_type,
  #                   number_of_children=number_of_children)
  # b2.2 = design_box(pull = pull%>%semi_join(b1%>%filter(FINAL_RUN_NO==2),by=c(subject_id)),aliquot = aliquot%>%semi_join(b1%>%filter(FINAL_RUN_NO==2),by=c(subject_id)),
  #                     extract = extract%>%semi_join(b1%>%filter(FINAL_RUN_NO==2),by=c(subject_id)),combine = combine%>%semi_join(b1%>%filter(FINAL_RUN_NO==2),by=c(subject_id)),
  #                     balance_vars, box_size=n4samples, subject_id,maximize_fullness = maximize_fullness,
  #                   dir =dir, verbose = verbose,  calibrate=calibrate,visit=visit,visit_type=visit_type,
  #                   number_of_children=number_of_children)
#
#
#   b3.1 = design_box.1(pull = pull%>%semi_join(b2.1%>%filter(FINAL_RUN_NO==1),by=c(subject_id)),aliquot = aliquot%>%semi_join(b2.1%>%filter(FINAL_RUN_NO==1),by=c(subject_id)),
#                       extract = extract%>%semi_join(b2.1%>%filter(FINAL_RUN_NO==1),by=c(subject_id)),combine = combine%>%semi_join(b2.1%>%filter(FINAL_RUN_NO==1),by=c(subject_id)),
#                       balance_vars, box_size=box_size, subject_id,maximize_fullness = maximize_fullness,
#                       dir =dir, verbose = verbose, iterations=iterations, calibrate=calibrate,visit=visit,visit_type=visit_type,
#                       number_of_children=number_of_children)
#   b3.2 = design_box.1(pull = pull%>%semi_join(b2.1%>%filter(FINAL_RUN_NO==2),by=c(subject_id)),aliquot = aliquot%>%semi_join(b2.1%>%filter(FINAL_RUN_NO==2),by=c(subject_id)),
#                       extract = extract%>%semi_join(b2.1%>%filter(FINAL_RUN_NO==2),by=c(subject_id)),combine = combine%>%semi_join(b2.1%>%filter(FINAL_RUN_NO==2),by=c(subject_id)),
#                       balance_vars, box_size=box_size, subject_id,maximize_fullness = maximize_fullness,
#                       dir =dir, verbose = verbose, iterations=iterations, calibrate=calibrate,visit=visit,visit_type=visit_type,
#                       number_of_children=number_of_children)
#   b3.3 = design_box.1(pull = pull%>%semi_join(b2.2%>%filter(FINAL_RUN_NO==1),by=c(subject_id)),aliquot = aliquot%>%semi_join(b2.2%>%filter(FINAL_RUN_NO==1),by=c(subject_id)),
#                       extract = extract%>%semi_join(b2.2%>%filter(FINAL_RUN_NO==1),by=c(subject_id)),combine = combine%>%semi_join(b2.2%>%filter(FINAL_RUN_NO==1),by=c(subject_id)),
#                       balance_vars, box_size=box_size, subject_id,maximize_fullness = maximize_fullness,
#                       dir =dir, verbose = verbose, iterations=iterations, calibrate=calibrate,visit=visit,visit_type=visit_type,
#                       number_of_children=number_of_children)
#   b3.4 = design_box.1(pull = pull%>%semi_join(b2.2%>%filter(FINAL_RUN_NO==2),by=c(subject_id)),aliquot = aliquot%>%semi_join(b2.2%>%filter(FINAL_RUN_NO==2),by=c(subject_id)),
#                       extract = extract%>%semi_join(b2.2%>%filter(FINAL_RUN_NO==2),by=c(subject_id)),combine = combine%>%semi_join(b2.2%>%filter(FINAL_RUN_NO==2),by=c(subject_id)),
#                       balance_vars, box_size=box_size, subject_id,maximize_fullness = maximize_fullness,
#                       dir =dir, verbose = verbose, iterations=iterations, calibrate=calibrate,visit=visit,visit_type=visit_type,
#                       number_of_children=number_of_children)
  # design = b3.1%>%bind_rows(
  #   b3.2%>%mutate(FINAL_RUN_NO=FINAL_RUN_NO+max(b3.1$FINAL_RUN_NO)),
  #   b3.3%>%mutate(FINAL_RUN_NO=FINAL_RUN_NO+max(b3.1$FINAL_RUN_NO)+max(b3.2$FINAL_RUN_NO)),
  #   b3.4%>%mutate(FINAL_RUN_NO=FINAL_RUN_NO+max(b3.1$FINAL_RUN_NO)+max(b3.2$FINAL_RUN_NO)+max(b3.3$FINAL_RUN_NO))
  # )
  design = b4[[1]]
  for(i in 2:8){
    design = design%>%bind_rows(b4[[i]])
  }
  openxlsx::write.xlsx(design,"bdnew.xlsx",row.names=FALSE)

}





design_box = function(pull,aliquot,extract,combine, balance_vars, box_size, subject_id,maximize_fullness = T,
                        dir = ".", verbose = FALSE, iterations=5, calibrate=0.001,visit=T,visit_type="VISIT",number_of_children=1){
  config = mmgeDistributions:::get_pullsheet_config(dir)
  if(!missing(pull)) {
    if(nrow(pull)>0){
      pull <- dplyr::ungroup(pull)
    } else{pull = NULL}
  } else{
    pull = NULL
  }
  if(!missing(aliquot)) {
    if(nrow(aliquot)>0){
      aliquot <- dplyr::ungroup(aliquot)
      aliquot_test = mmgeDistributions::split_aliquots(aliquot,number_of_children)
    } else{aliquot_test=NULL}

  } else{
    aliquot_test = NULL
  }
  if(!missing(extract)) {
    if(nrow(extract)>0){
      extract <- dplyr::ungroup(extract)
      extract_test = mmgeDistributions::split_aliquots(extract,number_of_children)
    } else{extract_test=NULL}

  } else{
    extract_test = NULL
  }
  if(!missing(combine)) {
    if(nrow(combine)>0){
      combine <- dplyr::ungroup(combine)%>%
        group_by(CASE_NO)%>%
        filter(row_number()==1)%>%
        ungroup()
    } else{combine=NULL}

  } else{
    combine = NULL
  }

  if(missing(subject_id)) {
    subject_id <- config$subject_ids$blinded
  }

  if(missing(box_size)) {
    box_size <- config$box_size
  }

  if(missing(balance_vars)) {
    balance_vars = config$balance_vars
  }


  if(visit==F){
    box_design <- dplyr::bind_rows(pull,aliquot_test,extract_test,combine) %>%
      dplyr::distinct_(.dots = c(subject_id, visit_type), .keep_all = TRUE) %>%
      dplyr::select_(.dots = c(subject_id,visit_type, balance_vars)) %>%
      dplyr::group_by_(.dots = c(subject_id,visit_type, balance_vars)) %>%
      dplyr::summarise(VISITS = n()) %>%
      dplyr::arrange_(.dots = balance_vars) %>%
      dplyr::mutate(FINAL_RUN_NO = 0)
  }
  if(visit==T){
    box_design <- dplyr::bind_rows(pull,aliquot_test,extract_test,combine) %>%
      dplyr::distinct_(.dots = c(subject_id, visit_type), .keep_all = TRUE)%>%
      dplyr::select_(.dots = c(subject_id,visit_type, balance_vars)) %>%
      dplyr::group_by_(.dots = c(subject_id, balance_vars)) %>%
      dplyr::summarise(VISITS = n()) %>%
      dplyr::arrange_(.dots = balance_vars) %>%
      dplyr::mutate(FINAL_RUN_NO = 0)
  }


  statlist=c()
  stat_list = data.frame()
  stat=c()
  fullness = c()
  boxes = ceiling(sum(box_design$VISITS)/box_size)
  box_design1=c()
  box_design_list=list()
  maxlist=c()
  u=0
  l=1
  while(u==0){
    tim = proc.time()
    itr = paste("Iteration #",l,sep=" ")
    message("")
    message(itr)
    message("")
    box_design = box_design[sample(nrow(box_design)),]
    #for (k in 1:length(unique(box_design[,balance_vars]))){
    #maxlist[k]=sum(box_design$VISITS[which(box_design[,balance_vars]==as.character(unique(box_design[k,balance_vars])))])/(sum(box_design$VISITS))*box_size
    #}

    for (i in 1:nrow(box_design)){
      time = proc.time()
      for (j in 1:boxes){
        box_design$FINAL_RUN_NO[i]=j
        statlist[j]=calc_score(box_design,balance_vars = balance_vars,box_size=box_size,calibrate=calibrate,maximize_fullness = maximize_fullness)
      }
      box_design$FINAL_RUN_NO[i]=which.min(statlist)
      box_design$SCORE[i] = min(statlist)
      time2 = proc.time()-time
      time3 = tim+time2*nrow(box_design)
      eta = paste("Row",i,"completed","(",ceiling((time3-proc.time())/60)["elapsed"],"minutes left",")",sep=" ")
      message(eta)
    }
    if(sum(box_design$VISITS[box_design$FINAL_RUN_NO==1])==box_size){
      message(paste0("The process took ",l," iterations"))
      u=1
    }
    l=l+1
  }
  return(box_design)
}

