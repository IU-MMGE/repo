#' Close a Footprints ticket
#'
#' Checks if the ticket is open and is assigned to the current user, if it is
#' sends an email to close the ticket in footprints.
#'
#' @param fp_id The footprints issue id
#'
#' @export
close_ticket <- function(fp_id) {

  ticket <- query_footprints(number=fp_id)

  if(ticket$status == "Closed") {
    stop("Ticket ", fp_id, " is already closed.", call. = FALSE)
  } else if(!grepl(Sys.info()['user'], ticket$assignees)) {
    stop("Ticket ", fp_id, " is not assigned to you.", call. = FALSE)
  } else {
    return(
      invisible(
        mmge::send_email(get_footprints_email_subject(ticket), msg = "Status=Closed", to = "mmgehelp@iu.edu")
      )
    )
  }

}