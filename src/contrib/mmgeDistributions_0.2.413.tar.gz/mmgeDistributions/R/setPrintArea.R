setPrintArea <- function (wb, sheet, cols, rows)
{
  name = "Print_Area"
  sheet <- wb$validateSheet(sheet)
  if (!"Workbook" %in% class(wb))
    stop("First argument must be a Workbook.")
  if (!is.numeric(rows))
    stop("rows argument must be a numeric/integer vector")
  if (!is.numeric(cols))
    stop("cols argument must be a numeric/integer vector")
  ex_names <- regmatches(wb$workbook$definedNames, regexpr("(?<=name=\")[^\"]+",
                                                           wb$workbook$definedNames, perl = TRUE))
  # ex_names <- tolower(replaceXMLEntities(ex_names))
  # if (tolower(name) %in% ex_names) {
  #   stop(sprintf("Named region with name '%s' already exists!",
  #                name))
  # }
  if (grepl("[^A-Z0-9_\\.]", name[1], ignore.case = TRUE)) {
    stop("Invalid characters in name")
  }
  else if (grepl("^[A-Z]{1,3}[0-9]+$", name)) {
    stop("name cannot look like a cell reference.")
  }
  cols <- round(cols)
  rows <- round(rows)
  startCol <- min(cols)
  endCol <- max(cols)
  startRow <- min(rows)
  endRow <- max(rows)
  ref1 <- paste0("$", call("openxlsx_convert_to_excel_ref",
                            startCol, LETTERS, PACKAGE = "openxlsx"), "$", startRow)
  ref2 <- paste0("$", call("openxlsx_convert_to_excel_ref",
                            endCol, LETTERS, PACKAGE = "openxlsx"), "$", endRow)
  invisible(wb$createNamedRegion(ref1 = ref1, ref2 = ref2,
                                 name = name, sheet = wb$sheet_names[sheet]))
}