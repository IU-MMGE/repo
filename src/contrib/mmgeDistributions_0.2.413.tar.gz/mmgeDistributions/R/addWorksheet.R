addWorksheet <- function(wb, sheetName, data, tabColour = NULL, pullsheet = FALSE, ...) {

  if(!is.null(data)) {

    data <- as.data.frame(data)
    stb <- openxlsx::createStyle(border = "TopBottomLeftRight")

    openxlsx::addWorksheet(wb, sheetName, tabColour = tabColour)
    if(pullsheet) {
      openxlsx::writeData(wb, sheetName, x = data, startCol = 1, startRow = 1, ...)
      try(openxlsx::setColWidths(wb, sheetName, seq(ncol(data)), widths = "auto"))
      #openxlsx::freezePane(wb, sheetName, 4)
      #openxlsx::writeData(wb, sheetName, "Pulled By", startCol = 1, startRow = 1)
      #openxlsx::writeData(wb, sheetName, "Date", startCol = 1, startRow = 2)
      st <- openxlsx::createStyle(textDecoration = "bold")
      #openxlsx::writeData(wb, sheetName, "KEEP FROZEN", startCol = 9, startRow = 1)
      #openxlsx::addStyle(wb, sheetName, st, 1, 9, stack = TRUE)
      #setPrintArea(wb, sheetName, cols = 1:10, rows = 1:(nrow(data) + 3))
      #openxlsx::pageSetup(wb, sheetName, fitToWidth = TRUE, printTitleRows = 3)
      openxlsx::addStyle(wb = wb, sheet = sheetName, rows = 1:nrow(data), cols = 1:ncol(data), style = stb, gridExpand = TRUE, stack = TRUE)
    } else {
      openxlsx::writeData(wb, sheetName, x = data, ...)
      try(openxlsx::setColWidths(wb, sheetName, seq(ncol(data)), widths = "auto"))
      openxlsx::freezePane(wb, sheetName, 2)
      #setPrintArea(wb, sheetName, cols = 1:ncol(data), rows = 1:(nrow(data) + 3))
      # openxlsx::pageSetup(wb, sheetName, fitToWidth = TRUE, printTitleRows = 1)
      openxlsx::addStyle(wb, sheetName, rows = 1:nrow(data), cols = 1:ncol(data), style = stb, gridExpand = TRUE, stack = TRUE)
    }

  }

}