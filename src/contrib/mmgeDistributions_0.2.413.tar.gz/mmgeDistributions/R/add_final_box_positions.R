add_final_box_positions <- function(df, box) {
  
  if(is.null(df)) return(NULL)
  
  tb <- box %>%
    dplyr::ungroup() %>%
    dplyr::select_("SPECIMEN_NO", "FINAL_BOX_NO", "FINAL_BOX_POSITION")
  
  # stopifnot({
  #   nrow(tb %>% dplyr::distinct(CASE_NO)) == nrow(box)
  # })
  
  dplyr::left_join(df, tb)
  
}