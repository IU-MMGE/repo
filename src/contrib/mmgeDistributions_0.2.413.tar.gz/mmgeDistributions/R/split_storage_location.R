#'Split out Storage Locations
#'
#'@param query The returned query
#'@param location_field The field in the query data.frame that contains the storage locations
#'
#'@export
split_storage_location <- function(query, location_field = "SPECIMEN_STORAGE_LOCATION", sort = TRUE) {

  # Field names of the original data.frame
  fields <- colnames(query)

  # Split the storage location into its individual pieces
  x <- strsplit(query[[location_field]], "/")
  # Find the index of the storage location field
  f <- which(colnames(query) == location_field)
  # Variable to store the names of all the storage location related fields we are going to create
  location_fields <- c("STORAGE_LOCATION")

  # Create the STORAGE_LOCATION fields that is just the Room and the Freezer
  query$STORAGE_LOCATION <- sapply(x, function(y) {paste(y[1], y[2])})

  # Loop through each split storage location
  for(r in seq(nrow(query))) {

    # If there is anything left after the STORAGE_LOCATION field was built...
    if(length(x[[r]]) > 2) {

      # Loop through the remaining parts...
      for(c in seq(3, length(x[[r]]))) {

        # Use regular expressions to split the location type from the location id
        y <- regmatches(x[[r]][c], regexec(pattern = "([[:alpha:]]+)[[:space:]]*([[:alnum:]]+)", x[[r]][c]))

        # Make the location type upper-case cause thats the way I like it
        z <- toupper(y[[1]][2])

        # If there is anything there...
        if(length(y[[1]]) > 0) {
          # Check if that storage type has already been added
          if(!z %in% colnames(query)) {
            # If not, initialize the field with NAs
            query[[z]] <- NA
            # and add the name to the location_fields variable
            location_fields <- c(location_fields, z)
          }
          # then put the value in the appropriate spot
          query[[z]][r] <- y[[1]][3]
        }

      }

    }

  }

  # Split the data.frame up and stick the new location fields in the middle after the original storage location
  cn <- c(fields[1:f], location_fields)
  if(length(fields) > f) {
    cn <- c(cn, fields[(f+1):length(fields)])
  }
  query <- query[, cn]

  # If you want the data.frame sorted by locations
  if(sort) {

    # Look at each location field and see if everything is numeric, if it is convert the column to numeric so it sorts right
    for(f in location_fields) {
      x <- query[[f]]
      y <- suppressWarnings(as.numeric(x))
      if(sum(is.na(x)) == sum(is.na(y))) {
        query[[f]] <- as.numeric(query[[f]])
      }
    }

    # Use dplyr's arrange_ function as a shortcut to sort by all the location fields
    query <- dplyr::arrange_(query, .dots = location_fields)

  }

  # Return the data.frame with location_fields split out
  return(query)

}