#'Select standard pullsheet columns from a data.frame
#'
#'Wrapper for dplyr's select function that selects the standard pullsheet columns.
#'Supports adding additional custom columns when necessary.
#'
#'@param df The data.frame or tibble to select from
#'@param \dots Additional columns to include
#'@param .dots A list of additional columns to include
#'@param dir The directory that contains the mmgeDistribution project
#'
#'@export
select_pullsheet_fields <- function(df, ..., .dots, dir = ".", box_name,box_size) {

  get_storage_location <- function(df) {
    df$STORAGE_LOCATION <- sapply(strsplit(df$SPECIMEN_STORAGE_LOCATION, "/"), function(x) paste(x[1], x[2]))
    return(df)
  }

  df <- dplyr::ungroup(df)

  config <- mmgeDistributions:::get_pullsheet_config(dir)

  extra_fields <- unlist(list(...))

  if(!missing(.dots)) {
    extra_fields <- unique(c(extra_fields, unlist(.dots)))
  }

  if("extra_fields" %in% names(config)) {
    extra_fields <- unique(c(extra_fields, unlist(config$extra_fields)))
  }

  lab_fields <- c("SPECIMEN_BAR_CODE", "SPECIMEN_STORAGE_LOCATION","SPECIMEN_NO")

  coord_fields <- fields <- unique(c("SPECIMEN_NO","CASE_NO","ALTERNATE_MRN",config$subject_ids$blinded,"PATIENT_ID","SUBJECT_LAST_NAME","KIT_NUMBER", "VISIT", "COLLECTION_GROUP","SPECIMEN_TYPE",
                                     "SPECIMEN_QUANTITY", "SPECIMEN_COMMENTS","SPECIMEN_STATUS","UNIT_OF_MEASURE","CASE_OR_CONTROL","HEMOGLOBIN_ASSAY",
                                     "HEMOLYSIS_GRADE","TURBIDITY_GRADE","CONCENTRATION","CONCENTRATION","CONCENTRATION_UOM","X260.230_RATIO","X260.280_RATIO",
                                     "RIN_VALUE","KIT_NUMBER","NON.CONFORMANCE_REASON_.SPECIMEN.","NON.CONFORMANCE_DETAIL_.SPECIMEN.", extra_fields))


  lab_pullsheet <- df %>%
    dplyr::select_(.dots = lab_fields) %>%
    dplyr::mutate(SPECIMEN_NO = as.character(SPECIMEN_NO))#
  if(!all(is.na(lab_pullsheet$SPECIMEN_STORAGE_LOCATION))){
    lab_pullsheet = lab_pullsheet%>%process_storage_location()

  }

  location_fields <- attr(lab_pullsheet, "location_fields")

  # for(x in colnames(lab_pullsheet)) {
  #   if(all(is.na(lab_pullsheet[[x]]))) {
  #     lab_pullsheet[[x]] <- NULL
  #   }
  # }

  coord_pullsheet <- df %>%
    dplyr::select_(.dots = coord_fields)%>%
    dplyr::mutate(SPECIMEN_NO = as.character(SPECIMEN_NO))

  pullsheet <- lab_pullsheet %>%
    dplyr::ungroup() %>%
    dplyr::full_join(coord_pullsheet, by = "SPECIMEN_NO")

  pullsheet <- pullsheet%>%ungroup()%>%dplyr::arrange_(.dots = c(location_fields,"SPECIMEN_NO"))

  col_order <- c("SPECIMEN_NO", "SPECIMEN_BAR_CODE", location_fields)

  pullsheet <- pullsheet %>%
    dplyr::mutate(TEMP_BOX_POSITION = rep(seq(box_size), times = ceiling(nrow(pullsheet) / box_size))[1:nrow(pullsheet)]) %>%
    dplyr::group_by(TEMP_BOX_POSITION) %>%
    dplyr::mutate(TEMP_BOX_NO = row_number())

  other_cols <- colnames(pullsheet)[!colnames(pullsheet) %in% col_order]
  col_order <- c(col_order, other_cols)

  pullsheet <- pullsheet %>%
    dplyr::select_(.dots = col_order) %>%
    dplyr::select(-SPECIMEN_STORAGE_LOCATION)


   if(!missing(box_name)) {
     pullsheet$TEMP_BOX_NO = paste(box_name, pullsheet$TEMP_BOX_NO, sep = "_")
   }

  return(pullsheet)

}

process_storage_location <- function(df) {

  x <- strsplit(df$SPECIMEN_STORAGE_LOCATION, "/")
  location_fields <- c("STORAGE_LOCATION")

  df$STORAGE_LOCATION <- sapply(x, function(x) paste(x[1], x[2]))

  for(r in seq(nrow(df))) {

    if(length(x[[r]]) > 2) {

      for(c in seq(3, length(x[[r]]))) {

        if(grepl("Section",x[[r]][c])){
          y <- regmatches(x[[r]][c], regexec(pattern = "([[:alpha:]]+)[[:space:]]*([[:alpha:]]+)", x[[r]][c]))

        } else{
          y <- regmatches(x[[r]][c], regexec(pattern = "([[:alpha:]]+)[[:space:]]*([[:digit:]]+)", x[[r]][c]))

        }

        z <- toupper(y[[1]][2])

        if(length(y[[1]]) > 0) {

          if(!z %in% colnames(df)) {
            location_fields <- c(location_fields, z)
            df[[z]] <- NA
          }
          if(z=="SECTION"){
            df[[z]][r] <- as.character(y[[1]][3])

          } else{
            df[[z]][r] <- as.numeric(y[[1]][3])

          }

        }

      }

    }

  }
  df <- as.data.frame(df,stringsAsFactors=F)
  attr(df, "location_fields") <- location_fields
  return(df)

}
