#'@export

create_new_project = function(project_name, folders,custom_dir,markdown = FALSE, open = TRUE,overwrite = FALSE){

  if(!missing(custom_dir)){
    r_dir = paste0(custom_dir,"/",project_name)
  } else{
    r_dir = paste0("/media/R/zagoodma/",project_name)

  }

  if(!dir.exists(r_dir)) {
    dir.create(r_dir)
  }


  if(!missing(folders)){
    suppressWarnings({
      for(i in 1:length(folders)){
        if(!dir.exists(file.path(r_dir, folders[i]))|overwrite){
          dir.create(file.path(r_dir, folders[i]))
        }
      }
    })
  }

  if(missing(folders)){
    folders = ""
  }


  if(!file.exists(file.path(r_dir,paste0(project_name,".Rmd")))|overwrite){
    write_r_script_template(project_name, r_dir,folders)
    write_r_proj_template(project_name, r_dir)

    if(markdown){
      write_r_markdown_template(project_name,r_dir)
    }
  }



  if(open==T){
    rstudioapi::openProject(file.path(r_dir,paste(project_name,".Rproj",sep="")))
  }
  if(open==F){
    return(file.path(r_dir,paste(project_name,".Rproj",sep="")))
  }



}


write_r_markdown_template = function(project_name,r_dir){

  required_packages <- c("dplyr", "openxlsx", "mmge", "mmgeDistributions","mmgeMongo")

  libraries <- paste("library(", required_packages, ")", collapse = "\n", sep = "")

  info <- glue::glue(
      .sep = "\n",
      "---",
      'pagetitle: "{{project_name}}"',
      'output: html_document',
      '---',
      '<!--',
      'params:',
      '  firstparam:',
      '    label:',
      '    value:',
      '    input:',
      '    choices:',
      '-->',
      "",
      '<style type="text/css">
  .main-container {
    max-width: 1800px;
    margin-left: auto;
    margin-right: auto;
  }
  </style>',
  '',
  '<!-- TITLE OF REPORT -->',
  '',
  '<b><center><H1>TITLE GOES HERE</b></center></H1',
  '',
  '<!-- DESCRIPTION -->',
  '',
  '<H5>DESCRIPTION GOES HERE</H5>',
  '',
  '<!-- REPORT CODE -->',
  '',
  '```{r report,echo=FALSE,message=FALSE,warning=FALSE}',
  'rm(list=ls())',
  libraries,
  '',

  '```',
  '',
  '<!-- OUTPUT -->',
  '',
  '## {.tabset}',
  '',
  '### TAB1',
  '',
  '```{r, echo=FALSE,message=FALSE,warning=FALSE}',
  'final %>%',
  '  DT::datatable(',
  "  extensions = 'Buttons', filter = 'top',",
  "  options = list(dom = 'Bfrtip', ",
  "                buttons = list('excel', 'csv'),pageLength=50))",
  '',
  '```',
  '',
  '### TAB2',
  '',
  '```{r, echo=FALSE,message=FALSE,warning=FALSE}',
  'final2 %>%',
  '  DT::datatable(',
  "  extensions = 'Buttons', filter = 'top',",
  "  options = list(dom = 'Bfrtip', ",
  "                buttons = list('excel', 'csv'),pageLength=50))",
  '',
  '```',
  '',

  '<!-- ANNOTATIONS -->',
  '',
  '<H5></H5>'
  , .open = "{{")


  file <- file(file.path(r_dir,paste0(project_name,".Rmd")))

  writeLines(info, file)



}


write_r_script_template <- function(project_name,r_dir,folders) {


  required_packages <- c("dplyr", "openxlsx", "mmge", "mmgeDistributions","mmgeMongo")

  libraries <- paste("library(", required_packages, ")", collapse = "\n", sep = "")


  info <- glue::glue(.sep = "\n",
                     "rm(list = ls())",
                     "",
                     libraries,
                     "",
                     glue::collapse(rep("#", times = 80)),
                     "##",
                     "##        Project Name: {project_name}",
                     "##",
                     glue::collapse(rep("#", times = 80)),
                     "",
                     "process_data_files('{folders[1]}')"
  )

  file <- file(file.path(r_dir,paste0(project_name,".R")))


  writeLines(info, file)



  close(file)

}


write_r_proj_template <- function(project_name, r_dir) {

  file <- file(file.path(r_dir,paste0(project_name, ".Rproj")))

  writeLines(glue::glue(.sep = "\n",
                        "Version: 1.0",
                        "",
                        "RestoreWorkspace: Default",
                        "SaveWorkspace: Default",
                        "AlwaysSaveHistory: Default",
                        "",
                        "EnableCodeIndexing: Yes",
                        "UseSpacesForTab: Yes",
                        "NumSpacesForTab: 2",
                        "Encoding: UTF-8",
                        "",
                        "RnwWeave: Sweave",
                        "LaTeX: pdfLaTeX"
  ), file)

  close(file)

}
