#'@export


arrange_dcr = function(pull){
  pull = pull%>%
    arrange(ReferencedTable,DNAStatus,DNASource,DCRDateRemoved,desc(IsBackup),desc(Available),desc(Yieldug))
  return(pull)
}
