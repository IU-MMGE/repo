#'@export
send_pullsheet <- function(file_path, msg = "Requested pullsheet attached.", dir = ".", close = TRUE) {

  msgs <- c(
    "See how this looks...",
    "Requested pullsheet attached...",
    "Let me know if you have any issues...",
    "Let me know if you need anything else..."
  )

  if(missing(msg)) {
    msg <- sample(msgs, size = 1)
  }

  if(close) {
    msg <- paste(msg, "\nStatus=Closed")
  }

  mmge::send_email(
    subject = get_footprints_email_subject(get_pullsheet_config(dir)),
    msg = msg,
    to = "mmgehelp@iu.edu",
    html = FALSE,
    attachments = file_path
  )

  # if(close) {
  #   close_ticket(get_pullsheet_config(dir)$number)
  # }

}