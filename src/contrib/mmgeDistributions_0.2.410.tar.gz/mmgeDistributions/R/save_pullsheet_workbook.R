#'@export
save_pullsheet_workbook <- function(wb, file_name, file_name_append, dir = ".",folder=NULL) {

#  dir <- "/media/distributions/MMGE-NINDS-BIOSEND/Caughey_23884_7413/R/"

  config <- get_pullsheet_config(dir)

  if(!is.null(folder)){
    if(!file.exists(file.path(config$directory,"Pullsheet",folder))){
      dir.create(file.path(config$directory,"Pullsheet",folder))
    }
    if(missing(file_name)) {
      if(missing(file_name_append)) {
        save_file <- file.path(config$directory, "Pullsheet",folder, sprintf("%s_%s.xlsx", config$order_name, Sys.Date()))
      } else {
        save_file <- file.path(config$directory, "Pullsheet",folder, sprintf("%s_%s_%s.xlsx", config$order_name, file_name_append, Sys.Date()))
      }
    } else {
      if(!grepl("/", file_name)) {
        save_file <- file.path(config$directory, "Pullsheet",folder, file_name)
      } else {
        save_file = file_name
      }
      if(!grepl("\\.xlsx$", save_file)) {
        save_file <- paste0(save_file, ".xlsx")
      }
    }
  }
  else{
    if(missing(file_name)) {
      if(missing(file_name_append)) {
        save_file <- file.path(config$directory, "Pullsheet", sprintf("%s_%s.xlsx", config$order_name, Sys.Date()))
      } else {
        save_file <- file.path(config$directory, "Pullsheet", sprintf("%s_%s_%s.xlsx", config$order_name, file_name_append, Sys.Date()))
      }
    } else {
      if(!grepl("/", file_name)) {
        save_file <- file.path(config$directory, "Pullsheet", file_name)
      } else {
        save_file = file_name
      }
      if(!grepl("\\.xlsx$", save_file)) {
        save_file <- paste0(save_file, ".xlsx")
      }
    }
  }



  openxlsx::saveWorkbook(wb, file = save_file, overwrite = TRUE)

  return(save_file)

}