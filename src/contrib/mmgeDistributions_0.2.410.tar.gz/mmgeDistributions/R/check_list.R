#'@export

pullsheet_query = function(fields,annotations,extra_fields = NULL,extra_annotations = NULL,env="PRD",recode=F,pullsheet=F,protocol=NULL){
  options(java.parameters = "-Xmx8192m")

  require(dplyr)
  if(missing(fields)&missing(annotations)){
    recode=T
    fields = c("PROTOCOL_NO","SPECIMEN_NO","SPECIMEN_STORAGE_LOCATION","PARENT_SPECIMEN_ID","ALTERNATE_MRN","PATIENT_ID","SUBJECT_LAST_NAME",
               "COLLECTION_GROUP","SPECIMEN_TYPE","VISIT","CASE_NO","SPECIMEN_QUANTITY","SPECIMEN_BAR_CODE","SPECIMEN_STATUS",
               "PCS_SPECIMEN_ID","SPECIMEN_COMMENTS","SEQUENCE_NUMBER","SPECIMEN_REQUEST_ID","GENDER","UNIT_OF_MEASURE")
    annotations = c("Kit Number","Freeze / Thaw Cycle","Concentration","Concentration UOM","Instrument for QC",
                    "Volume","Volume UOM","DNA Source","Genotyped","Genotyping Instrument","Last Date Genotyped",
                    "Nucleic Acid Derivative","Collection Container","Storage Container","Cell Type","Hemoglobin Assay",
                    "Researcher Reserved For","Hemolysis Grade","Turbidity Grade","260/230 Ratio","260/280 Ratio","RIN Value",
                    "Case or Control","Non-Conformance Detail (specimen)","Non-Conformance Reason (specimen)")
  }
  if(missing(fields)&!missing(annotations)){
    fields = c()
  }
  if(!missing(fields)&missing(annotations)){
    annotations = c()
  }
  if(!is.null(extra_fields)){
    fields = unique(c(fields,extra_fields))
  }
  if(!is.null(extra_annotations)){
    annotations = unique(c(annotations,extra_annotations))
  }
  if(is.null(annotations)){
    query1 <- oncore2::oncore_connect(env=env)%>%
      oncore2::select_fields_(.dots = fields)
  }
  if(is.null(fields)){
    query1 <- oncore2::oncore_connect(env=env)%>%
      oncore2::select_annotations(.dots = annotations)
  }
  if(!is.null(fields)&!is.null(annotations)){
    query1 <- oncore2::oncore_connect(env=env)%>%
      oncore2::select_fields_(.dots = fields)%>%
      oncore2::select_annotations(.dots = annotations)
  }
  if(is.null(protocol)){
    query = query1%>%oncore2::execute_query()
  }
  if(!is.null(protocol)){
    query = query1%>%oncore2:::filter_oncore(oncore2::protocol(protocol))%>%oncore2::execute_query()
  }

  if(recode){
    query$NON.CONFORMANCE_REASON_.SPECI = query$NON.CONFORMANCE_REASON_.SPECIMEN.
    query$NON.CONFORMANCE_DETAIL_.SPECI = query$NON.CONFORMANCE_DETAIL_.SPECIMEN.
    query = oncore2::recode_field(query,"COLLECTION_GROUP")
    query = oncore2::recode_field(query,"GENOTYPING_INSTRUMENT")
    query = oncore2::recode_field(query,"CONCENTRATION_UOM")
    query = oncore2::recode_field(query,"INSTRUMENT_FOR_QC")
    query = oncore2::recode_field(query,"VOLUME_UOM")
    query = oncore2::recode_field(query,"DNA_SOURCE")
    query = oncore2::recode_field(query,"GENOTYPED")
    query = oncore2::recode_field(query,"RESEARCHER_RESERVED_FOR")
    query = oncore2::recode_field(query,"STORAGE_CONTAINER")
    query = oncore2::recode_field(query,"COLLECTION_CONTAINER")
    query = oncore2::recode_field(query,"CASE_OR_CONTROL")
    query = oncore2::recode_field(query,"TURBIDITY_GRADE")
    query = oncore2::recode_field(query,"CELL_TYPE")
    query = oncore2::recode_field(query,"NON.CONFORMANCE_REASON_.SPECI")
    query = oncore2::recode_field(query,"NUCLEIC_ACID_DERIVATIVE")
    query = oncore2::recode_field(query,"HEMOLYSIS_GRADE")
    query$SPECIMEN_COMMENTS = ifelse(is.na(query$SPECIMEN_COMMENTS),"",query$SPECIMEN_COMMENTS)
    query = query%>%
      dplyr::arrange(SPECIMEN_COMMENTS)
  }

  if(pullsheet){
    query = query%>%
      dplyr::filter(!GENOTYPED%in%c("FAIL","GENOERR")|is.na(GENOTYPED))
    query = query%>%
      dplyr::filter(is.na(RESEARCHER_RESERVED_FOR)|!RESEARCHER_RESERVED_FOR%in%c("Reference Pool"))
    query = query%>%
      dplyr::filter(ifelse(COLLECTION_GROUP%in%c("PBMC","CELL LINE")|CELL_TYPE%in%c("EBV LCL","Fibroblast","iPSC"),
                                                        grepl("R3",SPECIMEN_STORAGE_LOCATION,fixed=T),is.na(SPECIMEN_COMMENTS)|!is.na(SPECIMEN_COMMENTS)))
    query = query[!duplicated(query$SPECIMEN_NO,fromLast=TRUE),]
  }
  return(query)
}

get_all_tables = function(){
  tables <- oncore2::query_oncore("SELECT TABLE_NAME FROM ALL_TAB_COLUMNS")
  return(tables)
}

get_field_list = function(){
  x = oncore2:::get_data_file('field_list')
  return(x)
}

get_annotation_list = function(){
  y = oncore2:::get_data_file('annotation_list')
  return(y)
}