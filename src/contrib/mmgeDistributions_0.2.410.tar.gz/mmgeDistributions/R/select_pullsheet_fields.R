#'Select standard pullsheet columns from a data.frame
#'
#'Wrapper for dplyr's select function that selects the standard pullsheet columns.
#'Supports adding additional custom columns when necessary.
#'
#'@param df The data.frame or tibble to select from
#'@param \dots Additional columns to include
#'@param .dots A list of additional columns to include
#'@param dir The directory that contains the mmgeDistribution project
#'
#'@export
select_pullsheet_fields <- function(df, ..., .dots, dir = ".", box_name,box_size) {

  get_storage_location <- function(df) {
    df$STORAGE_LOCATION <- sapply(strsplit(df$SPECIMEN_STORAGE_LOCATION, "/"), function(x) paste(x[1], x[2]))
    return(df)
  }

  df <- dplyr::ungroup(df)

  config <- mmgeDistributions:::get_pullsheet_config(dir)

  extra_fields <- unlist(list(...))

  if(!missing(.dots)) {
    extra_fields <- unique(c(extra_fields, unlist(.dots)))
  }

  if("extra_fields" %in% names(config)) {
    extra_fields <- unique(c(extra_fields, unlist(config$extra_fields)))
  }

  lab_fields <- c("SPECIMEN_BAR_CODE", "SPECIMEN_STORAGE_LOCATION","SPECIMEN_NO")

  coord_fields <- fields <- unique(c("PROTOCOL_NO","SPECIMEN_NO","CASE_NO","ALTERNATE_MRN",config$subject_ids$blinded,"PATIENT_ID","SUBJECT_LAST_NAME","KIT_NUMBER", "VISIT",
                                     "TIMEPOINT_LABEL","COLLECTION_GROUP","SPECIMEN_TYPE",
                                     "SPECIMEN_QUANTITY", "SPECIMEN_COMMENTS","SPECIMEN_STATUS","UNIT_OF_MEASURE","CASE_OR_CONTROL","HEMOGLOBIN_ASSAY",
                                     "HEMOLYSIS_GRADE","TURBIDITY_GRADE","CONCENTRATION","CONCENTRATION","CONCENTRATION_UOM","X260.230_RATIO","X260.280_RATIO",
                                     "RIN_VALUE","KIT_NUMBER","NON.CONFORMANCE_REASON_.SPECIMEN.","NON.CONFORMANCE_DETAIL_.SPECIMEN.", extra_fields))


  lab_pullsheet <- df %>%
    dplyr::select_(.dots = lab_fields) %>%
    dplyr::mutate(SPECIMEN_NO = as.character(SPECIMEN_NO))#
  if(!all(is.na(lab_pullsheet$SPECIMEN_STORAGE_LOCATION))){
    lab_pullsheet = lab_pullsheet%>%split_storage_location()

  }

  location_fields <- attr(lab_pullsheet, "location_fields")

  # for(x in colnames(lab_pullsheet)) {
  #   if(all(is.na(lab_pullsheet[[x]]))) {
  #     lab_pullsheet[[x]] <- NULL
  #   }
  # }

  coord_pullsheet <- df %>%
    dplyr::select_(.dots = coord_fields)%>%
    dplyr::mutate(SPECIMEN_NO = as.character(SPECIMEN_NO))

  pullsheet <- lab_pullsheet %>%
    dplyr::ungroup() %>%
    dplyr::full_join(coord_pullsheet, by = "SPECIMEN_NO")

  pullsheet <- pullsheet%>%ungroup()%>%dplyr::arrange_(.dots = c(location_fields,"SPECIMEN_NO"))

  col_order <- c("SPECIMEN_NO", "SPECIMEN_BAR_CODE", location_fields)

  pullsheet <- pullsheet %>%
    dplyr::mutate(TEMP_BOX_POSITION = rep(seq(box_size), times = ceiling(nrow(pullsheet) / box_size))[1:nrow(pullsheet)]) %>%
    dplyr::group_by(TEMP_BOX_POSITION) %>%
    dplyr::mutate(TEMP_BOX_NO = row_number())

  other_cols <- colnames(pullsheet)[!colnames(pullsheet) %in% col_order]
  col_order <- c(col_order, other_cols)

  pullsheet <- pullsheet %>%
    dplyr::select_(.dots = col_order) %>%
    dplyr::select(-SPECIMEN_STORAGE_LOCATION)


   if(!missing(box_name)) {
     pullsheet$TEMP_BOX_NO = paste(box_name, pullsheet$TEMP_BOX_NO, sep = "_")
   }

  return(pullsheet)

}

process_storage_location <- function(query, location_field = "SPECIMEN_STORAGE_LOCATION", sort = TRUE) {

  # Field names of the original data.frame
  fields <- colnames(query)

  # Split the storage location into its individual pieces
  x <- strsplit(query[[location_field]], "/")
  # Find the index of the storage location field
  f <- which(colnames(query) == location_field)
  # Variable to store the names of all the storage location related fields we are going to create
  location_fields <- c("STORAGE_LOCATION")

  # Create the STORAGE_LOCATION fields that is just the Room and the Freezer
  query$STORAGE_LOCATION <- sapply(x, function(y) {paste(y[1], y[2])})

  # Loop through each split storage location
  for(r in seq(nrow(query))) {

    # If there is anything left after the STORAGE_LOCATION field was built...
    if(length(x[[r]]) > 2) {

      # Loop through the remaining parts...
      for(c in seq(3, length(x[[r]]))) {

        # Use regular expressions to split the location type from the location id
        y <- regmatches(x[[r]][c], regexec(pattern = "([[:alpha:]]+)[[:space:]]*([[:alnum:]]+)", x[[r]][c]))

        # Make the location type upper-case cause thats the way I like it
        z <- toupper(y[[1]][2])

        # If there is anything there...
        if(length(y[[1]]) > 0) {
          # Check if that storage type has already been added
          if(!z %in% colnames(query)) {
            # If not, initialize the field with NAs
            query[[z]] <- NA
            # and add the name to the location_fields variable
            location_fields <- c(location_fields, z)
          }
          # then put the value in the appropriate spot
          query[[z]][r] <- y[[1]][3]
        }

      }

    }

  }

  # Split the data.frame up and stick the new location fields in the middle after the original storage location
  cn <- c(fields[1:f], location_fields)
  if(length(fields) > f) {
    cn <- c(cn, fields[(f+1):length(fields)])
  }
  query <- query[, cn]

  # If you want the data.frame sorted by locations
  if(sort) {

    # Look at each location field and see if everything is numeric, if it is convert the column to numeric so it sorts right
    for(f in location_fields) {
      x <- query[[f]]
      y <- suppressWarnings(as.numeric(x))
      if(sum(is.na(x)) == sum(is.na(y))) {
        query[[f]] <- as.numeric(query[[f]])
      }
    }

    # Use dplyr's arrange_ function as a shortcut to sort by all the location fields
    query <- dplyr::arrange_(query, .dots = location_fields)

  }

  # Return the data.frame with location_fields split out
  return(query)

}


#   function(df) {
#
#   x <- strsplit(df$SPECIMEN_STORAGE_LOCATION, "/")
#   location_fields <- c("STORAGE_LOCATION")
#
#   df$STORAGE_LOCATION <- sapply(x, function(x) paste(x[1], x[2]))
#
#   for(r in seq(nrow(df))) {
#
#     if(length(x[[r]]) > 2) {
#
#       for(c in seq(3, length(x[[r]]))) {
#
#         if(grepl("Section",x[[r]][c])){
#           y <- regmatches(x[[r]][c], regexec(pattern = "([[:alpha:]]+)[[:space:]]*([[:alpha:]]+)", x[[r]][c]))
#
#         } else{
#           y <- regmatches(x[[r]][c], regexec(pattern = "([[:alpha:]]+)[[:space:]]*([[:digit:]]+)", x[[r]][c]))
#
#         }
#
#         z <- toupper(y[[1]][2])
#
#         if(length(y[[1]]) > 0) {
#
#           if(!z %in% colnames(df)) {
#             location_fields <- c(location_fields, z)
#             df[[z]] <- NA
#           }
#           if(z=="SECTION"){
#             df[[z]][r] <- as.character(y[[1]][3])
#
#           } else{
#             df[[z]][r] <- as.numeric(y[[1]][3])
#
#           }
#
#         }
#
#       }
#
#     }
#
#   }
#   df <- as.data.frame(df,stringsAsFactors=F)
#   attr(df, "location_fields") <- location_fields
#   return(df)
#
# }
