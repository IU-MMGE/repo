#'@export
process_inventory <- function(protocol) {

  config_file <- file.path(mmge::hgdata(protocol), "Settings/inventory.yaml")

  x <-read_config(config_file) %>%
    query_oncore() %>%
    build_inventory() %>%
    publish_inventory() %>%
    save_inventory()

}
