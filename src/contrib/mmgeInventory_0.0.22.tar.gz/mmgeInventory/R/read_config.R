#' Read an mmgeInventory config file
#'
#' Reads and processes an mmgeInventory config file so that it can be used to
#' create an inventory file
#'
#' @param config_file the path to the config file to be read
#'
#' @export
read_config <- function(config_file = "./config.yaml") {

  config <- yaml::yaml.load_file(config_file)

  env <- new.env()

  if("variables" %in% names(config)) {
    for(a in names(config$variables)) {
      env[[a]] <- config$variables[[a]]
    }
  }
  if("functions" %in% names(config)) {
    for(a in names(config$functions)) {
      env[[a]] <- eval(parse(text = config$functions[[a]]), envir = env)
    }
  }

  if("external_data" %in% names(config)) {
    for(a in names(config$external_data)) {
      mmgeProtocols::load_protocol_data(config$protocol[1], a)
      ext_name <- gsub("\\..+$", "", a)
      env[[ext_name]] <- eval(parse(text = ext_name))
      if(paste0("post_", ext_name) %in% names(config)) {
        eval(parse(text = config[paste0("post_", ext_name)]), envir = env)
      }
    }
  }

  config$env <- env

  if("pre_query" %in% names(config)) {
    eval(parse(text = config$preface), envir = config$env)
  }

  data_fields <- sapply(config$fields, function(i) {names(i)[1]})

  config$sources <- list()

  for(x in unique(data_fields)) {
    config$sources[[x]] <- sapply(config$fields[data_fields == x], function(i) {
      return(i[[x]])
    })
  }

  config$not_na <- names(config$fields)[names(config$fields) %in% names(unlist(sapply(config$fields, function(x) {x$not_na == TRUE})))]
  config$valid_date <- names(config$fields)[names(config$fields) %in% names(unlist(sapply(config$fields, function(x) {x$valid_date == TRUE})))]

  return(config)

}
