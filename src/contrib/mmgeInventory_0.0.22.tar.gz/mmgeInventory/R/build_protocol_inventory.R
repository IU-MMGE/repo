#' build an inventory for a protocol
#'
#' wrapper for other mmgeInventory functions that relies on files being in
#' standard places to allow for automated building of a protocol-specific
#' inventory file.
#'
#' @param protocol the name of the protocol
#'
#' @return an inventory object
#' @export
#'
#' @examples
build_protocol_inventory <- function(protocol) {

  config_file <- file.path(mmgeProtocols::protocol_path(), protocol, "settings", "inventory.yaml")

  if(!file.exists(config_file)) {
    stop("Could not locate an inventory config file.", call. = FALSE)
  }

  config <- read_config(config_file) %>%
    query_oncore() %>%
    build_inventory()

  return(config)

}
