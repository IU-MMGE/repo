#' Query the oncore database
#'
#' Builds an oncore query based on the fields and annotations used by the sample
#' inventory.
#'
#' @param config the output from \code{\link{read_config}}
#' @param execute Should the query be sent to oncore?
#'
#' @export
query_oncore <- function(config, execute = TRUE) {

  if(config$verbose) message("Querying OnCore...")

  query <- oncore2::oncore_connect(env = config$oncore_source, distinct = TRUE,
                                   query_name = config$name, verbose = config$verbose)

  fields <- c("SPECIMEN_NO", "SPECIMEN_BAR_CODE", "SUBJECT_LAST_NAME",
              "ALTERNATE_MRN", "PATIENT_ID", "SPECIMEN_STORAGE_LOCATION",
              "COLLECTION_GROUP", "SPECIMEN_TYPE")

  annotations <- c()

  if("field" %in% names(config$sources)) {
    fields <- c(fields, unname(unlist(config$sources$field, recursive = TRUE)))
  }

  if(config$standard_removes) {
    fields <- c(fields, c("SPECIMEN_STATUS", "REASON_DESTROYED"))
  }

  if("additional_fields" %in% names(config)) {
    fields <- unique(c(fields, config$additional_fields))
  }

  if("annotation" %in% names(config$sources)) {
    annotations <- c(annotations, unname(unlist(config$sources$annotation, recursive = TRUE)))
  }

  if("additional_annotations" %in% names(config)) {
    annotations <- unique(c(annotations, config$additional_annotations))
  }

  if("formula" %in% names(config$sources)) {
    formulas <- unname(unlist(config$sources$formula))
    formula_arguments <- unlist(stringr::str_match_all(formulas, "[A-Z0-9_\\.]{2,}"))
    formula_fields <- unique(formula_arguments[formula_arguments %in% oncore2::field_list()$COLUMN_NAME])
    formula_annotations <- unique(formula_arguments[formula_arguments %in% anno_format(oncore2::annotation_list()$ANNOTATION)])
    formula_annotations <- oncore2::annotation_list()$ANNOTATION[anno_format(oncore2::annotation_list()$ANNOTATION) %in% formula_annotations]
    if(length(formula_fields) > 0) {
      fields <- c(fields, formula_fields)
    }
    if(length(formula_annotations) > 0) {
      annotations <- c(annotations, formula_annotations)
    }
  }

  annotations <- annotations[!anno_format(annotations) %in% fields]

  query <- oncore2::select_fields_(query, .dots = unique(fields))
  if(!is.null(annotations)) {
    query <- oncore2::select_annotations(query, .dots = unique(annotations))
  }
  query <- oncore2::filter_oncore(query, oncore2::protocol(config$protocol))

  if(config$include_pools) {
    pool_query <- oncore2::oncore_connect(env = config$oncore_source, distinct = TRUE,
                                          query_name = paste0(config$name, "_pools"),
                                          verbose = config$verbose)
    pool_query <- oncore2::select_fields_(pool_query, .dots = unique(fields))
    if(!is.null(annotations)) {
      pool_query <- oncore2::select_annotations(pool_query, .dots = unique(annotations))
    }
    pool_query <- oncore2::filter_oncore(pool_query, oncore2::protocol("POOL"))
  }

  if(config$not_new) {
    query <- oncore2::filter_oncore(query, oncore2::not(oncore2::specimen_status("New")))
    if(config$include_pools) {
      pool_query <- oncore2::filter_oncore(pool_query, oncore2::not(oncore2::specimen_status("New")))
    }
  }

  if("mongo" %in% names(config)) {
    if(config$mongo$use_mongo) {
      query
    }
  }

  query <- oncore2::execute_query(query, recode = TRUE, execute = execute)

  # if("UNIT_OF_MEASURE" %in% colnames(query)) {
  #   query <- oncore2::recode_field(query, "UNIT_OF_MEASURE")
  # }

  if(config$include_pools) {
    if(config$verbose) message("Getting Pool Information...")
    pool_query <- oncore2::execute_query(pool_query, recode = TRUE, execute = execute)
    pool_query <- eval(parse(text = paste0("dplyr::filter(pool_query, ",config$pool_identifier,")")))
    if("pool_function" %in% names(config$env)) {
      pool_query <- config$env$pool_function(pool_query)
    }
    query <- rbind(query, pool_query)
  }

  config$env$query <- query

  if(execute & config$standard_removes) {
    if(config$verbose) message("Performing standard removes...")
    config$env$query <- config$env$query %>%
      dplyr::filter(!(SPECIMEN_STATUS == "Destroyed" & REASON_DESTROYED %in% c("Not Filled", "Extra Label")))
  }

  if("post_query" %in% names(config)) {
    if(config$verbose) message("Executing custom post-query actions...")
    eval(parse(text = config$post_query), envir = config$env)
  }

  return(invisible(config))

}
