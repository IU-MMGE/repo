#'@export
save_inventory <- function(config) {

  if(config$verbose) message("Saving Inventory File")
  if("save_group" %in% names(config)) {
    save_group = config$save_group
  } else {
    save_group = "year"
  }

  if("file_type" %in% names(config)) {
    type = config$file_type
  } else {
    type = "xlsx"
  }

  if(!type %in% c("xlsx", "csv")) {
    stop("file_type should be xlsx or csv", call. = FALSE)
  }

  protocol <- config$protocol[1]
  if(length(protocol) > 1) {
    protocol <- protocol[1]
  }

  if(type == 'xlsx') {

    mmge::save_report(list(Inventory = config$inventory, Dropped = config$dropped_records),
                      name = "Sample Inventory", protocol = protocol,
                      save_group = save_group, type = 'xlsx', latest = TRUE, archive = TRUE)

  } else {

    mmge::save_report(config$inventory,
                      name = "Sample Inventory", protocol = protocol,
                      save_group = save_group, type = 'csv', latest = TRUE, archive = TRUE)

    mmge::save_report(config$dropped_records,
                      name = "Sample Inventory Dropped Records", protocol = protocol,
                      save_group = save_group, type = 'csv', latest = TRUE, archive = TRUE)

  }

  return(invisible(config))

}
