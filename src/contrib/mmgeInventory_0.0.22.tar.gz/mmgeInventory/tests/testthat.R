library(testthat)
library(mmgeInventory)

test_check("mmgeInventory")
