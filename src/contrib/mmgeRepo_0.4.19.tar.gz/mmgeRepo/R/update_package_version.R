update_package_version <- function(pkg, increment = 'patch') {

  desc_path <- file.path(pkg, "DESCRIPTION")

  d <- readLines(desc_path)
  vl <- grep("^Version", d)
  v <- as.numeric(unlist(strsplit(regmatches(d[vl], regexec("[0-9]+\\.[0-9]+\\.[0-9]+", d[vl]))[[1]], "\\.")))

  if(increment == "patch") {
    v[3] <- v[3] + 1
  } else if(increment == "minor") {
    v[3] <- 0
    v[2] <- v[2] + 1
  } else if(increment == "major") {
    v[3] <- 0
    v[2] <- 0
    v[1] <- v[1] + 1
  }
  v <- paste(v, collapse = ".")
  d[vl] <- paste0("Version: ", v)

  dl <- grep("Date:", d)
  if(length(dl) == 0) {
    dl <- vl + 1L
    d1 <- d[1:vl]
    d2 <- d[dl:length(d)]
    d <- c(d1, paste0("Date: ", Sys.Date()), d2)
  } else {
    d[dl] <- paste0("Date: ", Sys.Date())
  }

  f <- file(desc_path)
  writeLines(d, f)
  close(f)

}