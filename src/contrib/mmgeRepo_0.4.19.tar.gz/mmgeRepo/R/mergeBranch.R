mergeBranch <- function(pkg) {

  branch <- system(glue::glue("git -C {pkg} rev-parse --abbrev-ref HEAD"), intern = TRUE)
  merge_with <- tolower(readline(glue::glue("Which branch do you want to merge `{branch}` with? (dev/master)")))
  if(!merge_with %in% c("dev", "master")) {
    merge_with <- NULL
    stop("Must merge with `dev` or `master`")
  }

  return(merge_with)

}