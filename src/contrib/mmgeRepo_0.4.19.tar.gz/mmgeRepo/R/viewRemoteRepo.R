#'@export
viewRemoteRepo <- function(dev = FALSE) {

  if(dev) {
    n <- "dev-repo"
  } else {
    n <- "repo"
  }

  browseURL(paste0(getOption("mmgeRepo.repo_base_url"), n))

}